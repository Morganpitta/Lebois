package io.github.apace100.apoli.condition.type.damage;

import io.github.apace100.apoli.condition.ConditionConfiguration;
import io.github.apace100.apoli.condition.type.DamageConditionTypes;
import net.minecraft.class_8103;
import org.jetbrains.annotations.NotNull;

@Deprecated(forRemoval = true)
public class BypassesArmorDamageConditionType extends InTagDamageConditionType {

	public BypassesArmorDamageConditionType() {
		super(class_8103.field_42241);
	}

	@Override
	public @NotNull ConditionConfiguration<?> getConfig() {
		return DamageConditionTypes.BYPASSES_ARMOR;
	}

}
