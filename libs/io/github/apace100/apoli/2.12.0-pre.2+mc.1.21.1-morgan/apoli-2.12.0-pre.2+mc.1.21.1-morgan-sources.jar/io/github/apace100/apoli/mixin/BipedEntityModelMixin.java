package io.github.apace100.apoli.mixin;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import io.github.apace100.apoli.util.ArmPoseReference;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1309;
import net.minecraft.class_3881;
import net.minecraft.class_3882;
import net.minecraft.class_4592;
import net.minecraft.class_572;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Environment(EnvType.CLIENT)
@Mixin(class_572.class)
public abstract class BipedEntityModelMixin<T extends class_1309> extends class_4592<T> implements class_3881, class_3882 {

    @ModifyExpressionValue(method = "positionRightArm", at = @At(value = "FIELD", target = "Lnet/minecraft/client/render/entity/model/BipedEntityModel;rightArmPose:Lnet/minecraft/client/render/entity/model/BipedEntityModel$ArmPose;"))
    private class_572.class_573 apoli$overrideRightArmPose(class_572.class_573 original, T entity) {
        return ArmPoseReference
            .getArmPose(entity)
            .orElse(original);
    }

    @ModifyExpressionValue(method = "positionLeftArm", at = @At(value = "FIELD", target = "Lnet/minecraft/client/render/entity/model/BipedEntityModel;leftArmPose:Lnet/minecraft/client/render/entity/model/BipedEntityModel$ArmPose;"))
    private class_572.class_573 apoli$overrideLeftArmPose(class_572.class_573 original, T entity) {
        return ArmPoseReference
            .getArmPose(entity)
            .orElse(original);
    }

}
