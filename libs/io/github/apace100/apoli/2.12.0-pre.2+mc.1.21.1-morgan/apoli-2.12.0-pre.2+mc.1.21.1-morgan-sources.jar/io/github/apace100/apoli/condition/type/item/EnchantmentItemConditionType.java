package io.github.apace100.apoli.condition.type.item;

import io.github.apace100.apoli.condition.ConditionConfiguration;
import io.github.apace100.apoli.condition.context.ItemConditionContext;
import io.github.apace100.apoli.condition.type.ItemConditionType;
import io.github.apace100.apoli.condition.type.ItemConditionTypes;
import io.github.apace100.apoli.data.ApoliDataTypes;
import io.github.apace100.apoli.data.TypedDataObjectFactory;
import io.github.apace100.apoli.power.type.ModifyEnchantmentLevelPowerType;
import io.github.apace100.apoli.util.Comparison;
import io.github.apace100.calio.data.SerializableData;
import io.github.apace100.calio.data.SerializableDataTypes;
import org.jetbrains.annotations.NotNull;

import java.util.Optional;
import net.minecraft.class_1799;
import net.minecraft.class_1887;
import net.minecraft.class_1937;
import net.minecraft.class_5321;
import net.minecraft.class_7924;
import net.minecraft.class_9304;

public class EnchantmentItemConditionType extends ItemConditionType {

    public static final TypedDataObjectFactory<EnchantmentItemConditionType> DATA_FACTORY = TypedDataObjectFactory.simple(
        new SerializableData()
            .add("enchantment", SerializableDataTypes.ENCHANTMENT.optional(), Optional.empty())
            .add("use_modifications", SerializableDataTypes.BOOLEAN, true)
            .add("comparison", ApoliDataTypes.COMPARISON, Comparison.GREATER_THAN)
            .add("compare_to", SerializableDataTypes.INT, 0),
        data -> new EnchantmentItemConditionType(
            data.get("enchantment"),
            data.get("use_modifications"),
            data.get("comparison"),
            data.get("compare_to")
        ),
        (conditionType, serializableData) -> serializableData.instance()
            .set("enchantment", conditionType.enchantmentKey)
            .set("use_modifications", conditionType.useModifications)
            .set("comparison", conditionType.comparison)
            .set("compare_to", conditionType.compareTo)
    );

    private final Optional<class_5321<class_1887>> enchantmentKey;
    private final boolean useModifications;

    private final Comparison comparison;
    private final int compareTo;

    public EnchantmentItemConditionType(Optional<class_5321<class_1887>> enchantmentKey, boolean useModifications, Comparison comparison, int compareTo) {
        this.enchantmentKey = enchantmentKey;
        this.useModifications = useModifications;
        this.comparison = comparison;
        this.compareTo = compareTo;
    }

    @Override
    public boolean test(ItemConditionContext context) {

        class_1799 stack = context.stack();
        class_1937 world = context.world();

        class_9304 enchantmentsComponent = ModifyEnchantmentLevelPowerType.getEnchantments(stack, useModifications);
        int levelOrEnchantments = enchantmentKey
            .map(key -> world.method_30349().method_30530(class_7924.field_41265).method_40290(key))
            .map(enchantmentsComponent::method_57536)
            .orElseGet(enchantmentsComponent::method_57541);

        return comparison.compare(levelOrEnchantments, compareTo);

    }

    @Override
    public @NotNull ConditionConfiguration<?> getConfig() {
        return ItemConditionTypes.ENCHANTMENT;
    }

}
