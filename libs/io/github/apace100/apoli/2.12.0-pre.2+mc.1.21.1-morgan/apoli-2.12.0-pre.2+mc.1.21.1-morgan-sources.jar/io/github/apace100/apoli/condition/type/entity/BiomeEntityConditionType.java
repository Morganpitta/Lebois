package io.github.apace100.apoli.condition.type.entity;

import io.github.apace100.apoli.condition.BiomeCondition;
import io.github.apace100.apoli.condition.ConditionConfiguration;
import io.github.apace100.apoli.condition.context.EntityConditionContext;
import io.github.apace100.apoli.condition.type.EntityConditionType;
import io.github.apace100.apoli.condition.type.EntityConditionTypes;
import io.github.apace100.apoli.data.TypedDataObjectFactory;
import io.github.apace100.calio.data.SerializableData;
import io.github.apace100.calio.data.SerializableDataType;
import org.jetbrains.annotations.NotNull;

import java.util.List;
import java.util.Optional;
import net.minecraft.class_1297;
import net.minecraft.class_1959;
import net.minecraft.class_5321;
import net.minecraft.class_6880;
import net.minecraft.class_7924;

public class BiomeEntityConditionType extends EntityConditionType {

    public static final TypedDataObjectFactory<BiomeEntityConditionType> DATA_FACTORY = TypedDataObjectFactory.simple(
        new SerializableData()
            .add("condition", BiomeCondition.DATA_TYPE.optional(), Optional.empty())
            .add("biome", SerializableDataType.registryKey(class_7924.field_41236).optional(), Optional.empty())
            .add("biomes", SerializableDataType.registryKey(class_7924.field_41236).list().optional(), Optional.empty()),
        data -> new BiomeEntityConditionType(
            data.get("condition"),
            data.get("biome"),
            data.get("biomes")
        ),
        (conditionType, serializableData) -> serializableData.instance()
            .set("condition", conditionType.biomeCondition)
            .set("biome", conditionType.biome)
            .set("biomes", conditionType.biomes)
    );

    private final Optional<BiomeCondition> biomeCondition;

    private final Optional<class_5321<class_1959>> biome;
    private final Optional<List<class_5321<class_1959>>> biomes;

    public BiomeEntityConditionType(Optional<BiomeCondition> biomeCondition, Optional<class_5321<class_1959>> biome, Optional<List<class_5321<class_1959>>> biomes) {
        this.biomeCondition = biomeCondition;
        this.biome = biome;
        this.biomes = biomes;
    }

    @Override
    public boolean test(EntityConditionContext context) {

        class_1297 entity = context.entity();

        class_6880<class_1959> biomeEntry = entity.method_37908().method_23753(entity.method_24515());
        class_5321<class_1959> biomeKey = biomeEntry.method_40230().orElseThrow();

        return biome.map(biomeKey::equals).orElse(true)
            && biomes.map(keys -> keys.contains(biomeKey)).orElse(true)
            && biomeCondition.map(condition -> condition.test(entity.method_24515(), biomeEntry)).orElse(true);

    }

    @Override
    public @NotNull ConditionConfiguration<?> getConfig() {
        return EntityConditionTypes.BIOME;
    }

}
