package io.github.apace100.apoli.condition.type.damage;

import io.github.apace100.apoli.condition.ConditionConfiguration;
import io.github.apace100.apoli.condition.type.DamageConditionTypes;
import net.minecraft.class_8103;
import org.jetbrains.annotations.NotNull;

@Deprecated(forRemoval = true)
public class FromFallingDamageConditionType extends InTagDamageConditionType {

	public FromFallingDamageConditionType() {
		super(class_8103.field_42250);
	}

	@Override
	public @NotNull ConditionConfiguration<?> getConfig() {
		return DamageConditionTypes.FROM_FALLING;
	}

}
