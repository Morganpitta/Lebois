package io.github.apace100.apoli.access;

import net.minecraft.class_52;
import net.minecraft.class_5321;

public interface ReplacingLootContext extends LootContextTypeHolder {

    void apoli$setReplaced(class_5321<class_52> key);

    boolean apoli$isReplaced(class_5321<class_52> key);
}
