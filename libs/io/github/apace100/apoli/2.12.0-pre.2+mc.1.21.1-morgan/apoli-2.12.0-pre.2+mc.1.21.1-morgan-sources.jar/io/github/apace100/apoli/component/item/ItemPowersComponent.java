package io.github.apace100.apoli.component.item;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableSet;
import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.apace100.apoli.Apoli;
import io.github.apace100.apoli.component.PowerHolderComponent;
import io.github.apace100.apoli.power.Power;
import io.github.apace100.apoli.power.PowerManager;
import io.netty.buffer.ByteBuf;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import it.unimi.dsi.fastutil.objects.ObjectLinkedOpenHashSet;
import it.unimi.dsi.fastutil.objects.ObjectListIterator;
import java.util.*;
import java.util.function.Consumer;
import java.util.function.Predicate;
import java.util.stream.Stream;
import net.minecraft.class_124;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_2487;
import net.minecraft.class_2509;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import net.minecraft.class_9274;

//  TODO: Make the data of stack powers persist in the item stack
public class ItemPowersComponent {

    public static final ItemPowersComponent DEFAULT = new ItemPowersComponent(Set.of());

    public static final Codec<ItemPowersComponent> CODEC = Entry.SET_CODEC.xmap(
        ItemPowersComponent::new,
		ItemPowersComponent::entries
    );

    public static final class_9139<ByteBuf, ItemPowersComponent> PACKET_CODEC = class_9135.method_56376(ObjectLinkedOpenHashSet::new, Entry.PACKET_CODEC).method_56432(
        ItemPowersComponent::new,
        ItemPowersComponent::entries
    );

    final ObjectLinkedOpenHashSet<Entry> entries;

    ItemPowersComponent(Collection<Entry> entries) {
        this.entries = new ObjectLinkedOpenHashSet<>(entries);
    }

    @Override
    public String toString() {
        return "ItemPowersComponent{entries=" + entries + "}";
    }

    @Override
    public boolean equals(Object obj) {

        if (this == obj) {
            return true;
        }

        else if (!(obj instanceof ItemPowersComponent that)) {
            return false;
        }

        else {
            return Objects.equals(this.entries(), that.entries());
        }

    }

    @Override
    public int hashCode() {
        return Objects.hashCode(entries);
    }

    private ObjectLinkedOpenHashSet<Entry> entries() {
        return entries;
    }

    public Stream<Entry> stream() {
        return entries.stream();
    }

    public void appendTooltip(class_9274 modifierSlot, class_1792.class_9635 context, Consumer<class_2561> tooltip, class_1836 type) {

        for (Entry entry : entries) {

            Power power = PowerManager.getNullable(entry.powerId());
            if (power == null || entry.hidden() || !entry.slot().equals(modifierSlot)) {
                continue;
            }

            tooltip.accept(class_2561
                .method_43469("tooltip.apoli.stack_power.name", power.getName())
                .formatted(entry.negative()
                    ? class_124.field_1061
                    : class_124.field_1054));

            if (!type.method_8035()) {
                continue;
            }

            tooltip.accept(class_2561
                .method_43469("tooltip.apoli.stack_power.description", power.getDescription())
                .formatted(class_124.field_1080));

        }

    }

    public int matchingSlots(class_9274 modifierSlot) {
        return (int) entries
            .stream()
            .map(Entry::slot)
            .filter(modifierSlot::equals)
            .count();
    }

    public boolean containsSlot(class_9274 modifierSlot) {
        return entries
            .stream()
            .map(Entry::slot)
            .anyMatch(modifierSlot::equals);
    }

    public boolean isEmpty() {
        return entries.isEmpty();
    }

    public int size() {
        return entries.size();
    }

    public static void onChangeEquipment(class_1309 entity, class_1304 equipmentSlot, class_1799 previousStack, class_1799 currentStack) {

        class_2960 sourceId = Apoli.identifier("item/" + equipmentSlot.method_5923());
        if (class_1799.method_7973(previousStack, currentStack) || !PowerHolderComponent.KEY.isProvidedBy(entity)) {
            return;
        }

        List<Power> revokedPowers = new ObjectArrayList<>();
        ItemPowersComponent prevStackPowers = previousStack.method_57825(ApoliDataComponentTypes.POWERS, DEFAULT);

        for (Entry prevEntry : prevStackPowers.entries) {
            PowerManager.getOptional(prevEntry.powerId())
                .filter(power -> prevEntry.slot().method_57286(equipmentSlot))
                .ifPresent(revokedPowers::add);
        }

        List<Power> grantedPowers = new ObjectArrayList<>();
        ItemPowersComponent currStackPowers = currentStack.method_57825(ApoliDataComponentTypes.POWERS, DEFAULT);

        for (Entry currEntry : currStackPowers.entries) {
            PowerManager.getOptional(currEntry.powerId())
                .filter(power -> currEntry.slot().method_57286(equipmentSlot))
                .ifPresent(grantedPowers::add);
        }

        if (!revokedPowers.isEmpty()) {
            PowerHolderComponent.revokePowers(entity, Map.of(sourceId, revokedPowers), true);
        }

        if (!grantedPowers.isEmpty()) {
            PowerHolderComponent.grantPowers(entity, Map.of(sourceId, grantedPowers), true);
        }

    }

    public record Entry(class_2960 powerId, class_9274 slot, boolean hidden, boolean negative) {

        public static final MapCodec<Entry> MAP_CODEC = RecordCodecBuilder.mapCodec(instance -> instance.group(
            class_2960.field_25139.fieldOf("power").forGetter(Entry::powerId),
            class_9274.field_49226.fieldOf("slot").forGetter(Entry::slot),
            Codec.BOOL.optionalFieldOf("hidden", false).forGetter(Entry::hidden),
            Codec.BOOL.optionalFieldOf("negative", false).forGetter(Entry::negative)
        ).apply(instance, Entry::new));

        public static final class_9139<ByteBuf, Entry> PACKET_CODEC = class_9139.method_56905(
            class_2960.field_48267, Entry::powerId,
            class_9274.field_49227, Entry::slot,
            class_9135.field_48547, Entry::hidden,
            class_9135.field_48547, Entry::negative,
            Entry::new
        );

        public static final Codec<Set<Entry>> SET_CODEC = MAP_CODEC.codec().listOf().xmap(
			ImmutableSet::copyOf,
			ImmutableList::copyOf
        );

        @Override
        public boolean equals(Object obj) {

            if (this == obj) {
                return true;
            }

            else if (obj instanceof Entry other) {
                return this.powerId().equals(other.powerId())
                    && this.slot().equals(other.slot());
            }

            else {
                return false;
            }

        }

        @Override
        public int hashCode() {
            return Objects.hash(powerId, slot);
        }

    }

    public static Builder builder() {
        return builder(DEFAULT);
    }

    public static Builder builder(ItemPowersComponent baseItemPowers) {
        return new Builder(baseItemPowers);
    }

    public static class Builder {

        private final ObjectLinkedOpenHashSet<Entry> entries = new ObjectLinkedOpenHashSet<>();

        private Builder(ItemPowersComponent baseItemPowers) {
            this.entries.addAll(baseItemPowers.entries);
        }

        public Builder add(EnumSet<class_9274> slots, class_2960 powerId, boolean hidden, boolean negative) {

            class_2487 entryNbt = new class_2487();
            for (class_9274 slot : slots) {

                entryNbt.method_10582("slot", slot.method_15434());
                entryNbt.method_10582("power", powerId.toString());
                entryNbt.method_10556("hidden", hidden);
                entryNbt.method_10556("negative", negative);

                Entry.MAP_CODEC.codec().parse(class_2509.field_11560, entryNbt)
                    .resultOrPartial(err -> Apoli.LOGGER.warn("Cannot add element ({}) as an item power entry: {}", entryNbt, err))
                    .ifPresent(entries::add);

            }

            return this;

        }

        public Builder remove(EnumSet<class_9274> slots, class_2960 powerId) {
            return remove(slots, powerId, modifierSlot -> {});
        }

        public Builder remove(EnumSet<class_9274> slots, class_2960 powerId, Consumer<Collection<Entry>> removalCallback) {

            ObjectListIterator<Entry> entryIterator = entries.iterator();
            ObjectLinkedOpenHashSet<Entry> removedEntries = new ObjectLinkedOpenHashSet<>();

            while (entryIterator.hasNext()) {

                Entry entry = entryIterator.next();

                if (entry.powerId().equals(powerId) && slots.contains(entry.slot())) {
                    removedEntries.add(entry);
                    entryIterator.remove();
                }

            }

            if (!removedEntries.isEmpty()) {
                removalCallback.accept(removedEntries);
            }

            return this;

        }

        public Builder remove(Predicate<Entry> entryPredicate) {
            entries.removeIf(entryPredicate);
            return this;
        }

        public ItemPowersComponent build() {
            return !entries.isEmpty()
                ? new ItemPowersComponent(entries)
                : DEFAULT;
        }

    }

}
