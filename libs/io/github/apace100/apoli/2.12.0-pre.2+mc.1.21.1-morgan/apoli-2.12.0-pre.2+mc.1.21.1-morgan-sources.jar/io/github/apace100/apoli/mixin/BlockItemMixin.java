package io.github.apace100.apoli.mixin;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Local;
import com.llamalad7.mixinextras.sugar.Share;
import com.llamalad7.mixinextras.sugar.ref.LocalRef;
import io.github.apace100.apoli.component.PowerHolderComponent;
import io.github.apace100.apoli.power.type.*;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.List;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1747;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;

@Mixin(class_1747.class)
public class BlockItemMixin {

    @ModifyReturnValue(method = "canPlace", at = @At("RETURN"))
    private boolean apoli$preventBlockPlace(boolean original, class_1750 context, class_2680 state) {

        class_1657 playerEntity = context.method_8036();
        if (playerEntity == null) {
            return original;
        }

        class_2350 direction = context.method_8038();
        class_1799 stack = context.method_8041();
        class_1268 hand = context.method_20287();

        class_2338 toPos = context.method_8037();
        class_2338 onPos = ((ItemUsageContextAccessor) context).callGetHitResult().method_17777();

        Prioritized.CallInstance<ActiveInteractionPowerType> aipci = new Prioritized.CallInstance<>();
        int preventBlockPlacePowers = 0;

        aipci.add(playerEntity, PreventBlockPlacePowerType.class, pbpp -> pbpp.doesPrevent(stack, hand, toPos, onPos, direction));

        for (int i = aipci.getMaxPriority(); i >= aipci.getMinPriority(); i--) {

            if (!aipci.hasPowerTypes(i)) {
                continue;
            }

            List<PreventBlockPlacePowerType> pbpps = aipci.getPowerTypes(i)
                .stream()
                .filter(p -> p instanceof PreventBlockPlacePowerType)
                .map(p -> (PreventBlockPlacePowerType) p)
                .toList();

            preventBlockPlacePowers += pbpps.size();
            pbpps.forEach(pbpp -> pbpp.executeActions(hand, toPos, onPos, direction));

        }

        return preventBlockPlacePowers <= 0 && original;

    }

    @Inject(method = "place(Lnet/minecraft/item/ItemPlacementContext;)Lnet/minecraft/util/ActionResult;", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/World;getBlockState(Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/block/BlockState;"))
    private void apoli$actionOnBlockPlace(class_1750 context, CallbackInfoReturnable<class_1269> cir, @Local class_1657 user, @Local class_2338 toPos, @Local class_1799 stack, @Share("aipci") LocalRef<Prioritized.CallInstance<ActiveInteractionPowerType>> aipciRef) {

        if (user == null) {
            return;
        }

        class_2350 direction = context.method_8038();
        class_2338 onPos = ((ItemUsageContextAccessor) context).callGetHitResult().method_17777();
        class_1268 hand = context.method_20287();

        Prioritized.CallInstance<ActiveInteractionPowerType> aipci = new Prioritized.CallInstance<>();
        aipci.add(user, ActionOnBlockPlacePowerType.class, aobpp -> aobpp.shouldExecute(stack, hand, toPos, onPos, direction));

        for (int i = aipci.getMaxPriority(); i >= aipci.getMinPriority(); i--) {
            aipci.getPowerTypes(i)
                .stream()
                .filter(p -> p instanceof ActionOnBlockPlacePowerType)
                .forEach(p -> ((ActionOnBlockPlacePowerType) p).executeOtherActions(toPos, onPos, direction));
        }

        aipciRef.set(aipci);

    }

    @Inject(method = "place(Lnet/minecraft/item/ItemPlacementContext;)Lnet/minecraft/util/ActionResult;", at = @At("TAIL"))
    private void apoli$actionOnBlockPlacePost(class_1750 context, CallbackInfoReturnable<class_1269> cir, @Share("aipci") LocalRef<Prioritized.CallInstance<ActiveInteractionPowerType>> aipciRef) {

        Prioritized.CallInstance<ActiveInteractionPowerType> aipci = aipciRef.get();

        if (aipci != null) {

            for (int i = aipci.getMaxPriority(); i >= aipci.getMinPriority(); i--) {
                aipci.getPowerTypes(i)
                    .stream()
                    .filter(ActionOnBlockPlacePowerType.class::isInstance)
                    .map(ActionOnBlockPlacePowerType.class::cast)
                    .forEach(p -> p.executeItemActions(context.method_20287()));
            }

        }

    }

    @WrapOperation(method = "useOnBlock", at = @At(value = "INVOKE", target = "Lnet/minecraft/item/Item;use(Lnet/minecraft/world/World;Lnet/minecraft/entity/player/PlayerEntity;Lnet/minecraft/util/Hand;)Lnet/minecraft/util/TypedActionResult;"))
    private class_1271<class_1799> apoli$preventItemUseIfFoodBlockItem(class_1747 instance, class_1937 world, class_1657 user, class_1268 hand, Operation<class_1271<class_1799>> original) {
        class_1799 handStack = user.method_5998(hand);
        return PowerHolderComponent.hasPowerType(user, PreventItemUsePowerType.class, p -> p.doesPrevent(handStack))
            ? class_1271.method_22431(handStack)
            : original.call(instance, world, user, hand);
    }

}
