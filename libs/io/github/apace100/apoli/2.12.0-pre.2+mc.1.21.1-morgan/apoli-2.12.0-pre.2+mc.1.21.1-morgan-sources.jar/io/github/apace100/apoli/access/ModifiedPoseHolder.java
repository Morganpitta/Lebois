package io.github.apace100.apoli.access;

import io.github.apace100.apoli.util.ArmPoseReference;
import java.util.Optional;
import net.minecraft.class_4050;

public interface ModifiedPoseHolder {

    Optional<class_4050> apoli$getModifiedEntityPose();
    void apoli$setModifiedEntityPose(class_4050 entityPose);

    Optional<ArmPoseReference> apoli$getModifiedArmPose();
    void apoli$setModifiedArmPose(ArmPoseReference armPose);

}
