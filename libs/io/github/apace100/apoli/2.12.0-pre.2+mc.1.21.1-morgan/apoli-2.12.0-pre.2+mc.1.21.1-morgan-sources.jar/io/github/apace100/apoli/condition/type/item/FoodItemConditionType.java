package io.github.apace100.apoli.condition.type.item;

import io.github.apace100.apoli.condition.ConditionConfiguration;
import io.github.apace100.apoli.condition.context.ItemConditionContext;
import io.github.apace100.apoli.condition.type.ItemConditionType;
import io.github.apace100.apoli.condition.type.ItemConditionTypes;
import io.github.apace100.apoli.power.type.EdibleItemPowerType;
import net.minecraft.class_1799;
import net.minecraft.class_9334;
import org.jetbrains.annotations.NotNull;

public class FoodItemConditionType extends ItemConditionType {

    @Override
    public boolean test(ItemConditionContext context) {
        class_1799 stack = context.stack();
        return EdibleItemPowerType.get(stack).isPresent()
            || stack.method_57826(class_9334.field_50075);
    }

    @Override
    public @NotNull ConditionConfiguration<?> getConfig() {
        return ItemConditionTypes.FOOD;
    }

}
