package io.github.apace100.apoli.component;

import io.github.apace100.apoli.Apoli;
import io.github.apace100.apoli.data.TypedDataObjectFactory;
import io.github.apace100.apoli.power.MultiplePower;
import io.github.apace100.apoli.power.Power;
import io.github.apace100.apoli.power.PowerConfiguration;
import io.github.apace100.apoli.power.PowerReference;
import io.github.apace100.apoli.power.type.PowerType;
import io.github.apace100.apoli.util.GainedPowerCriterion;
import io.github.apace100.calio.data.SerializableData;
import it.unimi.dsi.fastutil.objects.*;
import org.jetbrains.annotations.NotNull;

import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.BiConsumer;
import java.util.function.Consumer;
import net.minecraft.class_1309;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2509;
import net.minecraft.class_2520;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_7225;
import net.minecraft.class_9129;

public class PowerHolderComponentImpl implements PowerHolderComponent {

    private final Map<Power, PowerType> powers = new Object2ObjectLinkedOpenHashMap<>();
    private final Map<Power, Set<class_2960>> powerSources = new Object2ObjectLinkedOpenHashMap<>();

    private final class_1309 owner;

    public PowerHolderComponentImpl(class_1309 owner) {
        this.owner = owner;
    }

    @Override
    public boolean hasPower(Power power) {
        return powers.containsKey(power);
    }

    @Override
    public boolean hasPower(Power power, class_2960 source) {
        return powerSources.containsKey(power) && powerSources.get(power).contains(source);
    }

    @Override
    public PowerType getPowerType(Power power) {
        return powers.get(power);
    }

    @Override
    public List<PowerType> getPowerTypes() {
        return new LinkedList<>(powers.values());
    }

    @Override
    public Set<Power> getPowers(boolean includeSubPowers) {

        Set<Power> result = new ObjectLinkedOpenHashSet<>();

        for (var power : powers.keySet()) {

            if (includeSubPowers || !power.isSubPower()) {
                result.add(power);
            }

        }

        return result;

    }

    @Override
    public <T extends PowerType> List<T> getPowerTypes(Class<T> typeClass) {
        return getPowerTypes(typeClass, false);
    }

    @Override
    public <T extends PowerType> List<T> getPowerTypes(Class<T> typeClass, boolean includeInactive) {

        List<T> result = new ObjectArrayList<>();

        for (var type : powers.values()) {

            if (typeClass.isInstance(type)) {

                T castedType = typeClass.cast(type);

                if (includeInactive || castedType.isActive()) {
                    result.add(castedType);
                }

            }

        }

        return result;

    }

    @Override
    public List<class_2960> getSources(Power power) {

        if (powerSources.containsKey(power)) {
            return List.copyOf(powerSources.get(power));
        }

        else {
            return List.of();
        }

    }

    @Override
    public boolean removePower(Power power, class_2960 source) {

        Set<Power> powersToRemove = new ObjectLinkedOpenHashSet<>();
        boolean result = this.removePower(power, source, powersToRemove::add);

        powers.keySet().removeAll(powersToRemove);
        powerSources.keySet().removeAll(powersToRemove);

        return result;

    }

    protected boolean removePower(Power power, class_2960 source, Consumer<Power> adder) {

        Set<class_2960> sources = powerSources.getOrDefault(power, new ObjectOpenHashSet<>());
        if (!sources.remove(source)) {
            return false;
        }

        if (sources.isEmpty() && powers.containsKey(power)) {

            PowerType powerType = powers.get(power);
            adder.accept(power);

            powerType.onRemoved();
            powerType.onLost();

        }

        if (power instanceof MultiplePower multiplePower) {
            multiplePower.getSubPowers().forEach(subPower -> this.removePower(subPower, source, adder));
        }

        return true;

    }

    @Override
    public int removeAllPowersFromSource(class_2960 source) {

        List<Power> powersFromSource = this.getPowersFromSource(source);
        int count = 0;

        for (var power : powersFromSource) {

            if (!power.isSubPower() && this.removePower(power, source)) {
                count++;
            }

        }

        return count;

    }

    @Override
    public List<Power> getPowersFromSource(class_2960 source) {

        List<Power> result = new ObjectArrayList<>();

        for (var entry : powerSources.entrySet()) {

            if (entry.getValue().contains(source)) {
                result.add(entry.getKey());
            }

        }

        return result;

    }

    @Override
    public boolean addPower(Power power, class_2960 source) {

        Map<Power, PowerType> powersToAdd = new Object2ObjectArrayMap<>();
        boolean result = this.addPower(power, source, powersToAdd::put);

        powersToAdd.forEach((powerToAdd, powerTypeToAdd) -> {

            powerTypeToAdd.onAdded();
            powerTypeToAdd.onGained();

            if (owner instanceof class_3222 serverPlayer) {
                GainedPowerCriterion.INSTANCE.trigger(serverPlayer, powerToAdd);
            }

        });

        return result;

    }

    protected boolean addPower(Power power, class_2960 source, BiConsumer<Power, PowerType> adder) {

        Set<class_2960> sources = powerSources.computeIfAbsent(power, pt -> new ObjectOpenHashSet<>());
        if (!sources.add(source)) {
            return false;
        }

        PowerType powerType = shallowCopy(power.getType());

        powerType.setPower(power);
        powerType.setHolder(owner);

        powerType.onInit();
        adder.accept(power, powerType);

        powers.put(power, powerType);
        powerSources.put(power, sources);

        if (power instanceof MultiplePower multiplePower) {
            multiplePower.getSubPowers().forEach(subPower -> this.addPower(subPower, source, adder));
        }

        return true;

    }

    @Override
    public void serverTick() {

        for (var type : powers.values()) {

            if (type.shouldTick()) {

                if (type.shouldTickWhenInactive() || type.isActive()) {
                    type.commonTick();
                    type.serverTick();
                }

            }

        }

    }

    @Override
    public void clientTick() {

        for (var type : powers.values()) {

            if (type.shouldTick()) {

                if (type.shouldTickWhenInactive() || type.isActive()) {
                    type.commonTick();
                    type.clientTick();
                }

            }

        }

    }

    @Override
    public void tick() {

    }

    @Override
    public void readFromNbt(@NotNull class_2487 compoundTag, class_7225.class_7874 lookup) {

        powers.clear();
        powerSources.clear();

        class_2499 powersTag = compoundTag.method_10554("powers", class_2520.field_33260);

        //  Migrate compound NBTs from the old 'Powers' NBT path to the new 'powers' NBT path
        if (compoundTag.method_10545("Powers")) {
            powersTag.addAll(compoundTag.method_10554("Powers", class_2520.field_33260));
        }

        for (int i = 0; i < powersTag.size(); i++) {

            class_2487 powerTag = powersTag.method_10602(i);

            try {

                Power.DataEntry powerDataEntry = Power.DataEntry.CODEC.read(lookup.method_57093(class_2509.field_11560), powerTag).getOrThrow();
                PowerReference powerReference = powerDataEntry.powerReference();

                try {

                    Power power = powerReference.getPower();
                    PowerType powerType = shallowCopy(power.getType());

                    powerType.setPower(power);
                    powerType.setHolder(owner);

                    powerType.onInit();

                    try {
                        powerType.fromTag(powerDataEntry.nbtData());
                    }

                    catch (ClassCastException cce) {
                        //  Occurs when the power was overridden by a data pack since last resource reload,
                        //  where the overridden power may encode/decode different NBT types
                        Apoli.LOGGER.warn("Data type of power \"{}\" has changed, skipping data for that power on entity {} (UUID: {})", powerReference.id(), owner.method_5477().getString(), owner.method_5845());
                    }

                    powers.put(power, powerType);
                    powerSources.put(power, powerDataEntry.sources());

                }

                catch (Throwable t) {
                    Apoli.LOGGER.warn("Unregistered power \"{}\" found on entity {} (UUID: {}), skipping...", powerReference.id(), owner.method_5477().getString(), owner.method_5845());
                }

            }

            catch (Throwable t) {
                Apoli.LOGGER.warn("Error trying to decode NBT element ({}) at index {} into a power from NBT of entity {} (UUID: {}) (skipping): {}", powerTag, i, owner.method_5477().getString(), owner.method_5845(), t.getMessage());
            }

        }

    }

    @Override
    public void writeToNbt(@NotNull class_2487 compoundTag, class_7225.class_7874 lookup) {

        class_2499 powersTag = new class_2499();
        powers.forEach((power, powerType) -> {

            PowerConfiguration<?> typeConfig = power.getType().getConfig();
            PowerReference powerReference = PowerReference.of(power.getId());

            Power.DataEntry.CODEC.codec().encodeStart(lookup.method_57093(class_2509.field_11560), new Power.DataEntry(typeConfig, powerReference, powerType.toTag(), powerSources.get(power)))
                .mapError(err -> "Error encoding power \"" + power.getId() + "\" to NBT of entity " + owner.getName().getString() + " (UUID: " + owner.getUuidAsString() + ") (skipping): " + err)
                .resultOrPartial(Apoli.LOGGER::warn)
                .ifPresent(powersTag::add);

        });

        compoundTag.method_10566("powers", powersTag);

    }

    @Override
    public void writeSyncPacket(class_9129 buf, class_3222 recipient) {
        buf.method_10804(0);
        PowerHolderComponent.super.writeSyncPacket(buf, recipient);
    }

    @Override
    public void applySyncPacket(class_9129 buf) {

        int syncType = buf.method_10816();
        switch (syncType) {
            case 0 ->
                PowerHolderComponent.super.applySyncPacket(buf);
            case 1 ->
                PacketHandlers.GRANT_POWERS.apply(buf, this);
            case 2 ->
                PacketHandlers.REVOKE_POWERS.apply(buf, this);
            case 3 ->
                PacketHandlers.REVOKE_ALL_POWERS.apply(buf, this);
            default ->
                Apoli.LOGGER.warn("Received unknown sync type with ID {} (expected value range: [0 to 3]) when applying sync packet to entity {}! Skipping...", syncType, owner.method_5477().getString());
        }

    }

    @Override
    public void sync() {
        KEY.sync(this.owner);
    }

    @Override
    public String toString() {
        StringBuilder str = new StringBuilder("PowerHolderComponent[\n");
        for (Map.Entry<Power, PowerType> powerEntry : powers.entrySet()) {
            str.append("\t").append(powerEntry.getKey().getId()).append(": ").append(powerEntry.getValue().toTag().toString()).append("\n");
        }
        str.append("]");
        return str.toString();
    }

    private static PowerType shallowCopy(PowerType powerType) {

		//noinspection unchecked
		PowerConfiguration<PowerType> config = (PowerConfiguration<PowerType>) powerType.getConfig();
        TypedDataObjectFactory<PowerType> dataFactory = config.dataFactory();

        SerializableData.Instance data = dataFactory.toData(powerType);
        return dataFactory.fromData(data);

    }

}
