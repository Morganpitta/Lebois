package io.github.apace100.apoli.action.type.item;

import io.github.apace100.apoli.action.ActionConfiguration;
import io.github.apace100.apoli.action.context.ItemActionContext;
import io.github.apace100.apoli.action.type.ItemActionType;
import io.github.apace100.apoli.action.type.ItemActionTypes;
import io.github.apace100.apoli.data.TypedDataObjectFactory;
import io.github.apace100.calio.data.SerializableData;
import io.github.apace100.calio.data.SerializableDataTypes;
import net.minecraft.class_2487;
import net.minecraft.class_9279;
import net.minecraft.class_9334;
import org.jetbrains.annotations.NotNull;

public class MergeCustomDataItemActionType extends ItemActionType {

    public static final TypedDataObjectFactory<MergeCustomDataItemActionType> DATA_FACTORY = TypedDataObjectFactory.simple(
        new SerializableData()
            .add("nbt", SerializableDataTypes.NBT_COMPOUND),
        data -> new MergeCustomDataItemActionType(
            data.get("nbt")
        ),
        (actionType, serializableData) -> serializableData.instance()
            .set("nbt", actionType.nbt)
    );

    private final class_2487 nbt;

    public MergeCustomDataItemActionType(class_2487 nbt) {
        this.nbt = nbt;
    }

    @Override
    public void accept(ItemActionContext context) {
        class_9279.method_57452(class_9334.field_49628, context.stackReference().method_32327(), oldNbt -> oldNbt.method_10543(nbt));
    }

    @Override
    public @NotNull ActionConfiguration<?> getConfig() {
        return ItemActionTypes.MERGE_CUSTOM_DATA;
    }

}
