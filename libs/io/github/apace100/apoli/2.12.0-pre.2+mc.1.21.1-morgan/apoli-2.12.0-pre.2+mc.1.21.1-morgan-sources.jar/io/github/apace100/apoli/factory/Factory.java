package io.github.apace100.apoli.factory;

import io.github.apace100.calio.data.SerializableData;
import io.github.apace100.calio.util.Validatable;
import net.minecraft.class_2960;
import net.minecraft.class_9129;

public interface Factory {

    class_2960 getSerializerId();

    SerializableData getSerializableData();

    Instance receive(class_9129 buf);

    Instance fromData(SerializableData.Instance data);

    interface Instance extends Validatable {

        default SerializableData getSerializableData() {
            return this.getFactory().getSerializableData();
        }

        default class_2960 getSerializerId() {
            return this.getFactory().getSerializerId();
        }

        SerializableData.Instance getData();

        Factory getFactory();

        @Override
        default void validate() throws Exception {
            this.getData().validate();
        }

        default void send(class_9129 buf) {

            Factory factory = this.getFactory();

            buf.method_10812(factory.getSerializerId());
            factory.getSerializableData().send(buf, this.getData());

        }

    }

}
