package io.github.apace100.apoli.condition;

import io.github.apace100.apoli.condition.context.ItemConditionContext;
import io.github.apace100.apoli.condition.type.ItemConditionType;
import io.github.apace100.apoli.condition.type.ItemConditionTypes;
import io.github.apace100.apoli.data.ApoliDataTypes;
import io.github.apace100.calio.data.SerializableDataType;
import net.minecraft.class_1799;
import net.minecraft.class_1937;

public final class ItemCondition extends Condition<ItemConditionContext, ItemConditionType> {

	public static final SerializableDataType<ItemCondition> DATA_TYPE = SerializableDataType.lazy(() -> ApoliDataTypes.condition("type", ItemConditionTypes.DATA_TYPE, ItemCondition::new));

	public ItemCondition(ItemConditionType conditionType, boolean inverted) {
		super(conditionType, inverted);
	}

	public ItemCondition(ItemConditionType conditionType) {
		this(conditionType, false);
	}

	public boolean test(class_1937 world, class_1799 stack) {
		return test(new ItemConditionContext(world, stack));
	}

}
