package io.github.apace100.apoli.condition.type.entity;

import io.github.apace100.apoli.condition.ConditionConfiguration;
import io.github.apace100.apoli.condition.context.EntityConditionContext;
import io.github.apace100.apoli.condition.type.EntityConditionType;
import io.github.apace100.apoli.condition.type.EntityConditionTypes;
import io.github.apace100.apoli.data.ApoliDataTypes;
import io.github.apace100.apoli.data.TypedDataObjectFactory;
import io.github.apace100.apoli.mixin.ClientPlayerEntityAccessor;
import io.github.apace100.apoli.mixin.ClientPlayerInteractionManagerAccessor;
import io.github.apace100.apoli.mixin.ServerPlayerInteractionManagerAccessor;
import io.github.apace100.calio.data.SerializableData;
import net.minecraft.class_1657;
import net.minecraft.class_1934;
import net.minecraft.class_3222;
import net.minecraft.class_746;
import org.jetbrains.annotations.NotNull;

public class GameModeEntityConditionType extends EntityConditionType {

    public static final TypedDataObjectFactory<GameModeEntityConditionType> DATA_FACTORY = TypedDataObjectFactory.simple(
        new SerializableData()
            .add("gamemode", ApoliDataTypes.GAME_MODE),
        data -> new GameModeEntityConditionType(
            data.get("gamemode")
        ),
        (conditionType, serializableData) -> serializableData.instance()
            .set("gamemode", conditionType.gameMode)
    );

    private final class_1934 gameMode;

    public GameModeEntityConditionType(class_1934 gameMode) {
        this.gameMode = gameMode;
    }

    @Override
    public boolean test(EntityConditionContext context) {

        if (!(context.entity() instanceof class_1657 player)) {
            return false;
        }

        else if (player instanceof class_3222 serverPlayer) {
            ServerPlayerInteractionManagerAccessor interactionManager = (ServerPlayerInteractionManagerAccessor) serverPlayer.field_13974;
            return interactionManager.getGameMode() == gameMode;
        }

        else if (player instanceof class_746 clientPlayer) {
            ClientPlayerInteractionManagerAccessor interactionManager = (ClientPlayerInteractionManagerAccessor) (((ClientPlayerEntityAccessor) clientPlayer).getClient()).field_1761;
            return interactionManager != null && interactionManager.getGameMode() == gameMode;
        }

        else {
            return false;
        }

    }

    @Override
    public @NotNull ConditionConfiguration<?> getConfig() {
        return EntityConditionTypes.GAME_MODE;
    }

}
