package io.github.apace100.apoli.mixin;

import net.minecraft.class_1734;
import net.minecraft.class_8566;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_1734.class)
public interface CraftingResultSlotAccessor {
    @Accessor
    class_8566 getInput();
}
