package io.github.apace100.apoli.action.type.entity;

import io.github.apace100.apoli.action.ActionConfiguration;
import io.github.apace100.apoli.action.EntityAction;
import io.github.apace100.apoli.action.context.EntityActionContext;
import io.github.apace100.apoli.action.type.EntityActionType;
import io.github.apace100.apoli.action.type.EntityActionTypes;
import io.github.apace100.apoli.data.TypedDataObjectFactory;
import io.github.apace100.apoli.util.MiscUtil;
import io.github.apace100.calio.data.SerializableData;
import io.github.apace100.calio.data.SerializableDataTypes;
import org.jetbrains.annotations.NotNull;

import java.util.Optional;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1668;
import net.minecraft.class_1676;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_3218;
import net.minecraft.class_3532;
import net.minecraft.class_5819;

/**
 *  TODO: Add a {@code bientity_action} field -eggohito
 */
public class FireProjectileEntityActionType extends EntityActionType {

    public static final TypedDataObjectFactory<FireProjectileEntityActionType> DATA_FACTORY = TypedDataObjectFactory.simple(
        new SerializableData()
            .add("entity_type", SerializableDataTypes.ENTITY_TYPE)
            .add("projectile_action", EntityAction.DATA_TYPE.optional(), Optional.empty())
            .add("tag", SerializableDataTypes.NBT_COMPOUND, new class_2487())
            .add("divergence", SerializableDataTypes.FLOAT, 1.0F)
            .add("speed", SerializableDataTypes.FLOAT, 1.5F)
            .add("count", SerializableDataTypes.INT, 1),
        data -> new FireProjectileEntityActionType(
            data.get("entity_type"),
            data.get("projectile_action"),
            data.get("tag"),
            data.get("divergence"),
            data.get("speed"),
            data.get("count")
        ),
        (actionType, serializableData) -> serializableData.instance()
            .set("entity_type", actionType.entityType)
            .set("projectile_action", actionType.projectileAction)
            .set("tag", actionType.tag)
            .set("divergence", actionType.divergence)
            .set("speed", actionType.speed)
            .set("count", actionType.count)
    );

    private final class_1299<?> entityType;
    private final Optional<EntityAction> projectileAction;

    private final class_2487 tag;

    private final float divergence;
    private final float speed;

    private final int count;

    public FireProjectileEntityActionType(class_1299<?> entityType, Optional<EntityAction> projectileAction, class_2487 tag, float divergence, float speed, int count) {
        this.entityType = entityType;
        this.projectileAction = projectileAction;
        this.tag = tag;
        this.divergence = divergence;
        this.speed = speed;
        this.count = count;
    }

    @Override
    public void accept(EntityActionContext context) {

        class_1297 entity = context.entity();

        if (!(entity.method_37908() instanceof class_3218 serverWorld)) {
            return;
        }

        class_5819 random = serverWorld.method_8409();

        class_243 velocity = entity.method_18798();
        class_243 verticalOffset = entity.method_19538().method_1031(0, entity.method_18381(entity.method_18376()), 0);

        float pitch = entity.method_36455();
        float yaw = entity.method_36454();

        for (int i = 0; i < count; i++) {

            class_1297 entityToSpawn = MiscUtil
                .getEntityWithPassengers(serverWorld, entityType, tag, verticalOffset, yaw, pitch)
                .orElse(null);

            if (entityToSpawn == null) {
                return;
            }

            if (entityToSpawn instanceof class_1676 projectileToSpawn) {

                if (projectileToSpawn instanceof class_1668 explosiveProjectileToSpawn) {
                    explosiveProjectileToSpawn.field_51893 = speed;
                }

                projectileToSpawn.method_7432(entity);
                projectileToSpawn.method_24919(entity, pitch, yaw, 0F, speed, divergence);

            }

            else {

                float j = 0.017453292F;
                double k = 0.007499999832361937D;

                float l = -class_3532.method_15374(yaw * j) * class_3532.method_15362(pitch * j);
                float m = -class_3532.method_15374(pitch * j);
                float n =  class_3532.method_15362(yaw * j) * class_3532.method_15362(pitch * j);

                class_243 velocityToApply = new class_243(l, m, n)
                    .method_1029()
                    .method_1031(random.method_43059() * k * divergence, random.method_43059() * k * divergence, random.method_43059() * k * divergence)
                    .method_1021(speed);

                entityToSpawn.method_18799(velocityToApply);
                entityToSpawn.method_5762(velocity.field_1352, entity.method_24828() ? 0.0D : velocity.field_1351, velocity.field_1350);

            }

            if (!tag.method_33133()) {

                class_2487 mergedNbt = entityToSpawn.method_5647(new class_2487());
                mergedNbt.method_10543(tag);

                entityToSpawn.method_5651(mergedNbt);

            }

            serverWorld.method_30736(entityToSpawn);
            projectileAction.ifPresent(action -> action.execute(entityToSpawn));

        }

    }

    @Override
    public @NotNull ActionConfiguration<?> getConfig() {
        return EntityActionTypes.FIRE_PROJECTILE;
    }

}
