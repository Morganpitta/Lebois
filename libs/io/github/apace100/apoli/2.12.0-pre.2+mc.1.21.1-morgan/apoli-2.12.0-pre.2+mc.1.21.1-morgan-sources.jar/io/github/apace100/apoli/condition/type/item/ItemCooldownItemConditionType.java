package io.github.apace100.apoli.condition.type.item;

import io.github.apace100.apoli.access.EntityLinkedItemStack;
import io.github.apace100.apoli.condition.ConditionConfiguration;
import io.github.apace100.apoli.condition.context.ItemConditionContext;
import io.github.apace100.apoli.condition.type.ItemConditionType;
import io.github.apace100.apoli.condition.type.ItemConditionTypes;
import io.github.apace100.apoli.data.ApoliDataTypes;
import io.github.apace100.apoli.data.TypedDataObjectFactory;
import io.github.apace100.apoli.util.Comparison;
import io.github.apace100.calio.data.SerializableData;
import io.github.apace100.calio.data.SerializableDataTypes;
import net.minecraft.class_1657;
import net.minecraft.class_1796;
import net.minecraft.class_1799;
import org.jetbrains.annotations.NotNull;

public class ItemCooldownItemConditionType extends ItemConditionType {

    public static final TypedDataObjectFactory<ItemCooldownItemConditionType> DATA_FACTORY = TypedDataObjectFactory.simple(
        new SerializableData()
            .add("comparison", ApoliDataTypes.COMPARISON)
            .add("compare_to", SerializableDataTypes.INT),
        data -> new ItemCooldownItemConditionType(
            data.get("comparison"),
            data.get("compare_to")
        ),
        (conditionType, serializableData) -> serializableData.instance()
            .set("comparison", conditionType.comparison)
            .set("compare_to", conditionType.compareTo)
    );

    private final Comparison comparison;
    private final int compareTo;

    public ItemCooldownItemConditionType(Comparison comparison, int compareTo) {
        this.comparison = comparison;
        this.compareTo = compareTo;
    }

    @Override
    public boolean test(ItemConditionContext context) {

        class_1799 stack = context.stack();

        if (!stack.method_7960() && ((EntityLinkedItemStack) stack).apoli$getEntity(true) instanceof class_1657 player) {

            class_1796.class_1797 cooldownEntry = player.method_7357().field_8024.get(stack.method_7909());
            int cooldown = cooldownEntry != null
                ? Math.abs(cooldownEntry.field_8027 - cooldownEntry.field_8028)
                : 0;

            return comparison.compare(cooldown, compareTo);

        }

        else {
            return false;
        }

    }

    @Override
    public @NotNull ConditionConfiguration<?> getConfig() {
        return ItemConditionTypes.ITEM_COOLDOWN;
    }

}
