package io.github.apace100.apoli.command.argument.suggestion;

import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.suggestion.SuggestionProvider;
import com.mojang.brigadier.suggestion.Suggestions;
import com.mojang.brigadier.suggestion.SuggestionsBuilder;
import io.github.apace100.apoli.Apoli;
import io.github.apace100.apoli.command.argument.PowerArgumentType;
import io.github.apace100.apoli.command.argument.PowerHolderArgumentType;
import io.github.apace100.apoli.component.PowerHolderComponent;
import io.github.apace100.apoli.power.Power;
import io.github.apace100.apoli.power.PowerManager;
import io.github.apace100.apoli.util.PowerUtil;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.function.Function;
import java.util.stream.Stream;
import net.minecraft.class_1297;
import net.minecraft.class_2168;
import net.minecraft.class_2172;
import net.minecraft.class_2960;

public record PowerSuggestionProvider(Function<CommandContext<class_2168>, Collection<class_1297>> getter, PowerArgumentType.PowerTarget targetType) implements SuggestionProvider<class_2168> {

	private static PowerSuggestionProvider entity(String entityArgumentName, PowerArgumentType.PowerTarget targetType) {
		return new PowerSuggestionProvider(context -> {

			try {
				return List.of(PowerHolderArgumentType.getHolder(context, entityArgumentName));
			}

			catch (IllegalArgumentException iae) {
				Apoli.LOGGER.warn("Something went wrong trying to get an entity from argument \"{}\": ", entityArgumentName, iae);
				throw iae;
			}

			catch (CommandSyntaxException e) {
				throw new IllegalStateException(e);
			}

		}, targetType);
	}

	private static PowerSuggestionProvider entities(String entitiesArgumentName, PowerArgumentType.PowerTarget targetType) {
		return new PowerSuggestionProvider(context -> {

			try {
				return PowerHolderArgumentType.getHolders(context, entitiesArgumentName)
					.stream()
					.map(class_1297.class::cast)
					.toList();
			}

			catch (IllegalArgumentException iae) {
				Apoli.LOGGER.warn("Something went wrong trying to get entities from argument \"{}\": ", entitiesArgumentName, iae);
				throw iae;
			}

			catch (CommandSyntaxException e) {
				throw new IllegalStateException(e);
			}

		}, targetType);
	}

	public static PowerSuggestionProvider powersFromEntity(String entityArgumentName) {
		return entity(entityArgumentName, PowerArgumentType.PowerTarget.GENERAL);
	}

	public static PowerSuggestionProvider powersFromEntities(String entitiesArgumentName) {
		return entities(entitiesArgumentName, PowerArgumentType.PowerTarget.GENERAL);
	}

	public static PowerSuggestionProvider resourcesFromEntity(String entityArgumentName) {
		return entity(entityArgumentName, PowerArgumentType.PowerTarget.RESOURCE);
	}

	public static PowerSuggestionProvider resourcesFromEntities(String entitiesArgumentName) {
		return entities(entitiesArgumentName, PowerArgumentType.PowerTarget.RESOURCE);
	}

	@Override
	public CompletableFuture<Suggestions> getSuggestions(CommandContext<class_2168> context, SuggestionsBuilder builder) {

		try {

			Stream.Builder<class_2960> powerIds = Stream.builder();
			Collection<class_1297> entities = getter().apply(context);

			for (class_1297 entity : entities) {

				PowerHolderComponent powerComponent = PowerHolderComponent.KEY.get(entity);
				for (Map.Entry<class_2960, Power> powerEntry : PowerManager.entrySet()) {

					class_2960 id = powerEntry.getKey();
					Power power = powerEntry.getValue();

					try {

						if (powerComponent.hasPower(power) && isAllowed(power)) {
							powerIds.add(id);
						}

					}

					catch (Exception e) {
						Apoli.LOGGER.error("Error trying to put power \"{}\" in the suggestion provider (skipping): {}", id, e);
					}

				}

			}

			return class_2172.method_9257(powerIds.build(), builder);

		}

		catch (Exception e) {
			return Suggestions.empty();
		}

	}

	private boolean isAllowed(Power power) {
		return targetType() != PowerArgumentType.PowerTarget.RESOURCE
			|| PowerUtil.validateResource(power.getType()).isSuccess();
	}

}
