package io.github.apace100.apoli.mixin;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import io.github.apace100.apoli.access.PowerModifiedGrindstone;
import io.github.apace100.apoli.power.type.ModifyGrindstonePowerType;
import io.github.apace100.apoli.util.modifier.Modifier;
import io.github.apace100.apoli.util.modifier.ModifierUtil;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;

import java.util.List;
import java.util.Optional;
import net.minecraft.class_1937;
import net.minecraft.class_3803;

@Mixin(targets = "net/minecraft/screen/GrindstoneScreenHandler$4")
public abstract class GrindstoneScreenHandlerOutputSlotMixin {

    @Final
    @Shadow
    class_3803 field_16780;

    @ModifyReturnValue(method = "getExperience(Lnet/minecraft/world/World;)I", at = @At("RETURN"))
    private int apoli$modifyExperience(int original, class_1937 world) {

        if (!(field_16780 instanceof PowerModifiedGrindstone powerModifiedGrindstone)) {
            return original;
        }

        List<Modifier> modifiers = powerModifiedGrindstone.apoli$getAppliedPowers()
            .stream()
            .map(ModifyGrindstonePowerType::getExperienceModifier)
            .filter(Optional::isPresent)
            .map(Optional::get)
            .toList();

        return (int) ModifierUtil.applyModifiers(powerModifiedGrindstone.apoli$getPlayer(), modifiers, original);

    }

}
