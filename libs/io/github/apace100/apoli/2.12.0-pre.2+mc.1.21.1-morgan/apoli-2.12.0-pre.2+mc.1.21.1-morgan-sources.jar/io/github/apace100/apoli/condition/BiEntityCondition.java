package io.github.apace100.apoli.condition;

import io.github.apace100.apoli.condition.context.BiEntityConditionContext;
import io.github.apace100.apoli.condition.type.BiEntityConditionType;
import io.github.apace100.apoli.condition.type.BiEntityConditionTypes;
import io.github.apace100.apoli.data.ApoliDataTypes;
import io.github.apace100.calio.data.SerializableDataType;
import net.minecraft.class_1297;

public final class BiEntityCondition extends Condition<BiEntityConditionContext, BiEntityConditionType> {

	public static final SerializableDataType<BiEntityCondition> DATA_TYPE = SerializableDataType.lazy(() -> ApoliDataTypes.condition("type", BiEntityConditionTypes.DATA_TYPE, BiEntityCondition::new));

	public BiEntityCondition(BiEntityConditionType conditionType, boolean inverted) {
		super(conditionType, inverted);
	}

	public BiEntityCondition(BiEntityConditionType conditionType) {
		this(conditionType, false);
	}

	public boolean test(class_1297 actor, class_1297 target) {
		return test(new BiEntityConditionContext(actor, target));
	}

}
