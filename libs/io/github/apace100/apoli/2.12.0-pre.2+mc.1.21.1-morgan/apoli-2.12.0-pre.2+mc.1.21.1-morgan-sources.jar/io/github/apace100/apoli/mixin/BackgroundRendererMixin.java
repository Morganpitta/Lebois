package io.github.apace100.apoli.mixin;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.llamalad7.mixinextras.sugar.Local;
import io.github.apace100.apoli.component.PowerHolderComponent;
import io.github.apace100.apoli.power.type.ModifyCameraSubmersionTypePowerType;
import io.github.apace100.apoli.power.type.NightVisionPowerType;
import io.github.apace100.apoli.power.type.PhasingPowerType;
import io.github.apace100.apoli.util.MiscUtil;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_4184;
import net.minecraft.class_5636;
import net.minecraft.class_638;
import net.minecraft.class_758;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;

import java.util.List;

@Mixin(class_758.class)
@Environment(EnvType.CLIENT)
public abstract class BackgroundRendererMixin {

    @Shadow private static float red;

    @Shadow private static float green;

    @Shadow private static float blue;

    @ModifyExpressionValue(method = "render", at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/LivingEntity;hasStatusEffect(Lnet/minecraft/registry/entry/RegistryEntry;)Z", ordinal = 0))
    private static boolean apoli$nightVisionProxy(boolean original, @Local class_1297 cameraFocusedEntity) {
        return original
            || PowerHolderComponent.hasPowerType(cameraFocusedEntity, NightVisionPowerType.class);
    }

    @ModifyExpressionValue(method = "render", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/render/Camera;getSubmersionType()Lnet/minecraft/block/enums/CameraSubmersionType;"))
    private static class_5636 apoli$modifyCameraSubmersionType(class_5636 original, class_4184 camera) {
        return PowerHolderComponent.getPowerTypes(camera.method_19331(), ModifyCameraSubmersionTypePowerType.class, true)
            .stream()
            .filter(p -> p.doesModify(original) && p.isActive())
            .findFirst()
            .map(ModifyCameraSubmersionTypePowerType::getNewType)
            .orElse(original);
    }

    @ModifyExpressionValue(method = "applyFog", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/render/Camera;getSubmersionType()Lnet/minecraft/block/enums/CameraSubmersionType;"))
    private static class_5636 apoli$modifyCameraSubmersionTypeFog(class_5636 original, class_4184 camera) {
        return PowerHolderComponent.getPowerTypes(camera.method_19331(), ModifyCameraSubmersionTypePowerType.class, true)
            .stream()
            .filter(p -> p.doesModify(original) && p.isActive())
            .findFirst()
            .map(ModifyCameraSubmersionTypePowerType::getNewType)
            .orElse(original);
    }

    @Inject(method = "render", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/render/BackgroundRenderer;getFogModifier(Lnet/minecraft/entity/Entity;F)Lnet/minecraft/client/render/BackgroundRenderer$StatusEffectFogModifier;"))
    private static void modifyFogColor(class_4184 camera, float tickDelta, class_638 world, int viewDistance, float skyDarkness, CallbackInfo ci) {
        if(camera.method_19331() instanceof class_1309) {
            if(PowerHolderComponent.getPowerTypes(camera.method_19331(), PhasingPowerType.class).stream().anyMatch(pp -> pp.getRenderType() == PhasingPowerType.RenderType.BLINDNESS)) {
                if(MiscUtil.getInWallBlockState((class_1657)camera.method_19331()) != null) {
                    red = 0f;
                    green = 0f;
                    blue = 0f;
                }
            }
        }
    }

    @Inject(method = "applyFog", at = @At(value = "INVOKE", target = "Lcom/mojang/blaze3d/systems/RenderSystem;setShaderFogStart(F)V", shift = At.Shift.BEFORE), locals = LocalCapture.CAPTURE_FAILHARD)
    private static void modifyFogData(class_4184 camera, class_758.class_4596 fogType, float viewDistance, boolean thickFog, float tickDelta, CallbackInfo ci, class_5636 cameraSubmersionType, class_1297 entity, class_758.class_7285 fogData) {
        if(camera.method_19331() instanceof class_1309) {
            List<PhasingPowerType> phasings = PowerHolderComponent.getPowerTypes(camera.method_19331(), PhasingPowerType.class);
            if(phasings.stream().anyMatch(pp -> pp.getRenderType() == PhasingPowerType.RenderType.BLINDNESS)) {
                if(MiscUtil.getInWallBlockState((class_1309)camera.method_19331()) != null) {
                    float view = phasings.stream().filter(pp -> pp.getRenderType() == PhasingPowerType.RenderType.BLINDNESS).map(PhasingPowerType::getViewDistance).min(Float::compareTo).get();
                    if (fogData.field_38339 == class_758.class_4596.field_20945) {
                        fogData.field_38340 = 0.0f;
                        fogData.field_38341 = view * 0.8f;
                    } else {
                        fogData.field_38340 = view * 0.25f;
                        fogData.field_38341 = view;
                    }
                }
            }
        }
    }
}
