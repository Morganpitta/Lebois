package io.github.apace100.apoli.mixin;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Share;
import com.llamalad7.mixinextras.sugar.ref.LocalRef;
import io.github.apace100.apoli.access.EntityLinkedItemStack;
import io.github.apace100.apoli.component.PowerHolderComponent;
import io.github.apace100.apoli.power.type.*;
import io.github.apace100.apoli.util.InventoryUtil;
import io.github.apace100.apoli.util.PriorityPhase;
import io.github.apace100.apoli.util.StackClickPhase;
import net.fabricmc.fabric.api.item.v1.FabricItemStack;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1735;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1839;
import net.minecraft.class_1937;
import net.minecraft.class_3414;
import net.minecraft.class_5328;
import net.minecraft.class_5536;
import net.minecraft.class_5630;
import net.minecraft.class_9322;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;

import java.lang.ref.WeakReference;

@Mixin(class_1799.class)
public abstract class ItemStackMixin implements class_9322, EntityLinkedItemStack, FabricItemStack {

    @Nullable
    @Shadow
    public abstract class_1297 getHolder();

    @Shadow
    public abstract class_1792 getItem();

    @Shadow
    public abstract boolean isEmpty();

    @Shadow
    public abstract class_1799 copy();

    @Unique
    @Nullable
    private WeakReference<class_1297> apoli$holdingEntity;

    @Override
    public class_1297 apoli$getEntity() {
        return apoli$getEntity(true);
    }

    @Override
    public class_1297 apoli$getEntity(boolean prioritiseVanillaHolder) {
        class_1297 vanillaHolder = getHolder();
        if (prioritiseVanillaHolder && vanillaHolder != null) {
            return vanillaHolder;
        }
        if (apoli$holdingEntity != null) {
            return apoli$holdingEntity.get();
        }
        return null;
    }

    @Override
    public void apoli$setEntity(class_1297 entity) {
        this.apoli$holdingEntity = new WeakReference<>(entity);
    }

    @WrapOperation(method = "use", at = @At(value = "INVOKE", target = "Lnet/minecraft/item/Item;use(Lnet/minecraft/world/World;Lnet/minecraft/entity/player/PlayerEntity;Lnet/minecraft/util/Hand;)Lnet/minecraft/util/TypedActionResult;"))
    private class_1271<class_1799> apoli$onItemUse(class_1792 item, class_1937 world, class_1657 user, class_1268 hand, Operation<class_1271<class_1799>> original) {

        //  region  Prevent item use
        class_1799 thisAsStack = (class_1799) (Object) this;
        if (PowerHolderComponent.hasPowerType(user, PreventItemUsePowerType.class, piup -> piup.doesPrevent(thisAsStack))) {
            return class_1271.method_22431(thisAsStack);
        }
        //  endregion

        //  region  Action on item before use
        class_5630 useStackReference = InventoryUtil.getStackReferenceFromStack(user, thisAsStack);
        class_1799 useStack = useStackReference.method_32327();

        ActionOnItemUsePowerType.TriggerType triggerType = useStack.method_7935(user) == 0
            ? ActionOnItemUsePowerType.TriggerType.INSTANT
            : ActionOnItemUsePowerType.TriggerType.START;
        ActionOnItemUsePowerType.executeActions(user, useStackReference, useStack, triggerType, PriorityPhase.BEFORE);
        //  endregion

        //  region  Edible item
        class_1799 oldUseStack = useStack.method_7972();
        boolean canConsumeCustomFood = EdibleItemPowerType.get(useStack, user)
            .map(EdibleItemPowerType::getFoodComponent)
            .map(fc -> user.method_7332(fc.comp_2493()))
            .orElse(false);

        class_1271<class_1799> action = canConsumeCustomFood
            ? class_5328.method_29282(world, user, hand)
            : original.call(useStack.method_7909(), world, user, hand);

        if (!action.method_5467().method_23665()) {
            return action;
        }
        //  endregion

        //  region  Action on item after use
        useStackReference = class_5630.method_32330(user, user.method_32326(oldUseStack));
        triggerType = useStack.method_7935(user) == 0
            ? ActionOnItemUsePowerType.TriggerType.INSTANT
            : ActionOnItemUsePowerType.TriggerType.START;

        ActionOnItemUsePowerType.executeActions(user, useStackReference, useStack, triggerType, PriorityPhase.AFTER);
        return action;
        //  endregion

    }

    @WrapOperation(method = "usageTick", at = @At(value = "INVOKE", target = "Lnet/minecraft/item/Item;usageTick(Lnet/minecraft/world/World;Lnet/minecraft/entity/LivingEntity;Lnet/minecraft/item/ItemStack;I)V"))
    private void apoli$actionOnItemDuringUse(class_1792 item, class_1937 world, class_1309 user, class_1799 stack, int remainingUseTicks, Operation<Void> original, @Share("usingStackReference") LocalRef<class_5630> sharedUsingStackReference) {

        ActionOnItemUsePowerType.TriggerType triggerType = ActionOnItemUsePowerType.TriggerType.DURING;

        class_5630 usingStackReference = InventoryUtil.getStackReferenceFromStack(user, (class_1799) (Object) this);
        class_1799 usingStack = usingStackReference.method_32327();

        ActionOnItemUsePowerType.executeActions(user, usingStackReference, usingStack, triggerType, PriorityPhase.BEFORE);

        if (EdibleItemPowerType.get(usingStack, user).isEmpty()) {
            original.call(usingStack.method_7909(), world, user, usingStack, remainingUseTicks);
        }

        else {
            ActionOnItemUsePowerType.executeActions(user, usingStackReference, usingStack, triggerType, PriorityPhase.AFTER);
        }

    }

    @WrapOperation(method = "onStoppedUsing", at = @At(value = "INVOKE", target = "Lnet/minecraft/item/Item;onStoppedUsing(Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/LivingEntity;I)V"))
    private void apoli$actionOnItemStoppedUsing(class_1792 item, class_1799 stack, class_1937 world, class_1309 user, int remainingUseTicks, Operation<Void> original, @Share("stoppedUsingStackReference") LocalRef<class_5630> sharedStoppedUsingStackReference) {

        ActionOnItemUsePowerType.TriggerType triggerType = ActionOnItemUsePowerType.TriggerType.STOP;

        class_5630 stoppedUsingStackReference = InventoryUtil.getStackReferenceFromStack(user, (class_1799) (Object) this);
        class_1799 stoppedUsingStack = stoppedUsingStackReference.method_32327();

        ActionOnItemUsePowerType.executeActions(user, stoppedUsingStackReference, stoppedUsingStack, triggerType, PriorityPhase.BEFORE);

        if (EdibleItemPowerType.get(stoppedUsingStack, user).isEmpty()) {
            original.call(stoppedUsingStack.method_7909(), stoppedUsingStack, world, user, remainingUseTicks);
        }

        else {
            ActionOnItemUsePowerType.executeActions(user, stoppedUsingStackReference, stoppedUsingStack, triggerType, PriorityPhase.AFTER);
        }

    }

    @WrapOperation(method = "finishUsing", at = @At(value = "INVOKE", target = "Lnet/minecraft/item/Item;finishUsing(Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/LivingEntity;)Lnet/minecraft/item/ItemStack;"))
    private class_1799 apoli$onFinishItemUse(class_1792 item, class_1799 stack, class_1937 world, class_1309 user, Operation<class_1799> original) {

        //  region  Action on item before finish using
        class_5630 finishUsingStackRef = InventoryUtil.getStackReferenceFromStack(user, stack);
        class_1799 finishUsingStack = finishUsingStackRef.method_32327();

        ActionOnItemUsePowerType.executeActions(user, finishUsingStackRef, finishUsingStack, ActionOnItemUsePowerType.TriggerType.FINISH, PriorityPhase.BEFORE);
        //  endregion

        //  region  Edible item consumption effects
        finishUsingStackRef.method_32332(EdibleItemPowerType.get(finishUsingStack, user)
            .map(p -> user.method_18866(world, stack, p.getFoodComponent()))
            .orElseGet(() -> original.call(finishUsingStack.method_7909(), finishUsingStack, world, user)));
        //  endregion

        //  region  Action on item after finish using
        ActionOnItemUsePowerType.executeActions(user, finishUsingStackRef, finishUsingStack, ActionOnItemUsePowerType.TriggerType.FINISH, PriorityPhase.AFTER);
        return finishUsingStack;
        //  endregion

    }

    @ModifyReturnValue(method = "getUseAction", at = @At("RETURN"))
    private class_1839 apoli$replaceUseAction(class_1839 original) {
        return EdibleItemPowerType.get((class_1799) (Object) this)
            .map(EdibleItemPowerType::getConsumeAnimation)
            .orElse(original);
    }

    @ModifyReturnValue(method = "getEatSound", at = @At("RETURN"))
    private class_3414 apoli$replaceEatingSound(class_3414 original) {
        return EdibleItemPowerType.get((class_1799) (Object) this)
            .map(EdibleItemPowerType::getConsumeSoundEvent)
            .orElse(original);
    }

    @ModifyReturnValue(method = "getDrinkSound", at = @At("RETURN"))
    private class_3414 apoli$replaceDrinkingSound(class_3414 original) {
        return EdibleItemPowerType.get((class_1799) (Object) this)
            .map(EdibleItemPowerType::getConsumeSoundEvent)
            .orElse(original);
    }

    @ModifyReturnValue(method = "getMaxUseTime", at = @At("RETURN"))
    private int apoli$modifyMaxUseTicks(int original) {
        return ModifyFoodPowerType
            .modifyEatTicks(this.apoli$getEntity(), (class_1799) (Object) this)
            .orElse(original);
    }

    @WrapOperation(method = "isUsedOnRelease", at = @At(value = "INVOKE", target = "Lnet/minecraft/item/Item;isUsedOnRelease(Lnet/minecraft/item/ItemStack;)Z"))
    private boolean apoli$useOnReleaseIfCustomFood(class_1792 item, class_1799 stack, Operation<Boolean> original) {
        return EdibleItemPowerType.get(stack).isEmpty()
            ? original.call(item, stack)
            : false;
    }

    @WrapOperation(method = "onStackClicked", at = @At(value = "INVOKE", target = "Lnet/minecraft/item/Item;onStackClicked(Lnet/minecraft/item/ItemStack;Lnet/minecraft/screen/slot/Slot;Lnet/minecraft/util/ClickType;Lnet/minecraft/entity/player/PlayerEntity;)Z"))
    private boolean apoli$itemOnItem_cursorStack(class_1792 cursorItem, class_1799 cursorStack, class_1735 slot, class_5536 clickType, class_1657 player, Operation<Boolean> original) {

        StackClickPhase clickPhase = StackClickPhase.CURSOR;

        class_5630 cursorStackReference = ((ScreenHandlerAccessor) player.field_7512).callGetCursorStackReference();
        class_5630 slotStackReference = class_5630.method_32328(slot.field_7871, slot.method_34266());

        return ItemOnItemPowerType.executeActions(player, PriorityPhase.BEFORE, clickPhase, clickType, slot, slotStackReference, cursorStackReference)
            || original.call(cursorStackReference.method_32327().method_7909(), cursorStackReference.method_32327(), slot, clickType, player)
            || ItemOnItemPowerType.executeActions(player, PriorityPhase.AFTER, clickPhase, clickType, slot, slotStackReference, cursorStackReference);

    }

    @WrapOperation(method = "onClicked", at = @At(value = "INVOKE", target = "Lnet/minecraft/item/Item;onClicked(Lnet/minecraft/item/ItemStack;Lnet/minecraft/item/ItemStack;Lnet/minecraft/screen/slot/Slot;Lnet/minecraft/util/ClickType;Lnet/minecraft/entity/player/PlayerEntity;Lnet/minecraft/inventory/StackReference;)Z"))
    private boolean apoli$itemOnItem_slotStack(class_1792 slotItem, class_1799 slotStack, class_1799 cursorStack, class_1735 slot, class_5536 clickType, class_1657 player, class_5630 cursorStackReference, Operation<Boolean> original) {

        StackClickPhase clickPhase = StackClickPhase.SLOT;
        class_5630 slotStackReference = class_5630.method_32328(slot.field_7871, slot.method_34266());

        return ItemOnItemPowerType.executeActions(player, PriorityPhase.BEFORE, clickPhase, clickType, slot, slotStackReference, cursorStackReference)
            || original.call(slotStackReference.method_32327().method_7909(), slotStackReference.method_32327(), cursorStackReference.method_32327(), slot, clickType, player, cursorStackReference)
            || ItemOnItemPowerType.executeActions(player, PriorityPhase.AFTER, clickPhase, clickType, slot, slotStackReference, cursorStackReference);

    }

}
