package io.github.apace100.apoli.access;

import io.github.apace100.apoli.power.type.PowerType;
import java.util.Collection;
import net.minecraft.class_1715;

public interface PowerCraftingInventory extends PowerCraftingObject {

    Collection<? extends PowerType> apoli$getPowerTypes();

    void apoli$setPowerTypes(Collection<? extends PowerType> powerType);

    default class_1715 apoli$getInventory() {
        return null;
    }

    default void apoli$setInventory(class_1715 inventory) {

    }

}
