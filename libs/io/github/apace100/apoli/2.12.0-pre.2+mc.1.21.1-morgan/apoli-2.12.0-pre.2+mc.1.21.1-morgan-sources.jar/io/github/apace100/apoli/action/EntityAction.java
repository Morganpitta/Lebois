package io.github.apace100.apoli.action;

import io.github.apace100.apoli.action.context.EntityActionContext;
import io.github.apace100.apoli.action.type.EntityActionType;
import io.github.apace100.apoli.action.type.EntityActionTypes;
import io.github.apace100.apoli.action.type.entity.meta.SequenceEntityActionType;
import io.github.apace100.apoli.data.ApoliDataTypes;
import io.github.apace100.calio.data.SerializableDataType;
import net.minecraft.class_1297;

public final class EntityAction extends Action<EntityActionContext, EntityActionType> {

	public static final SerializableDataType<EntityAction> DATA_TYPE = SerializableDataType.lazy(() -> ApoliDataTypes.actions("type", EntityActionTypes.DATA_TYPE, SequenceEntityActionType::new, EntityAction::new));

	public EntityAction(EntityActionType actionType) {
		super(actionType);
	}

	public void execute(class_1297 entity) {
		accept(new EntityActionContext(entity));
	}

}
