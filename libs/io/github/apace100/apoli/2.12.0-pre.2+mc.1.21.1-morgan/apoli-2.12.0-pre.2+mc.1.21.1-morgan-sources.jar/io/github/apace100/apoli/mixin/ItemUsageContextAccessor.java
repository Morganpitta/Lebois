package io.github.apace100.apoli.mixin;

import net.minecraft.class_1838;
import net.minecraft.class_3965;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_1838.class)
public interface ItemUsageContextAccessor {

    @Invoker
    class_3965 callGetHitResult();

}
