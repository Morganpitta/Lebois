package io.github.apace100.apoli.condition.type.entity;

import io.github.apace100.apoli.condition.ConditionConfiguration;
import io.github.apace100.apoli.condition.context.EntityConditionContext;
import io.github.apace100.apoli.condition.type.EntityConditionType;
import io.github.apace100.apoli.condition.type.EntityConditionTypes;
import io.github.apace100.apoli.util.MiscUtil;
import net.minecraft.class_1297;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import org.jetbrains.annotations.NotNull;

public class ExposedToSkyEntityConditionType extends EntityConditionType {

    @Override
    public boolean test(EntityConditionContext context) {

        class_1297 entity = context.entity();
        class_1937 world = entity.method_37908();

        return world.method_8311(class_2338.method_49638(MiscUtil.getPoseDependentEyePos(entity)))
            || world.method_8311(entity.method_24515());

    }

    @Override
    public @NotNull ConditionConfiguration<?> getConfig() {
        return EntityConditionTypes.EXPOSED_TO_SKY;
    }

}
