package io.github.apace100.apoli.condition.type.bientity;

import io.github.apace100.apoli.condition.ConditionConfiguration;
import io.github.apace100.apoli.condition.context.BiEntityConditionContext;
import io.github.apace100.apoli.condition.type.BiEntityConditionType;
import io.github.apace100.apoli.condition.type.BiEntityConditionTypes;
import io.github.apace100.apoli.data.TypedDataObjectFactory;
import io.github.apace100.apoli.util.requirement.BiEntityRequirement;
import io.github.apace100.calio.data.SerializableData;
import io.github.apace100.calio.data.SerializableDataTypes;
import net.minecraft.class_1297;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_3959;
import org.jetbrains.annotations.NotNull;

public class CanSeeBiEntityConditionType extends BiEntityConditionType {

    public static final TypedDataObjectFactory<CanSeeBiEntityConditionType> DATA_FACTORY = TypedDataObjectFactory.simple(
        new SerializableData()
            .add("shape_type", SerializableDataTypes.SHAPE_TYPE, class_3959.class_3960.field_23142)
            .add("fluid_handling", SerializableDataTypes.FLUID_HANDLING, class_3959.class_242.field_1348),
        data -> new CanSeeBiEntityConditionType(
            data.get("shape_type"),
            data.get("fluid_handling")
        ),
        (conditionType, serializableData) -> serializableData.instance()
            .set("shape_type", conditionType.shapeType)
            .set("fluid_handling", conditionType.fluidHandling)
    );

    private final class_3959.class_3960 shapeType;
    private final class_3959.class_242 fluidHandling;

    public CanSeeBiEntityConditionType(class_3959.class_3960 shapeType, class_3959.class_242 fluidHandling) {
        this.shapeType = shapeType;
        this.fluidHandling = fluidHandling;
    }

    @Override
    public boolean test(BiEntityConditionContext context) {

        class_1297 actor = context.actor();
        class_1297 target = context.target();

        if (actor.method_37908() != target.method_37908()) {
            return false;
        }

        class_243 actorEyePos = actor.method_33571();
        class_243 targetEyePos = target.method_33571();

        class_3959 raycastContext = new class_3959(actorEyePos, targetEyePos, shapeType, fluidHandling, actor);
        return actor.method_37908().method_17742(raycastContext).method_17783() == class_239.class_240.field_1333;

    }

    @Override
    public BiEntityRequirement getRequirement() {
        return BiEntityRequirement.BOTH;
    }

    @Override
    public @NotNull ConditionConfiguration<?> getConfig() {
        return BiEntityConditionTypes.CAN_SEE;
    }

}
