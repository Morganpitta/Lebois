package io.github.apace100.apoli.condition.type.meta;

import io.github.apace100.apoli.Apoli;
import io.github.apace100.apoli.condition.Condition;
import io.github.apace100.apoli.condition.ConditionConfiguration;
import io.github.apace100.apoli.condition.type.ConditionType;
import io.github.apace100.apoli.util.context.ConditionContext;
import io.github.apace100.calio.data.SerializableData;
import io.github.apace100.calio.data.SerializableDataType;
import io.github.apace100.calio.data.SerializableDataTypes;
import java.util.function.Function;
import net.minecraft.class_5819;

public interface RandomChanceMetaConditionType {

    float chance();

    default boolean testCondition() {
        return class_5819.method_43047().method_43057() < chance();
    }

    static <T extends ConditionContext, C extends Condition<T, CT>, CT extends ConditionType<T, C>, M extends ConditionType<T, C> & RandomChanceMetaConditionType> ConditionConfiguration<M> createConfiguration(Function<Float, M> constructor) {
        return ConditionConfiguration.of(
            Apoli.identifier("random_chance"),
            new SerializableData()
                .add("chance", SerializableDataType.boundNumber(SerializableDataTypes.FLOAT, 0F, 1F)),
            data -> constructor.apply(
                data.get("chance")
            ),
            (m, serializableData) -> serializableData.instance()
                .set("chance", m.chance())
        );
    }

}
