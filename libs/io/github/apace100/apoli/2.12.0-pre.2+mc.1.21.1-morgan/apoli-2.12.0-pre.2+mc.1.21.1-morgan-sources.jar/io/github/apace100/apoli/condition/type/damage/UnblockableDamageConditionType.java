package io.github.apace100.apoli.condition.type.damage;

import io.github.apace100.apoli.condition.ConditionConfiguration;
import io.github.apace100.apoli.condition.type.DamageConditionTypes;
import net.minecraft.class_8103;
import org.jetbrains.annotations.NotNull;

@Deprecated
public class UnblockableDamageConditionType extends InTagDamageConditionType {

	public UnblockableDamageConditionType() {
		super(class_8103.field_43116);
	}

	@Override
	public @NotNull ConditionConfiguration<?> getConfig() {
		return DamageConditionTypes.UNBLOCKABLE;
	}

}
