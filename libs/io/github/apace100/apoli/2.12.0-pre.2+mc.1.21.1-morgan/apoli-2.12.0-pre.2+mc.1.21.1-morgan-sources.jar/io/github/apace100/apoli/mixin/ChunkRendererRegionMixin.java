package io.github.apace100.apoli.mixin;

import io.github.apace100.apoli.component.PowerHolderComponent;
import io.github.apace100.apoli.power.type.ModifyBlockRenderPowerType;
import io.github.apace100.apoli.power.type.ModifyFluidRenderPowerType;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_3610;
import net.minecraft.class_853;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Environment(EnvType.CLIENT)
@Mixin(class_853.class)
public class ChunkRendererRegionMixin {

    @Inject(method = "getBlockState", at = @At("HEAD"), cancellable = true)
    private void modifyBlockRender(class_2338 pos, CallbackInfoReturnable<class_2680> cir) {
        class_310 client = class_310.method_1551();
        if(client.field_1687 != null && client.field_1724 != null) {
            for(ModifyBlockRenderPowerType power : PowerHolderComponent.getPowerTypes(client.field_1724, ModifyBlockRenderPowerType.class)) {
                if(power.doesPrevent(client.field_1687, pos)) {
                    cir.setReturnValue(power.getBlockState());
                    return;
                }
            }
        }
    }

    @Inject(method = "getFluidState", at = @At("HEAD"), cancellable = true)
    private void modifyFluidRender(class_2338 pos, CallbackInfoReturnable<class_3610> cir) {
        class_310 client = class_310.method_1551();
        if(client.field_1687 != null && client.field_1724 != null) {
            for(ModifyFluidRenderPowerType power : PowerHolderComponent.getPowerTypes(client.field_1724, ModifyFluidRenderPowerType.class)) {
                if(power.doesPrevent(client.field_1687, pos)) {
                    cir.setReturnValue(power.getFluidState());
                    return;
                }
            }
        }
    }
}
