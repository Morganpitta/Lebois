package io.github.apace100.apoli.mixin;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import com.llamalad7.mixinextras.injector.v2.WrapWithCondition;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Share;
import com.llamalad7.mixinextras.sugar.ref.LocalBooleanRef;
import com.llamalad7.mixinextras.sugar.ref.LocalIntRef;
import io.github.apace100.apoli.access.PseudoRenderDataHolder;
import io.github.apace100.apoli.component.PowerHolderComponent;
import io.github.apace100.apoli.power.type.*;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

import java.util.List;
import java.util.function.Predicate;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1921;
import net.minecraft.class_3887;
import net.minecraft.class_4050;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_5253;
import net.minecraft.class_5617;
import net.minecraft.class_583;
import net.minecraft.class_897;
import net.minecraft.class_922;
import net.minecraft.class_970;

@Mixin(class_922.class)
public abstract class LivingEntityRendererMixin extends class_897<class_1309> {

    protected LivingEntityRendererMixin(class_5617.class_5618 ctx) {
        super(ctx);
    }

    @ModifyReturnValue(method = "isShaking", at = @At("RETURN"))
    private boolean apoli$letEntitiesShakeTheirBodies(boolean original, class_1309 entity) {
        return original || PowerHolderComponent.hasPowerType(entity, ShakingPowerType.class);
    }

    @ModifyExpressionValue(method = "render(Lnet/minecraft/entity/LivingEntity;FFLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;I)V", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/MinecraftClient;hasOutline(Lnet/minecraft/entity/Entity;)Z"))
    private boolean apoli$preventOutlineWhenInvisible(boolean original, class_1309 entity) {
        return !PowerHolderComponent.hasPowerType(entity, InvisibilityPowerType.class, Predicate.not(InvisibilityPowerType::shouldRenderOutline)) && original;
    }

    @WrapOperation(method = "render(Lnet/minecraft/entity/LivingEntity;FFLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;I)V", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/render/entity/LivingEntityRenderer;getRenderLayer(Lnet/minecraft/entity/LivingEntity;ZZZ)Lnet/minecraft/client/render/RenderLayer;"))
    private class_1921 apoli$useTranslucentRenderLayerWhenVisible(class_922<?, ?> renderer, class_1309 entity, boolean showBody, boolean translucent, boolean showOutline, Operation<class_1921> original) {
        return original.call(renderer, entity, showBody, translucent || showBody && PowerHolderComponent.hasPowerType(entity, ModelColorPowerType.class, ModelColorPowerType::isTranslucent), showOutline);
    }

    @WrapWithCondition(method = "render(Lnet/minecraft/entity/LivingEntity;FFLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;I)V", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/render/entity/feature/FeatureRenderer;render(Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;ILnet/minecraft/entity/Entity;FFFFFF)V"))
    private boolean apoli$preventFeatureRender(class_3887<?, ?> instance, class_4587 matrices, class_4597 vertexConsumers, int light, class_1297 entity, float limbAngle, float limbDistance, float tickDelta, float animationProgress, float headYaw, float headPitch) {
        return (!(instance instanceof class_970<?, ?, ?>) || !PowerHolderComponent.hasPowerType(entity, InvisibilityPowerType.class, Predicate.not(InvisibilityPowerType::shouldRenderArmor)))
            && !PowerHolderComponent.hasPowerType(entity, PreventFeatureRenderPowerType.class, p -> p.doesApply(instance));
    }

    @WrapOperation(method = "render(Lnet/minecraft/entity/LivingEntity;FFLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;I)V", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/render/entity/model/EntityModel;render(Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumer;III)V"))
    private void apoli$renderColorChangedModel(class_583<class_1309> entityModel, class_4587 matrixStack, class_4588 vertexConsumer, int light, int overlay, int argb, Operation<Void> original, class_1309 entity) {

        List<ModelColorPowerType> modelColorPowers = PowerHolderComponent.getPowerTypes(entity, ModelColorPowerType.class);
        if (modelColorPowers.isEmpty()) {
            original.call(entityModel, matrixStack, vertexConsumer, light, overlay, argb);
            return;
        }

        //  TODO: Implement custom blending modes for blending colors -eggohito
        float newRed = modelColorPowers
            .stream()
            .map(ModelColorPowerType::getRed)
            .reduce((float) class_5253.class_5254.method_27765(argb) / 255, (a, b) -> a * b);
        float newGreen = modelColorPowers
            .stream()
            .map(ModelColorPowerType::getGreen)
            .reduce((float) class_5253.class_5254.method_27766(argb) / 255, (a, b) -> a * b);
        float newBlue = modelColorPowers
            .stream()
            .map(ModelColorPowerType::getBlue)
            .reduce((float) class_5253.class_5254.method_27767(argb) / 255, (a, b) -> a * b);

        float oldAlpha = (float) class_5253.class_5254.method_27762(argb) / 255;
        float newAlpha = modelColorPowers
            .stream()
            .map(ModelColorPowerType::getAlpha)
            .min(Float::compareTo)
            .map(alphaFactor -> oldAlpha * alphaFactor)
            .orElse(oldAlpha);

        original.call(entityModel, matrixStack, vertexConsumer, light, overlay, class_5253.class_5254.method_59554(newAlpha, newRed, newGreen, newBlue));

    }

    @ModifyExpressionValue(method = "setupTransforms", at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/LivingEntity;isUsingRiptide()Z"))
    private boolean apoli$forceRiptidePose(boolean original, class_1309 entity) {
        return original || PosePowerType.hasEntityPose(entity, class_4050.field_18080);
    }

    @ModifyExpressionValue(method = "setupTransforms", at = @At(value = "FIELD", target = "Lnet/minecraft/entity/LivingEntity;deathTime:I", ordinal = 0))
    private int apoli$forceDyingPose(int original, class_1309 entity, @Share("applyPseudoDeathTicks") LocalBooleanRef applyPseudoDeathTicksRef, @Share("pseudoDeathTicks") LocalIntRef pseudoDeathTicksRef) {

        if (original > 0 || !(entity instanceof PseudoRenderDataHolder renderData)) {
            return original;
        }

        int pseudoDeathTicks = renderData.apoli$getPseudoDeathTicks();

        pseudoDeathTicksRef.set(pseudoDeathTicks);
        applyPseudoDeathTicksRef.set(pseudoDeathTicks > 0);

        return pseudoDeathTicks;

    }

    @ModifyExpressionValue(method = "setupTransforms", at = @At(value = "FIELD", target = "Lnet/minecraft/entity/LivingEntity;deathTime:I", ordinal = 1))
    private int apoli$applyPseudoDeathTicks(int original, class_1309 entity, @Share("applyPseudoDeathTicks") LocalBooleanRef applyPseudoDeathTicksRef, @Share("pseudoDeathTicks") LocalIntRef pseudoDeathTicksRef) {
        return applyPseudoDeathTicksRef.get()
            ? pseudoDeathTicksRef.get()
            : original;
    }

}
