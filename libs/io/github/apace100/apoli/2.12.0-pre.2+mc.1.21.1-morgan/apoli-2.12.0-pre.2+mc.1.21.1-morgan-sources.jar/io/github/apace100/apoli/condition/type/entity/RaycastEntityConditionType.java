package io.github.apace100.apoli.condition.type.entity;

import io.github.apace100.apoli.condition.BiEntityCondition;
import io.github.apace100.apoli.condition.BlockCondition;
import io.github.apace100.apoli.condition.ConditionConfiguration;
import io.github.apace100.apoli.condition.context.EntityConditionContext;
import io.github.apace100.apoli.condition.type.EntityConditionType;
import io.github.apace100.apoli.condition.type.EntityConditionTypes;
import io.github.apace100.apoli.data.ApoliDataTypes;
import io.github.apace100.apoli.data.TypedDataObjectFactory;
import io.github.apace100.apoli.util.MiscUtil;
import io.github.apace100.apoli.util.Space;
import io.github.apace100.calio.data.SerializableData;
import io.github.apace100.calio.data.SerializableDataTypes;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.joml.Vector3f;

import java.util.Optional;
import java.util.function.Predicate;
import net.minecraft.class_1297;
import net.minecraft.class_1301;
import net.minecraft.class_1675;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_3966;
import net.minecraft.class_5134;

public class RaycastEntityConditionType extends EntityConditionType {

    public static final TypedDataObjectFactory<RaycastEntityConditionType> DATA_FACTORY = TypedDataObjectFactory.simple(
        new SerializableData()
            .add("match_bientity_condition", BiEntityCondition.DATA_TYPE.optional(), Optional.empty())
            .add("hit_bientity_condition", BiEntityCondition.DATA_TYPE.optional(), Optional.empty())
            .add("block_condition", BlockCondition.DATA_TYPE.optional(), Optional.empty())
            .add("shape_type", SerializableDataTypes.SHAPE_TYPE, class_3959.class_3960.field_17559)
            .add("fluid_handling", SerializableDataTypes.FLUID_HANDLING, class_3959.class_242.field_1347)
            .add("direction", SerializableDataTypes.VECTOR.optional(), Optional.empty())
            .add("space", ApoliDataTypes.SPACE, Space.WORLD)
            .add("entity_distance", SerializableDataTypes.POSITIVE_DOUBLE.optional(), Optional.empty())
            .add("block_distance", SerializableDataTypes.POSITIVE_DOUBLE.optional(), Optional.empty())
            .add("distance", SerializableDataTypes.POSITIVE_DOUBLE.optional(), Optional.empty())
            .add("entity", SerializableDataTypes.BOOLEAN, true)
            .add("block", SerializableDataTypes.BOOLEAN, true),
        data -> new RaycastEntityConditionType(
            data.get("match_bientity_condition"),
            data.get("hit_bientity_condition"),
            data.get("block_condition"),
            data.get("shape_type"),
            data.get("fluid_handling"),
            data.get("direction"),
            data.get("space"),
            data.get("entity_distance"),
            data.get("block_distance"),
            data.get("distance"),
            data.get("entity"),
            data.get("block")
        ),
        (conditionType, serializableData) -> serializableData.instance()
            .set("match_bientity_condition", conditionType.matchBiEntityCondition)
            .set("hit_bientity_condition", conditionType.hitBiEntityCondition)
            .set("block_condition", conditionType.blockCondition)
            .set("shape_type", conditionType.shapeType)
            .set("fluid_handling", conditionType.fluidHandling)
            .set("direction", conditionType.direction)
            .set("space", conditionType.space)
            .set("entity_distance", conditionType.entityDistance)
            .set("block_distance", conditionType.blockDistance)
            .set("distance", conditionType.distance)
            .set("entity", conditionType.entity)
            .set("block", conditionType.block)
    );

    private final Optional<BiEntityCondition> matchBiEntityCondition;
    private final Optional<BiEntityCondition> hitBiEntityCondition;

    private final Optional<BlockCondition> blockCondition;

    private final class_3959.class_3960 shapeType;
    private final class_3959.class_242 fluidHandling;

    private final Optional<class_243> direction;
    private final Space space;

    private final Optional<Double> entityDistance;
    private final Optional<Double> blockDistance;
    private final Optional<Double> distance;

    private final boolean entity;
    private final boolean block;

    public RaycastEntityConditionType(Optional<BiEntityCondition> matchBiEntityCondition, Optional<BiEntityCondition> hitBiEntityCondition, Optional<BlockCondition> blockCondition, class_3959.class_3960 shapeType, class_3959.class_242 fluidHandling, Optional<class_243> direction, Space space, Optional<Double> entityDistance, Optional<Double> blockDistance, Optional<Double> distance, boolean entity, boolean block) {
        this.matchBiEntityCondition = matchBiEntityCondition;
        this.hitBiEntityCondition = hitBiEntityCondition;
        this.blockCondition = blockCondition;
        this.shapeType = shapeType;
        this.fluidHandling = fluidHandling;
        this.direction = direction;
        this.space = space;
        this.entityDistance = entityDistance;
        this.blockDistance = blockDistance;
        this.distance = distance;
        this.entity = entity;
        this.block = block;
    }

    @Override
    public boolean test(EntityConditionContext context) {

        Entity entity = context.entity();

        Vec3d origin = MiscUtil.getPoseDependentEyePos(entity);
        Vec3d direction = this.direction
            .map(dir -> transformDirection(entity, dir))
            .orElseGet(() -> entity.getRotationVec(1.0F));

        Vec3d destination;
        HitResult hitResult = null;

        if (this.entity) {

            double distance = getEntityReach(entity);
            destination = origin.add(direction.multiply(distance));

            hitResult = entityRaycast(entity, origin, destination);

        }

        if (this.block) {

            double distance = getBlockReach(entity);
            destination = origin.add(direction.multiply(distance));

            BlockHitResult blockResult = blockRaycast(entity, origin, destination);

            if (blockResult.getType() != HitResult.Type.MISS && overrideHitResult(entity, hitResult, blockResult)) {
                hitResult = blockResult;
            }

        }

        if (hitResult == null || hitResult.getType() == HitResult.Type.MISS) {
            return false;
        }

        return switch (hitResult) {
            case BlockHitResult blockResult when blockCondition.isPresent() ->
                blockCondition.get().test(entity.getWorld(), blockResult.getBlockPos());
            case EntityHitResult entityResult when hitBiEntityCondition.isPresent() ->
                hitBiEntityCondition.get().test(entity, entityResult.getEntity());
            default ->
                true;  // unsupported
        };

    }

    @Override
    public @NotNull ConditionConfiguration<?> getConfig() {
        return EntityConditionTypes.RAYCAST;
    }

    private class_3966 entityRaycast(class_1297 caster, class_243 origin, class_243 destination) {

        class_243 ray = destination.method_1020(origin);
        class_238 box = caster.method_5829().method_18804(ray).method_1014(1.0D);

        Predicate<class_1297> intersectPredicate = class_1301.field_6155
            .and(intersected -> matchBiEntityCondition
                .map(condition -> condition.test(caster, intersected))
                .orElse(true));

        return class_1675.method_18075(
            caster,
            origin,
            destination,
            box,
            intersectPredicate,
            ray.method_1027()
        );

    }

    private class_3965 blockRaycast(class_1297 caster, class_243 origin, class_243 destination) {
        class_3959 context = new class_3959(origin, destination, shapeType, fluidHandling, caster);
        return caster.method_37908().method_17742(context);
    }

    private class_243 transformDirection(class_1297 entity, class_243 direction) {

        Vector3f normalizedDirection = new Vector3f((float) direction.method_10216(), (float) direction.method_10214(), (float) direction.method_10215()).normalize();
        space.toGlobal(normalizedDirection, entity);

        return new class_243(normalizedDirection);

    }

    private static boolean overrideHitResult(class_1297 caster, @Nullable class_239 prev, class_239 next) {
        return prev == null
            || prev.method_17783() == class_239.class_240.field_1333
            || prev.method_24801(caster) > next.method_24801(caster);
    }

    private double getEntityReach(class_1297 entity) {
        return entityDistance
            .or(() -> distance)
            .orElseGet(() -> MiscUtil.getAttributeValueOrElse(entity, class_5134.field_47759, 1.0));
    }

    private double getBlockReach(class_1297 entity) {
        return blockDistance
            .or(() -> distance)
            .orElseGet(() -> MiscUtil.getAttributeValueOrElse(entity, class_5134.field_47758, 1.0));
    }

}
