package io.github.apace100.apoli.mixin;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import io.github.apace100.apoli.access.OwnableAttributeContainer;
import io.github.apace100.apoli.access.OwnableAttributeInstance;
import net.minecraft.class_1297;
import net.minecraft.class_1324;
import net.minecraft.class_5132;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_5132.class)
public abstract class DefaultAttributeContainerMixin implements OwnableAttributeContainer {

    @Unique
    private final ThreadLocal<class_1297> apoli$owner = new ThreadLocal<>();

    @Override
    @Nullable
    public class_1297 apoli$getOwner() {
        return apoli$owner.get();
    }

    @Override
    public void apoli$setOwner(class_1297 owner) {
        this.apoli$owner.set(owner);
    }

    @ModifyExpressionValue(method = "getValue", at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/attribute/DefaultAttributeContainer;require(Lnet/minecraft/registry/entry/RegistryEntry;)Lnet/minecraft/entity/attribute/EntityAttributeInstance;"))
    private class_1324 apoli$setAttributeInstanceOwner(class_1324 original) {

        if (original instanceof OwnableAttributeInstance ownableAttributeInstance) {
            ownableAttributeInstance.apoli$setOwner(this.apoli$getOwner());
        }

        return original;

    }

}
