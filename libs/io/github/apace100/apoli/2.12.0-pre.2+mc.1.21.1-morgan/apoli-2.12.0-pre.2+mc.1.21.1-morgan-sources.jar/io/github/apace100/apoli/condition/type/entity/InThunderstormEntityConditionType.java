package io.github.apace100.apoli.condition.type.entity;

import io.github.apace100.apoli.condition.ConditionConfiguration;
import io.github.apace100.apoli.condition.context.EntityConditionContext;
import io.github.apace100.apoli.condition.type.EntityConditionType;
import io.github.apace100.apoli.condition.type.EntityConditionTypes;
import io.github.apace100.apoli.util.MiscUtil;
import io.github.apace100.apoli.util.WorldUtil;
import net.minecraft.class_1297;
import net.minecraft.class_2338;
import org.jetbrains.annotations.NotNull;

public class InThunderstormEntityConditionType extends EntityConditionType {

	@Override
	public boolean test(EntityConditionContext context) {
		class_1297 entity = context.entity();
		return WorldUtil.inThunderstorm(entity.method_37908(), class_2338.method_49638(MiscUtil.getPoseDependentEyePos(entity)), entity.method_24515());
	}

	@Override
	public @NotNull ConditionConfiguration<?> getConfig() {
		return EntityConditionTypes.IN_THUNDERSTORM;
	}

}
