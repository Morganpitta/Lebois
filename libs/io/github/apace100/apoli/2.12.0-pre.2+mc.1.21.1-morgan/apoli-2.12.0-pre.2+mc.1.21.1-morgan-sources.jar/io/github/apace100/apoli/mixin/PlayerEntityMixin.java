package io.github.apace100.apoli.mixin;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import com.llamalad7.mixinextras.injector.v2.WrapWithCondition;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Share;
import com.llamalad7.mixinextras.sugar.ref.LocalRef;
import io.github.apace100.apoli.access.JumpingEntity;
import io.github.apace100.apoli.access.ModifiableFoodEntity;
import io.github.apace100.apoli.access.ModifiedPoseHolder;
import io.github.apace100.apoli.component.PowerHolderComponent;
import io.github.apace100.apoli.networking.packet.s2c.DismountPlayerS2CPacket;
import io.github.apace100.apoli.power.type.*;
import io.github.apace100.apoli.util.ActionResultUtil;
import io.github.apace100.apoli.util.InventoryUtil;
import io.github.apace100.apoli.util.PriorityPhase;
import io.github.apace100.apoli.util.modifier.Modifier;
import io.github.apace100.apoli.util.modifier.ModifierUtil;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1275;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1313;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1702;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2165;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2749;
import net.minecraft.class_3222;
import net.minecraft.class_4174;
import net.minecraft.class_5630;
import net.minecraft.class_8103;
import net.minecraft.entity.*;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.Slice;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.List;

@Mixin(value = class_1657.class, priority = 999)
public abstract class PlayerEntityMixin extends class_1309 implements class_1275, class_2165, JumpingEntity, ModifiedPoseHolder {

    @Shadow
    public abstract boolean method_5643(class_1282 source, float amount);

    @Shadow
    public abstract class_1799 method_6118(class_1304 slot);

    @Shadow
    @Final
    class_1661 inventory;

    protected PlayerEntityMixin(class_1299<? extends class_1309> entityType, class_1937 world) {
        super(entityType, world);
    }

    @Inject(method = "getOffGroundSpeed", at = @At("RETURN"), cancellable = true)
    private void modifyFlySpeed(CallbackInfoReturnable<Float> cir) {
        cir.setReturnValue(PowerHolderComponent.modify(this, ModifyAirSpeedPowerType.class, cir.getReturnValue()));
    }

    @ModifyVariable(method = "eatFood", at = @At("HEAD"), argsOnly = true)
    private class_1799 apoli$modifyEatenStack(class_1799 original) {

        class_5630 newStackRef = InventoryUtil.createStackReference(original);
        ModifiableFoodEntity modifiableFoodEntity = (ModifiableFoodEntity) this;

        List<ModifyFoodPowerType> modifyFoodPowers = PowerHolderComponent.getPowerTypes(this, ModifyFoodPowerType.class)
            .stream()
            .filter(mfp -> mfp.doesApply(original))
            .toList();

        for (ModifyFoodPowerType modifyFoodPower : modifyFoodPowers) {
            modifyFoodPower.setConsumedItemStackReference(newStackRef);
        }

        EdibleItemPowerType.get(original.method_7972(), this).ifPresent(modifiableFoodEntity::apoli$setEdibleItemPower);

        modifiableFoodEntity.apoli$setCurrentModifyFoodPowers(modifyFoodPowers);
        modifiableFoodEntity.apoli$setOriginalFoodStack(original);

        return newStackRef.method_32327();

    }

    @Unique
    private boolean apoli$updateStatsManually = false;

    @ModifyVariable(method = "eatFood", at = @At("HEAD"), argsOnly = true)
    private class_4174 apoli$modifyFoodComponent(class_4174 original, class_1937 world, class_1799 stack, @Share("modifyFoodPowers") LocalRef<List<ModifyFoodPowerType>> sharedModifyFoodPowers) {

        List<ModifyFoodPowerType> modifyFoodPowers = ((ModifiableFoodEntity) this).apoli$getCurrentModifyFoodPowers()
            .stream()
            .filter(p -> p.doesApply(stack))
            .toList();

        sharedModifyFoodPowers.set(modifyFoodPowers);
        this.apoli$updateStatsManually = false;

        List<Modifier> nutritionModifiers = modifyFoodPowers
            .stream()
            .flatMap(p -> p.getFoodModifiers().stream())
            .toList();
        List<Modifier> saturationModifiers = modifyFoodPowers
            .stream()
            .flatMap(p -> p.getSaturationModifiers().stream())
            .toList();

        int oldNutrition = original.comp_2491();
        float oldSaturation = original.comp_2492();

        int newNutrition = (int) ModifierUtil.applyModifiers(this, nutritionModifiers, oldNutrition);
        float newSaturation = (float) ModifierUtil.applyModifiers(this, saturationModifiers, oldSaturation);

        if (newNutrition != oldNutrition || newSaturation != oldSaturation) {
            this.apoli$updateStatsManually = true;
        }

        return new class_4174(
            newNutrition,
            newSaturation,
            original.comp_2493(),
            original.comp_2494(),
            original.comp_2794(),
            original.comp_2495()
        );

    }

    @Inject(method = "eatFood", at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/player/HungerManager;eat(Lnet/minecraft/component/type/FoodComponent;)V", shift = At.Shift.AFTER))
    private void apoli$executeActionsAfterEating(class_1937 world, class_1799 stack, class_4174 foodComponent, CallbackInfoReturnable<class_1799> cir, @Share("modifyFoodPowers") LocalRef<List<ModifyFoodPowerType>> sharedModifyFoodPowers) {

        List<ModifyFoodPowerType> modifyFoodPowers = sharedModifyFoodPowers.get();
        if (!((class_1657) (Object) this instanceof class_3222 serverPlayer) || modifyFoodPowers == null) {
            return;
        }

        modifyFoodPowers.forEach(ModifyFoodPowerType::eat);
        if (apoli$updateStatsManually) {
            class_1702 hungerManager = serverPlayer.method_7344();
            serverPlayer.field_13987.method_14364(new class_2749(this.method_6032(), hungerManager.method_7586(), hungerManager.method_7589()));
        }

    }

    @Inject(method = "damage", at = @At(value = "RETURN", ordinal = 3), cancellable = true)
    private void allowDamageIfModifyingPowersExist(class_1282 source, float amount, CallbackInfoReturnable<Boolean> cir) {

        boolean hasModifyingPower = false;

        if (source.method_5529() != null) {
            if (source.method_48789(class_8103.field_42247)) hasModifyingPower = PowerHolderComponent.hasPowerType(source.method_5529(), ModifyProjectileDamagePowerType.class, mpdp -> mpdp.doesApply(source, amount, this));
            else hasModifyingPower = PowerHolderComponent.hasPowerType(source.method_5529(), ModifyDamageDealtPowerType.class, mddp -> mddp.doesApply(source, amount, this));
        }

        hasModifyingPower |= PowerHolderComponent.hasPowerType(this, ModifyDamageTakenPowerType.class, mdtp -> mdtp.doesApply(source, amount));
        if (hasModifyingPower) cir.setReturnValue(super.method_5643(source, amount));

    }

    @Inject(method = "dismountVehicle", at = @At("HEAD"))
    private void apoli$sendPlayerDismountPacket(CallbackInfo ci) {
        if (this.method_5854() instanceof class_3222 player) {
            ServerPlayNetworking.send(player, new DismountPlayerS2CPacket(this.method_5628()));
        }
    }

    @Inject(method = "updateSwimming", at = @At("TAIL"))
    private void updateSwimmingPower(CallbackInfo ci) {
        if(PowerHolderComponent.hasPowerType(this, SwimmingPowerType.class)) {
            this.method_5796(this.method_5624() && !this.method_5765());
            this.field_5957 = this.method_5681();
            if (this.method_5681()) {
                this.field_6017 = 0.0F;
                class_243 look = this.method_5720();
                method_5784(class_1313.field_6308, new class_243(look.field_1352/4, look.field_1351/4, look.field_1350/4));
            }
        } else if(PowerHolderComponent.hasPowerType(this, IgnoreWaterPowerType.class)) {
            this.method_5796(false);
        }
    }

    @Inject(method = "wakeUp(ZZ)V", at = @At("HEAD"))
    private void invokeWakeUpAction(boolean bl, boolean updateSleepingPlayers, CallbackInfo ci) {
        if(!bl && !updateSleepingPlayers && method_18398().isPresent()) {
            class_2338 sleepingPos = method_18398().get();
            PowerHolderComponent.getPowerTypes(this, ActionOnWakeUpPowerType.class).stream().filter(p -> p.doesApply(sleepingPos)).forEach(p -> p.executeActions(sleepingPos, class_2350.field_11033));
        }
    }

    // Prevent healing if DisableRegenPower
    // Note that this function was called "shouldHeal" instead of "canFoodHeal" at some point in time.
    @ModifyReturnValue(method = "canFoodHeal", at = @At("RETURN"))
    private boolean apoli$disableFoodRegen(boolean original) {
        return original
            && !PowerHolderComponent.hasPowerType(this, DisableRegenPowerType.class);
    }

    // ModifyExhaustion
    @ModifyVariable(at = @At("HEAD"), method = "addExhaustion", argsOnly = true)
    private float modifyExhaustion(float exhaustionIn) {
        return PowerHolderComponent.modify(this, ModifyExhaustionPowerType.class, exhaustionIn);
    }

    @Inject(method = "dropInventory", at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/player/PlayerInventory;dropAll()V"))
    private void dropAdditionalInventory(CallbackInfo ci) {
        PowerHolderComponent.withPowerTypes(this, InventoryPowerType.class, InventoryPowerType::shouldDropOnDeath, InventoryPowerType::dropItemsOnDeath);
        PowerHolderComponent.withPowerTypes(this, KeepInventoryPowerType.class, p -> true, KeepInventoryPowerType::preventItemsFromDropping);
    }

    @Inject(method = "dropInventory", at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/player/PlayerInventory;dropAll()V", shift = At.Shift.AFTER))
    private void restoreKeptInventory(CallbackInfo ci) {
        PowerHolderComponent.withPowerTypes(this, KeepInventoryPowerType.class, p -> true, KeepInventoryPowerType::restoreSavedItems);
    }

    @ModifyReturnValue(method = "canEquip", at = @At("RETURN"))
    private boolean apoli$preventArmorDispensing(boolean original, class_1799 stack) {
        return original
            && !PowerHolderComponent.hasPowerType(this, RestrictArmorPowerType.class, p -> p.doesRestrict(stack, this.method_32326(stack)));
    }

    @WrapOperation(method = "interact", at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/Entity;interact(Lnet/minecraft/entity/player/PlayerEntity;Lnet/minecraft/util/Hand;)Lnet/minecraft/util/ActionResult;"))
    private class_1269 apoli$beforeEntityUse(class_1297 entity, class_1657 player, class_1268 hand, Operation<class_1269> original, @Share("zeroPriority$onEntity") LocalRef<class_1269> sharedZeroPriority$onEntity) {

        class_1799 stackInHand = player.method_5998(hand);
        for (PreventEntityUsePowerType peup : PowerHolderComponent.getPowerTypes(this, PreventEntityUsePowerType.class)) {

            if (peup.doesApply(entity, hand, stackInHand)) {
                return peup.executeAction(entity, hand);
            }

        }

        for (PreventBeingUsedPowerType pbup : PowerHolderComponent.getPowerTypes(entity, PreventBeingUsedPowerType.class)) {

            if (pbup.doesApply(player, hand, stackInHand)) {
                return pbup.executeAction(player, hand);
            }

        }

        Prioritized.CallInstance<ActiveInteractionPowerType> aipci = new Prioritized.CallInstance<>();

        aipci.add(player, ActionOnEntityUsePowerType.class, p -> p.shouldExecute(entity, hand, stackInHand, PriorityPhase.BEFORE));
        aipci.add(entity, ActionOnBeingUsedPowerType.class, p -> p.shouldExecute(player, hand, stackInHand, PriorityPhase.BEFORE));

        for (int i = aipci.getMaxPriority(); i >= aipci.getMinPriority(); i--) {

            if (!aipci.hasPowerTypes(i)) {
                continue;
            }

            List<ActiveInteractionPowerType> aips = aipci.getPowerTypes(i);
            class_1269 previousResult = class_1269.field_5811;

            for (ActiveInteractionPowerType aip : aips) {

                class_1269 currentResult = class_1269.field_5811;
                if (aip instanceof ActionOnEntityUsePowerType aoeup) {
                    currentResult = aoeup.executeAction(entity, hand);
                }

                else if (aip instanceof ActionOnBeingUsedPowerType aobup) {
                    currentResult = aobup.executeAction(player, hand);
                }

                if (ActionResultUtil.shouldOverride(previousResult, currentResult)) {
                    previousResult = currentResult;
                }

            }

            if (i == 0) {
                sharedZeroPriority$onEntity.set(previousResult);
                continue;
            }

            if (previousResult == class_1269.field_5811) {
                continue;
            }

            if (previousResult.method_23666()) {
                this.method_6104(hand);
            }

            return previousResult;

        }

        return original.call(entity, player, hand);

    }

    @ModifyReturnValue(method = "interact", at = @At("RETURN"), slice = @Slice(from = @At(value = "INVOKE", target = "Lnet/minecraft/entity/player/PlayerEntity;getStackInHand(Lnet/minecraft/util/Hand;)Lnet/minecraft/item/ItemStack;", ordinal = 0)))
    private class_1269 apoli$afterEntityUse(class_1269 original, class_1297 entity, class_1268 hand, @Share("zeroPriority$onEntity") LocalRef<class_1269> sharedZeroPriority$onEntity) {

        class_1269 cachedPriorityZeroResult = sharedZeroPriority$onEntity.get();
        class_1269 newResult = class_1269.field_5811;

        if (cachedPriorityZeroResult != null && cachedPriorityZeroResult != class_1269.field_5811) {
            newResult = cachedPriorityZeroResult;
        }

        else if (original == class_1269.field_5811) {

            class_1799 stackInHand = this.method_5998(hand);
            Prioritized.CallInstance<ActiveInteractionPowerType> aipci = new Prioritized.CallInstance<>();

            aipci.add(this, ActionOnEntityUsePowerType.class, p -> p.shouldExecute(entity, hand, stackInHand, PriorityPhase.AFTER));
            aipci.add(entity, ActionOnBeingUsedPowerType.class, p -> p.shouldExecute((class_1657) (Object) this, hand, stackInHand, PriorityPhase.AFTER));

            for (int i = aipci.getMaxPriority(); i >= aipci.getMinPriority(); i--) {

                if (!aipci.hasPowerTypes(i)) {
                    continue;
                }

                List<ActiveInteractionPowerType> aips = aipci.getPowerTypes(i);
                class_1269 previousResult = class_1269.field_5811;

                for (ActiveInteractionPowerType aip : aips) {

                    class_1269 currentResult = class_1269.field_5811;
                    if (aip instanceof ActionOnEntityUsePowerType aoeup) {
                        currentResult = aoeup.executeAction(entity, hand);
                    }

                    else if (aip instanceof ActionOnBeingUsedPowerType aobup) {
                        currentResult = aobup.executeAction((class_1657) (Object) this, hand);
                    }

                    if (ActionResultUtil.shouldOverride(previousResult, currentResult)) {
                        previousResult = currentResult;
                    }

                }

                if (previousResult != class_1269.field_5811) {
                    newResult = previousResult;
                    break;
                }

            }

        }

        if (newResult.method_23666()) {
            this.method_6104(hand);
        }

        return ActionResultUtil.shouldOverride(original, newResult)
            ? newResult
            : original;

    }

    @ModifyExpressionValue(method = "jump", at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/player/PlayerEntity;isSprinting()Z"))
    private boolean apoli$shouldApplySprintJumpExhaustion(boolean original) {
        return original && this.apoli$applySprintJumpEffects();
    }

    @WrapWithCondition(method = "tick", at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/player/PlayerEntity;updatePose()V"))
    private boolean apoli$preventUpdatingPose(class_1657 player) {
        return this.apoli$getModifiedEntityPose().isEmpty();
    }

}
