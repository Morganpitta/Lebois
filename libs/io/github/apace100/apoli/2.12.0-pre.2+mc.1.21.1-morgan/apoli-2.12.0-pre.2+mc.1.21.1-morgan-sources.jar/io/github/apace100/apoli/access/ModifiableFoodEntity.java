package io.github.apace100.apoli.access;

import io.github.apace100.apoli.power.type.EdibleItemPowerType;
import io.github.apace100.apoli.power.type.ModifyFoodPowerType;
import java.util.List;
import net.minecraft.class_1799;

public interface ModifiableFoodEntity {

    class_1799 apoli$getOriginalFoodStack();
    void apoli$setOriginalFoodStack(class_1799 original);

    List<ModifyFoodPowerType> apoli$getCurrentModifyFoodPowers();
    void apoli$setCurrentModifyFoodPowers(List<ModifyFoodPowerType> powers);

    EdibleItemPowerType apoli$getEdibleItemPower();
    void apoli$setEdibleItemPower(EdibleItemPowerType power);

}
