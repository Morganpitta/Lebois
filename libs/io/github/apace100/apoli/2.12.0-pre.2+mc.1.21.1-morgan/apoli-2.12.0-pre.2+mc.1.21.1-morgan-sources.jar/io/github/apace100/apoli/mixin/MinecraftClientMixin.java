package io.github.apace100.apoli.mixin;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import io.github.apace100.apoli.access.OverlaySpriteHolder;
import io.github.apace100.apoli.component.PowerHolderComponent;
import io.github.apace100.apoli.integration.PostLoadTexturesCallback;
import io.github.apace100.apoli.internal.InternalClient;
import io.github.apace100.apoli.power.type.EntityGlowPowerType;
import io.github.apace100.apoli.power.type.OverlayPowerType;
import io.github.apace100.apoli.power.type.SelfGlowPowerType;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1058;
import net.minecraft.class_1060;
import net.minecraft.class_1297;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3304;
import net.minecraft.class_542;
import net.minecraft.class_638;
import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(EnvType.CLIENT)
@Mixin(class_310.class)
public abstract class MinecraftClientMixin implements OverlaySpriteHolder {

    @Shadow
    public class_746 player;

    @Shadow
    @Final
    private class_3304 resourceManager;

    @Shadow
    public abstract boolean isFinishedLoading();

    @Shadow
    public abstract class_1060 getTextureManager();

    @ModifyReturnValue(method = "hasOutline", at = @At("RETURN"))
    private boolean apoli$makeEntitiesGlow(boolean original, class_1297 entity) {
        return original
            || (player != entity && PowerHolderComponent.hasPowerType(player, EntityGlowPowerType.class, p -> p.doesApply(entity)))
            || PowerHolderComponent.hasPowerType(entity, SelfGlowPowerType.class, p -> p.doesApply(player));
    }

    @Unique
    private OverlayPowerType.SpriteHolder apoli$overlaySpriteHolder;

    @Override
    public class_1058 apoli$getSprite(class_2960 id) {
        return apoli$overlaySpriteHolder.method_18667(id);
    }

    @Inject(method = "<init>", at = @At(value = "NEW", target = "(Lnet/minecraft/client/MinecraftClient;)Lnet/minecraft/client/gui/hud/InGameHud;"))
    private void apoli$registerCustomAtlases(class_542 args, CallbackInfo ci) {
        this.apoli$overlaySpriteHolder = new OverlayPowerType.SpriteHolder(this.getTextureManager());
        this.resourceManager.method_14477(apoli$overlaySpriteHolder);
    }

    @Inject(method = "onFinishedLoading", at = @At("HEAD"))
    private void apoli$postReloadTextures(class_310.class_8764 loadingContext, CallbackInfo ci) {
        PostLoadTexturesCallback.EVENT.invoker().onPostLoad((class_310) (Object) this, this.isFinishedLoading());
    }

    @Inject(method = "setWorld", at = @At("HEAD"))
    private void apoli$onJoinWorld(class_638 world, CallbackInfo ci) {
        InternalClient.onClientWorldChanged();
    }
}
