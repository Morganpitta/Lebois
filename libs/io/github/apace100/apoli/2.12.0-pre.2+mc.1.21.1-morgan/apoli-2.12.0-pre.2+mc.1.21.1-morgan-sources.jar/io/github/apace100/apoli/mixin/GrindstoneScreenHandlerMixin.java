package io.github.apace100.apoli.mixin;

import com.llamalad7.mixinextras.sugar.Local;
import io.github.apace100.apoli.access.PowerModifiedGrindstone;
import io.github.apace100.apoli.component.PowerHolderComponent;
import io.github.apace100.apoli.power.type.ModifyGrindstonePowerType;
import io.github.apace100.apoli.util.InventoryUtil;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.LinkedList;
import java.util.List;
import java.util.stream.Collectors;
import net.minecraft.class_1263;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_3803;
import net.minecraft.class_3914;
import net.minecraft.class_3917;
import net.minecraft.class_5630;

@Mixin(class_3803.class)
public abstract class GrindstoneScreenHandlerMixin extends class_1703 implements PowerModifiedGrindstone {

    @Shadow
    @Final
    class_1263 input;

    @Shadow
    @Final
    private class_1263 result;

    @Shadow
    @Final
    public static int INPUT_1_ID;

    @Shadow
    @Final
    public static int INPUT_2_ID;

    @Shadow
    @Final
    public static int OUTPUT_ID;

    @Shadow
    @Final
    private class_3914 context;

    @Unique
    private class_1657 apoli$cachedPlayer;

    @Unique
    private List<ModifyGrindstonePowerType> apoli$appliedPowers;

    private GrindstoneScreenHandlerMixin(@Nullable class_3917<?> type, int syncId) {
        super(type, syncId);
    }

    @Inject(method = "<init>(ILnet/minecraft/entity/player/PlayerInventory;Lnet/minecraft/screen/ScreenHandlerContext;)V", at = @At("RETURN"))
    private void cachePlayer(int syncId, class_1661 playerInventory, class_3914 context, CallbackInfo ci) {
        apoli$cachedPlayer = playerInventory.field_7546;
    }

    @Inject(method = "updateResult", at = @At("RETURN"))
    private void modifyResult(CallbackInfo ci) {

        class_1799 topStack = input.method_5438(INPUT_1_ID);
        class_1799 bottomStack = input.method_5438(INPUT_2_ID);

        class_5630 outputStackRef = InventoryUtil.createStackReference(result.method_5438(0));
        this.apoli$appliedPowers = PowerHolderComponent.getPowerTypes(apoli$cachedPlayer, ModifyGrindstonePowerType.class)
            .stream()
            .filter(mgp -> mgp.doesApply(topStack, bottomStack, outputStackRef.method_32327(), apoli$getPos()))
            .peek(mgp -> mgp.setOutput(topStack, bottomStack, outputStackRef))
            .collect(Collectors.toCollection(LinkedList::new));

        result.method_5447(0, outputStackRef.method_32327());
        this.method_7623();

    }

    @ModifyVariable(method = "quickMove", at = @At(value = "INVOKE", target = "Lnet/minecraft/item/ItemStack;copy()Lnet/minecraft/item/ItemStack;"), ordinal = 1)
    private class_1799 performAfterGrindstoneActionsQuickMove(class_1799 original, class_1657 player, int slotIndex, @Local class_1735 slot) {

        List<ModifyGrindstonePowerType> applyingPowers = this.apoli$getAppliedPowers();
        class_5630 stackReference = InventoryUtil.createStackReference(original);

        if (slotIndex != OUTPUT_ID || applyingPowers == null || applyingPowers.isEmpty()) {
            return original;
        }

        class_1799 copy = original.method_7972();
        applyingPowers.forEach(mgpt -> mgpt.executeActions(this.apoli$getPos(), stackReference));

        if (stackReference.method_32327().method_7960()) {
            this.method_7611(slotIndex).method_7667(player, copy);
        }

        return stackReference.method_32327();

    }

    @Override
    public List<ModifyGrindstonePowerType> apoli$getAppliedPowers() {
        return apoli$appliedPowers;
    }

    @Override
    public class_1657 apoli$getPlayer() {
        return apoli$cachedPlayer;
    }

    @Nullable
    @Override
    public class_2338 apoli$getPos() {
        return this.context.method_17396((world, pos) -> pos, null);
    }

}
