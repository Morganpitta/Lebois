package io.github.apace100.apoli.component;

import com.google.common.collect.Lists;
import io.github.apace100.apoli.Apoli;
import io.github.apace100.apoli.integration.ModifyValueCallback;
import io.github.apace100.apoli.networking.packet.s2c.SyncBulkPowerDataS2CPacket;
import io.github.apace100.apoli.networking.packet.s2c.SyncPowerDataS2CPacket;
import io.github.apace100.apoli.power.Power;
import io.github.apace100.apoli.power.PowerManager;
import io.github.apace100.apoli.power.PowerReference;
import io.github.apace100.apoli.power.type.PowerType;
import io.github.apace100.apoli.power.type.ValueModifyingPowerType;
import io.github.apace100.apoli.util.modifier.Modifier;
import io.github.apace100.apoli.util.modifier.ModifierUtil;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import net.fabricmc.fabric.api.networking.v1.PlayerLookup;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_1297;
import net.minecraft.class_2487;
import net.minecraft.class_2520;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_9129;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.ladysnake.cca.api.v3.component.ComponentKey;
import org.ladysnake.cca.api.v3.component.ComponentRegistry;
import org.ladysnake.cca.api.v3.component.sync.AutoSyncedComponent;
import org.ladysnake.cca.api.v3.component.sync.ComponentPacketWriter;
import org.ladysnake.cca.api.v3.component.tick.CommonTickingComponent;

import java.util.*;
import java.util.function.BiConsumer;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;

//  TODO: Maybe use data attachments instead? -eggohito
public interface PowerHolderComponent extends AutoSyncedComponent, CommonTickingComponent {

    /**
     *  <b>Use {@link #getOptional(class_1297)} or {@link #getNullable(class_1297)} wherever possible.</b>
     */
    @ApiStatus.Internal
    ComponentKey<PowerHolderComponent> KEY = ComponentRegistry.getOrCreate(Apoli.identifier("powers"), PowerHolderComponent.class);

    boolean removePower(Power power, class_2960 source);

    default boolean removePower(PowerReference powerReference, class_2960 source) {
        return powerReference.getResultPower()
            .mapError(err -> "Couldn't revoke non-existing power with ID \"" + powerReference.id() + "\"!")
            .resultOrPartial(Apoli.LOGGER::warn)
            .map(power -> removePower(power, source))
            .orElse(false);
    }

    int removeAllPowersFromSource(class_2960 source);

    List<Power> getPowersFromSource(class_2960 source);

    boolean addPower(Power power, class_2960 source);

    default boolean addPower(PowerReference powerReference, class_2960 source) {
        return powerReference.getResultPower()
            .mapError(error -> "Couldn't grant non-existing power with ID \"" + powerReference.id() + "\"!")
            .resultOrPartial(Apoli.LOGGER::warn)
            .map(power -> addPower(power, source))
            .orElse(false);
    }

    boolean hasPower(Power power);

    default boolean hasPower(PowerReference powerReference) {
        return powerReference.getOptionalPower()
            .map(this::hasPower)
            .orElse(false);
    }

    boolean hasPower(Power power, class_2960 source);

    default boolean hasPower(PowerReference powerReference, class_2960 source) {
        return powerReference.getOptionalPower()
            .map(power -> hasPower(power, source))
            .orElse(false);
    }

    PowerType getPowerType(Power power);

    List<PowerType> getPowerTypes();

    Set<Power> getPowers(boolean includeSubPowers);

    <T extends PowerType> List<T> getPowerTypes(Class<T> typeClass);

    <T extends PowerType> List<T> getPowerTypes(Class<T> typeClass, boolean includeInactive);

    List<class_2960> getSources(Power power);

    default List<class_2960> getSources(PowerReference powerReference) {
        return powerReference.getOptionalPower()
            .map(this::getSources)
            .orElseGet(ArrayList::new);
    }

    void sync();

    /**
     *  Queries the {@link PowerHolderComponent} from an {@link class_1297}. This is safer and preferred than directly using
     *  {@link #KEY} as it handles certain scenarios where unexpected errors may occur.
     *
     *  @param entity   the entity to get the component from
     *  @return         the power component, or {@link Optional#empty()} if the entity is either null, its component
     *                  container hasn't been initialized yet, or if the entity doesn't/can't have the power component
     */
    @SuppressWarnings("ConstantValue")
	static Optional<PowerHolderComponent> getOptional(@Nullable class_1297 entity) {

        if (entity != null && entity.asComponentProvider().getComponentContainer() != null) {
            return KEY.maybeGet(entity);
        }

        else {
            return Optional.empty();
        }

    }

    /**
     *  An alternative version of {@link #getOptional(class_1297)} that returns a <b>nullable</b>
     *  {@link PowerHolderComponent} instead.
     *
     *  @param entity   the entity to get the power component from
     *  @return         the power component, or {@code null} if the entity is either null, its component container
     *                  hasn't been initialized yet, or if the entity doesn't/can't have the power component
     */
    @Nullable
    static PowerHolderComponent getNullable(@Nullable class_1297 entity) {
        return getOptional(entity).orElse(null);
    }

    static void sync(class_1297 entity) {
        getOptional(entity).ifPresent(PowerHolderComponent::sync);
    }

    static boolean grantPower(@NotNull class_1297 entity, Power power, class_2960 source, boolean sync) {
        return grantPowers(entity, Map.of(source, List.of(power)), sync);
    }

    static boolean grantPowers(@NotNull class_1297 entity, Map<class_2960, Collection<Power>> powersBySource, boolean sync) {

        PowerHolderComponent powerComponent = getNullable(entity);
        if (!entity.method_37908().method_8608() && powerComponent != null) {

            boolean granted = powersBySource.entrySet()
                .stream()
                .flatMap(e -> e.getValue()
                    .stream()
                    .map(power -> powerComponent.addPower(power, e.getKey())))
                .reduce(false, Boolean::logicalOr);

            if (granted && sync) {
                PacketHandlers.GRANT_POWERS.sync(entity, powersBySource);
            }

            return granted;

        }

        else {
            return false;
        }

    }

    static boolean revokePower(@NotNull class_1297 entity, Power power, class_2960 source, boolean sync) {
        return revokePowers(entity, Map.of(source, List.of(power)), sync);
    }

    static boolean revokePowers(@NotNull class_1297 entity, Map<class_2960, Collection<Power>> powersBySource, boolean sync) {

        PowerHolderComponent powerComponent = getNullable(entity);
        if (!entity.method_37908().method_8608() && powerComponent != null) {

            boolean revoked = powersBySource.entrySet()
                .stream()
                .flatMap(e -> e.getValue()
                    .stream()
                    .map(power -> powerComponent.removePower(power, e.getKey())))
                .reduce(false, Boolean::logicalOr);

            if (revoked && sync) {
                PacketHandlers.REVOKE_POWERS.sync(entity, powersBySource);
            }

            return revoked;

        }

        else {
            return false;
        }

    }

    static int revokeAllPowersFromSource(@NotNull class_1297 entity, class_2960 source, boolean sync) {
        return revokeAllPowersFromAllSources(entity, List.of(source), sync);
    }

    static int revokeAllPowersFromAllSources(@NotNull class_1297 entity, Collection<class_2960> sources, boolean sync) {

        PowerHolderComponent powerComponent = getNullable(entity);
        if (!entity.method_37908().method_8608() && powerComponent != null) {

            int revokedPowers = sources
                .stream()
                .map(powerComponent::removeAllPowersFromSource)
                .reduce(0, Integer::sum);

            if (revokedPowers > 0 && sync) {
                PacketHandlers.REVOKE_ALL_POWERS.sync(entity, sources);
            }

            return revokedPowers;

        }

        else {
            return 0;
        }

    }

    static void syncPower(class_1297 entity, PowerReference powerReference) {
        syncPower(entity, powerReference.getNullablePower());
    }

    static void syncPower(@Nullable class_1297 entity, @Nullable Power power) {

        if (power == null || entity == null || entity.method_37908().method_8608()) {
            return;
        }

        PowerHolderComponent component = PowerHolderComponent.KEY.getNullable(entity);
        if (component == null) {
            return;
        }

        class_2487 powerData = new class_2487();
        PowerType powerType = component.getPowerType(power);

        if (powerType == null) {
            return;
        }

        powerData.method_10566("Data", powerType.toTag());
        SyncPowerDataS2CPacket syncPowerDataPacket = new SyncPowerDataS2CPacket(entity.method_5628(), power.getId(), powerData);

        for (class_3222 trackingPlayer : PlayerLookup.tracking(entity)) {
            ServerPlayNetworking.send(trackingPlayer, syncPowerDataPacket);
        }

        if (entity instanceof class_3222 player) {
            ServerPlayNetworking.send(player, syncPowerDataPacket);
        }

    }

    static <P extends Power> void syncPowers(@Nullable class_1297 entity, Collection<P> powers) {

        if (entity == null || entity.method_37908().method_8608() || powers.isEmpty()) {
            return;
        }

        PowerHolderComponent component = getNullable(entity);
        Map<class_2960, class_2520> powersToSync = new HashMap<>();

        if (component == null) {
            return;
        }

        for (Power power : powers) {

            PowerType powerType = component.getPowerType(power);

            if (powerType != null) {
                powersToSync.put(power.getId(), powerType.toTag());
            }

        }

        if (powersToSync.isEmpty()) {
            return;
        }

        SyncBulkPowerDataS2CPacket syncBulkPowerDataPacket = new SyncBulkPowerDataS2CPacket(entity.method_5628(), powersToSync);
        for (class_3222 otherPlayer : PlayerLookup.tracking(entity)) {
            ServerPlayNetworking.send(otherPlayer, syncBulkPowerDataPacket);
        }

        if (entity instanceof class_3222 player) {
            ServerPlayNetworking.send(player, syncBulkPowerDataPacket);
        }

    }

    static <T extends PowerType> boolean withPowerType(@Nullable class_1297 entity, Class<T> powerClass, @NotNull Predicate<T> filter, Consumer<T> action) {

        Optional<T> powerType = getOptional(entity)
            .stream()
            .map(powerComponent -> powerComponent.getPowerTypes(powerClass))
            .flatMap(Collection::stream)
            .filter(filter)
            .findFirst();

        powerType.ifPresent(action);
        return powerType.isPresent();

    }

    static <T extends PowerType> boolean withPowerTypes(@Nullable class_1297 entity, Class<T> powerClass, @NotNull Predicate<T> filter, @NotNull Consumer<T> action) {

        List<T> powerTypes = getOptional(entity)
            .stream()
            .map(pc -> pc.getPowerTypes(powerClass))
            .flatMap(Collection::stream)
            .filter(filter)
            .toList();

        powerTypes.forEach(action);
        return !powerTypes.isEmpty();

    }

    static <T extends PowerType> List<T> getPowerTypes(class_1297 entity, Class<T> powerClass) {
        return getPowerTypes(entity, powerClass, false);
    }

    static <T extends PowerType> List<T> getPowerTypes(class_1297 entity, Class<T> powerClass, boolean includeInactive) {
        return getOptional(entity)
            .map(powerComponent -> powerComponent.getPowerTypes(powerClass, includeInactive))
            .orElse(Lists.newArrayList());
    }

    static <T extends PowerType> boolean hasPowerType(class_1297 entity, Class<T> powerClass) {
        return hasPowerType(entity, powerClass, p -> true);
    }

	static <T extends PowerType> boolean hasPowerType(class_1297 entity, Class<T> typeClass, @NotNull Predicate<T> typeFilter) {
        return getOptional(entity)
            .stream()
            .map(PowerHolderComponent::getPowerTypes)
            .flatMap(Collection::stream)
            .filter(typeClass::isInstance)
            .map(typeClass::cast)
            .filter(PowerType::isActive)
            .anyMatch(typeFilter);
    }

    static <T extends ValueModifyingPowerType> float modify(class_1297 entity, Class<T> powerClass, float baseValue) {
        return (float) modify(entity, powerClass, (double) baseValue, p -> true, p -> {});
    }

    static <T extends ValueModifyingPowerType> float modify(class_1297 entity, Class<T> powerClass, float baseValue, Predicate<T> powerFilter) {
        return (float) modify(entity, powerClass, (double) baseValue, powerFilter, p -> {});
    }

    static <T extends ValueModifyingPowerType> float modify(class_1297 entity, Class<T> powerClass, float baseValue, Predicate<T> powerFilter, Consumer<T> powerAction) {
        return (float) modify(entity, powerClass, (double) baseValue, powerFilter, powerAction);
    }

    static <T extends ValueModifyingPowerType> double modify(class_1297 entity, Class<T> powerClass, double baseValue) {
        return modify(entity, powerClass, baseValue, p -> true, p -> {});
    }

    static <T extends ValueModifyingPowerType> double modify(class_1297 entity, Class<T> powerClass, double baseValue, @NotNull Predicate<T> powerFilter, @NotNull Consumer<T> powerAction) {
        return modify(entity, powerClass, baseValue, powerFilter, powerAction, false);
    }

    static <T extends ValueModifyingPowerType> double modify(class_1297 entity, Class<T> powerClass, double baseValue, @NotNull Predicate<T> powerFilter, @NotNull Consumer<T> powerAction, boolean includeInactive) {
        return modify(entity, powerClass, ValueModifyingPowerType::getModifiers, baseValue, powerFilter, powerAction, includeInactive);
    }

    static <T extends ValueModifyingPowerType> double modify(class_1297 entity, Class<T> powerClass, Function<T, List<Modifier>> modifiersGetter, double baseValue, @NotNull Predicate<T> filter, @NotNull Consumer<T> action, boolean includeInactive) {
        return modify(entity, powerClass, getPowerTypes(entity, powerClass, includeInactive), modifiersGetter, baseValue, filter, action);
    }

    static <T extends ValueModifyingPowerType> double modify(class_1297 entity, Class<T> powerClass, List<T> powerTypes, Function<T, List<Modifier>> modifiersGetter, double baseValue, @NotNull Predicate<T> filter, @NotNull Consumer<T> action) {

        PowerHolderComponent powerComponent = getNullable(entity);
        if (powerComponent != null) {

            List<Modifier> modifiers = new ObjectArrayList<>();
            for (var powerType : powerTypes) {

                if (!filter.test(powerType)) {
                    continue;
                }

                action.accept(powerType);
                modifiers.addAll(modifiersGetter.apply(powerType));

            }

            ModifyValueCallback.EVENT.invoker().collectModifiers(entity, powerClass, baseValue, modifiers);
            return ModifierUtil.applyModifiers(entity, modifiers, baseValue);

        }

        else {
            return baseValue;
        }

    }

    final class PacketHandlers {

        public static final PacketHandler<Map<class_2960, Collection<Power>>> GRANT_POWERS = new PacketHandler.Impl<>(
            powersBySource -> (buf, recipient) -> buf.method_34063(powersBySource,
                class_2540::method_10812,
                (vbuf, powers) -> vbuf.method_34062(powers, (ebuf, power) -> ebuf.method_10812(power.getId()))
            ),
            (buf, component) -> {

                var powersBySource = buf.method_34067(
                    class_2540::method_10810,
                    vbuf -> vbuf.method_34068(ArrayList::new, ebuf -> PowerManager.get(ebuf.method_10810())));

                powersBySource.forEach((source, powers) -> powers.forEach(power -> component.addPower(power, source)));

            },
            1
        );

        public static final PacketHandler<Map<class_2960, Collection<Power>>> REVOKE_POWERS = new PacketHandler.Impl<>(
            GRANT_POWERS::write,
            (buf, component) -> {

                var powersBySource = buf.method_34067(
                    class_2540::method_10810,
                    vbuf -> vbuf.method_34068(ArrayList::new, ebuf -> PowerManager.get(ebuf.method_10810())));

                powersBySource.forEach((source, powers) -> powers.forEach(power -> component.removePower(power, source)));

            },
            2
        );

        public static final PacketHandler<Collection<class_2960>> REVOKE_ALL_POWERS = new PacketHandler.Impl<>(
            sources -> (buf, recipient) ->
                buf.method_34062(sources, class_2540::method_10812),
            (buf, component) -> buf
                .method_34068(ArrayList::new, class_2540::method_10810)
                .forEach(component::removeAllPowersFromSource),
            3
        );

    }

    abstract sealed class PacketHandler<T> permits PacketHandler.Impl {

        public abstract ComponentPacketWriter write(T type);

        public abstract void apply(class_9129 buf, PowerHolderComponent component);

        public abstract int getId();

        public final void sync(class_1297 powerHolder, T type) {

            if (getNullable(powerHolder) != null) {

                KEY.sync(powerHolder, (buf, recipient) -> {

                    buf.method_10804(this.getId());
                    this.write(type).writeSyncPacket(buf, recipient);

                });

            }

        }

        public static final class Impl<T> extends PacketHandler<T> {

            final Function<T, ComponentPacketWriter> writer;
            final BiConsumer<class_9129, PowerHolderComponent> applier;

            final int id;

            private Impl(Function<T, ComponentPacketWriter> writer, BiConsumer<class_9129, PowerHolderComponent> applier, int id) {
                this.writer = writer;
                this.applier = applier;
                this.id = id;
            }

            @Override
            public ComponentPacketWriter write(T type) {
                return writer.apply(type);
            }

            @Override
            public void apply(class_9129 buf, PowerHolderComponent component) {
                applier.accept(buf, component);
            }

            @Override
            public int getId() {
                return id;
            }

        }

    }

}
