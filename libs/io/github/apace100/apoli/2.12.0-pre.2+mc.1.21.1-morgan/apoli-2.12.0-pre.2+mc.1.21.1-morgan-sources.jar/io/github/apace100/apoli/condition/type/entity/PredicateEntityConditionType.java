package io.github.apace100.apoli.condition.type.entity;

import io.github.apace100.apoli.condition.ConditionConfiguration;
import io.github.apace100.apoli.condition.context.EntityConditionContext;
import io.github.apace100.apoli.condition.type.EntityConditionType;
import io.github.apace100.apoli.condition.type.EntityConditionTypes;
import io.github.apace100.apoli.data.TypedDataObjectFactory;
import io.github.apace100.calio.data.SerializableData;
import io.github.apace100.calio.data.SerializableDataTypes;
import org.jetbrains.annotations.NotNull;

import java.util.Optional;
import net.minecraft.class_1297;
import net.minecraft.class_173;
import net.minecraft.class_181;
import net.minecraft.class_3218;
import net.minecraft.class_47;
import net.minecraft.class_5321;
import net.minecraft.class_5341;
import net.minecraft.class_7924;
import net.minecraft.class_8567;

public class PredicateEntityConditionType extends EntityConditionType {

    public static final TypedDataObjectFactory<PredicateEntityConditionType> DATA_FACTORY = TypedDataObjectFactory.simple(
        new SerializableData()
            .add("predicate", SerializableDataTypes.PREDICATE),
        data -> new PredicateEntityConditionType(
            data.get("predicate")
        ),
        (conditionType, serializableData) -> serializableData.instance()
            .set("predicate", conditionType.predicate)
    );

    private final class_5321<class_5341> predicate;

    public PredicateEntityConditionType(class_5321<class_5341> predicate) {
        this.predicate = predicate;
    }

    @Override
    public boolean test(EntityConditionContext context) {

        class_1297 entity = context.entity();
        if (!(entity.method_37908() instanceof class_3218 serverWorld)) {
            return false;
        }

        class_5341 lootCondition = serverWorld.method_8503().method_58576()
            .method_58289()
            .method_30530(class_7924.field_50081)
            .method_31140(predicate);
        class_8567 lootContextParameterSet = new class_8567.class_8568(serverWorld)
            .method_51874(class_181.field_24424, entity.method_19538())
            .method_51877(class_181.field_1226, entity)
            .method_51875(class_173.field_20761);

        return lootCondition.test(new class_47.class_48(lootContextParameterSet).method_309(Optional.empty()));

    }

    @Override
    public @NotNull ConditionConfiguration<?> getConfig() {
        return EntityConditionTypes.PREDICATE;
    }

}
