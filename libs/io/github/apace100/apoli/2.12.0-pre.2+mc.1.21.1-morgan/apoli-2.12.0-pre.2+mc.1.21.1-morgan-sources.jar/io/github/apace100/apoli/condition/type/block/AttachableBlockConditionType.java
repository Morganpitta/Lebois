package io.github.apace100.apoli.condition.type.block;

import io.github.apace100.apoli.condition.ConditionConfiguration;
import io.github.apace100.apoli.condition.context.BlockConditionContext;
import io.github.apace100.apoli.condition.type.BlockConditionType;
import io.github.apace100.apoli.condition.type.BlockConditionTypes;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import org.jetbrains.annotations.NotNull;

public class AttachableBlockConditionType extends BlockConditionType {

    @Override
    public boolean test(BlockConditionContext context) {

        class_1937 world = context.world();
        class_2338 pos = context.pos();

        for (class_2350 direction : class_2350.values()) {

            class_2338 offsetPos = pos.method_10093(direction);

            if (world.method_22340(offsetPos) && world.method_8320(offsetPos).method_26206(world, pos, direction.method_10153())) {
                return true;
            }

        }

        return false;

    }

    @Override
    public @NotNull ConditionConfiguration<?> getConfig() {
        return BlockConditionTypes.ATTACHABLE;
    }

}
