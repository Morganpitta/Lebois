package io.github.apace100.apoli.condition.type.biome;

import io.github.apace100.apoli.condition.ConditionConfiguration;
import io.github.apace100.apoli.condition.context.BiomeConditionContext;
import io.github.apace100.apoli.condition.type.BiomeConditionType;
import io.github.apace100.apoli.condition.type.BiomeConditionTypes;
import io.github.apace100.apoli.data.TypedDataObjectFactory;
import io.github.apace100.calio.data.SerializableData;
import io.github.apace100.calio.data.SerializableDataTypes;
import net.minecraft.class_1959;
import net.minecraft.class_6862;
import org.jetbrains.annotations.NotNull;

public class InTagBiomeConditionType extends BiomeConditionType {

    public static final TypedDataObjectFactory<InTagBiomeConditionType> DATA_FACTORY = TypedDataObjectFactory.simple(
        new SerializableData()
            .add("tag", SerializableDataTypes.BIOME_TAG),
        data -> new InTagBiomeConditionType(
            data.get("tag")
        ),
        (conditionType, serializableData) -> serializableData.instance()
            .set("tag", conditionType.tag)
    );

    private final class_6862<class_1959> tag;

    public InTagBiomeConditionType(class_6862<class_1959> tag) {
        this.tag = tag;
    }

    @Override
    public boolean test(BiomeConditionContext context) {
        return context.biomeEntry().method_40220(tag);
    }

    @Override
    public @NotNull ConditionConfiguration<?> getConfig() {
        return BiomeConditionTypes.IN_TAG;
    }

}
