package io.github.apace100.apoli.mixin;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Local;
import io.github.apace100.apoli.access.*;
import io.github.apace100.apoli.component.PowerHolderComponent;
import io.github.apace100.apoli.power.type.*;
import io.github.apace100.apoli.util.ArmPoseReference;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1313;
import net.minecraft.class_1657;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_270;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_3726;
import net.minecraft.class_4050;
import net.minecraft.class_6862;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Comparator;
import java.util.List;
import java.util.Optional;

@Mixin(class_1297.class)
public abstract class EntityMixin implements MovingEntity, ModifiedPoseHolder, CustomLeashable {

    @Shadow
    private boolean onGround;

    @Shadow public abstract class_243 getPos();

    @Shadow public abstract double getX();

    @Shadow public abstract double getY();

    @Shadow public abstract double getZ();

    @Shadow public abstract class_1937 getWorld();

    @Shadow public abstract class_2561 getName();

    @Shadow public abstract void setPose(class_4050 pose);

    @Shadow public abstract class_4050 getPose();

    @Shadow public abstract boolean isSwimming();

    @Shadow public abstract class_1299<?> getType();

    @ModifyReturnValue(method = "isFireImmune", at = @At("RETURN"))
    private boolean apoli$makeFullyFireImmune(boolean original) {
        return original
            || PowerHolderComponent.hasPowerType((class_1297) (Object) this, FireImmunityPowerType.class);
    }

    @ModifyReturnValue(method = "isTouchingWater", at = @At("RETURN"))
    private boolean apoli$makeEntitiesIgnoreWater(boolean original) {

        if (!(this instanceof WaterMovingEntity waterMovingEntity)) {
            return original;
        }

        return original
            && !(waterMovingEntity.apoli$isInMovementPhase() && PowerHolderComponent.hasPowerType((class_1297) (Object) this, IgnoreWaterPowerType.class));

    }

    @Inject(method = "fall", at = @At(value = "INVOKE", target = "Lnet/minecraft/block/Block;onLandedUpon(Lnet/minecraft/world/World;Lnet/minecraft/block/BlockState;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/entity/Entity;F)V"))
    private void invokeActionOnLand(CallbackInfo ci) {
        PowerHolderComponent.withPowerTypes((class_1297) (Object) this, ActionOnLandPowerType.class, p -> true, ActionOnLandPowerType::executeAction);
    }

    @ModifyReturnValue(method = "isInvulnerableTo", at = @At("RETURN"))
    private boolean apoli$makeEntitiesInvulnerable(boolean original, class_1282 source) {
        return original
            || PowerHolderComponent.hasPowerType((class_1297) (Object) this, InvulnerabilityPowerType.class, p -> p.doesApply(source));
    }

    @ModifyExpressionValue(method = "move", at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/Entity;isWet()Z"))
    private boolean apoli$preventExtinguishingFromPowerSwimming(boolean original) {
        return original
            && !(this.isSwimming() && PowerHolderComponent.hasPowerType((class_1297) (Object) this, SwimmingPowerType.class));
    }

    @ModifyReturnValue(method = "isInvisible", at = @At("RETURN"))
    private boolean apoli$invisibility(boolean original) {
        return original
            || PowerHolderComponent.hasPowerType((class_1297) (Object) this, InvisibilityPowerType.class);
    }

    @WrapOperation(method = "isInvisibleTo", at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/Entity;isInvisible()Z"))
    private boolean apoli$specificallyInvisibleTo(class_1297 entity, Operation<Boolean> original, class_1657 viewer) {

        List<InvisibilityPowerType> invisibilityPowers = PowerHolderComponent.getPowerTypes(entity, InvisibilityPowerType.class, true);
        if (viewer == null || invisibilityPowers.isEmpty()) {
            return original.call(entity);
        }

        return invisibilityPowers
            .stream()
            .anyMatch(p -> p.isActive() && p.doesApply(viewer));

    }

    //  TODO: Use MixinExtras' @WrapMethod from its new beta releases -eggohito
    @Inject(method = "pushOutOfBlocks", at = @At(value = "NEW", target = "()Lnet/minecraft/util/math/BlockPos$Mutable;"), cancellable = true)
    protected void apoli$ignorePhasingEntities(double x, double y, double z, CallbackInfo ci, @Local class_2338 pos) {

        if (PowerHolderComponent.hasPowerType((class_1297) (Object) this, PhasingPowerType.class, p -> p.doesApply(pos))) {
            ci.cancel();
        }

    }

    @Redirect(method = "method_30022", at = @At(value = "INVOKE", target = "Lnet/minecraft/block/BlockState;getCollisionShape(Lnet/minecraft/world/BlockView;Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/util/shape/VoxelShape;"))
    private class_265 preventPhasingSuffocation(class_2680 state, class_1922 world, class_2338 pos) {
        return state.method_26194(world, pos, class_3726.method_16195((class_1297)(Object)this));
    }

    @ModifyVariable(method = "move", at = @At("HEAD"), argsOnly = true)
    private class_243 modifyMovementVelocity(class_243 original, class_1313 movementType) {

        if (movementType != class_1313.field_6308) {
            return original;
        }

        return new class_243(
            PowerHolderComponent.modify((class_1297)(Object) this, ModifyVelocityPowerType.class, original.field_1352, p -> p.doesApply(class_2350.class_2351.field_11048), p -> {}),
            PowerHolderComponent.modify((class_1297)(Object) this, ModifyVelocityPowerType.class, original.field_1351, p -> p.doesApply(class_2350.class_2351.field_11052), p -> {}),
            PowerHolderComponent.modify((class_1297)(Object) this, ModifyVelocityPowerType.class, original.field_1350, p -> p.doesApply(class_2350.class_2351.field_11051), p -> {})
        );

    }

    @Inject(method = "move", at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/Entity;getLandingPos()Lnet/minecraft/util/math/BlockPos;"))
    private void forceGrounded(class_1313 movementType, class_243 movement, CallbackInfo ci) {
        if(PowerHolderComponent.hasPowerType((class_1297)(Object)this, GroundedPowerType.class)) {
            this.onGround = true;
        }
    }

    @Environment(EnvType.CLIENT)
    @ModifyReturnValue(method = "getTeamColorValue", at = @At("RETURN"))
    private int apoli$modifyGlowingColorFromPower(int original) {

        //  region Advised by @EdwinMindcraft: a solution for making the hook limited to WorldRenderer ONLY. Uncomment the code in this region when run into unexpected calls to Entity#getTeamColorValue to fix the problem.
//        StackWalker walker = StackWalker.getInstance(Set.of(StackWalker.Option.RETAIN_CLASS_REFERENCE), 2);
//        boolean calledByWorldRenderer = walker.walk(stackFrameStream -> stackFrameStream
//            .map(StackWalker.StackFrame::getDeclaringClass)
//            .anyMatch(cls -> cls == WorldRenderer.class));
//
//        if (!calledByWorldRenderer) {
//            return original;
//        }
        //  endregion

        class_1297 cameraEntity = class_310.method_1551().method_1560();
        class_1297 renderedEntity = (class_1297) (Object) this;

        class_270 team = renderedEntity.method_5781();

        boolean hasTeamColor = team != null && team.method_1202().method_532() != null;
        int colorAmount = 0;

        float red = 0.0f;
        float green = 0.0f;
        float blue = 0.0f;

        for (EntityGlowPowerType entityGlowPower : PowerHolderComponent.getPowerTypes(cameraEntity, EntityGlowPowerType.class)) {

            if ((hasTeamColor && entityGlowPower.usesTeams()) || !entityGlowPower.doesApply(renderedEntity)) {
                continue;
            }

            red += entityGlowPower.getRed();
            green += entityGlowPower.getGreen();
            blue += entityGlowPower.getBlue();

            colorAmount++;

        }

        for (SelfGlowPowerType selfGlowPower : PowerHolderComponent.getPowerTypes(renderedEntity, SelfGlowPowerType.class)) {

            if ((hasTeamColor && selfGlowPower.usesTeams()) || !selfGlowPower.doesApply(cameraEntity)) {
                continue;
            }

            red += selfGlowPower.getRed();
            green += selfGlowPower.getGreen();
            blue += selfGlowPower.getBlue();

            colorAmount++;

        }

        return colorAmount > 0
            ? class_3532.method_15353(red / colorAmount, green / colorAmount, blue / colorAmount)
            : original;

    }

    @ModifyExpressionValue(method = "pushAwayFrom", at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/Entity;isConnectedThroughVehicle(Lnet/minecraft/entity/Entity;)Z"))
    private boolean apoli$preventEntityPushing(boolean original, class_1297 fromEntity) {
        return original || PreventEntityCollisionPowerType.doesApply(fromEntity, (class_1297) (Object) this);
    }

    @ModifyReturnValue(method = "collidesWith", at = @At("RETURN"))
    private boolean apoli$preventEntityCollision(boolean original, class_1297 other) {
        return !PreventEntityCollisionPowerType.doesApply((class_1297) (Object) this, other) && original;
    }

    @Unique
    private boolean apoli$movingHorizontally;

    @Unique
    private boolean apoli$movingVertically;

    @Unique
    private double apoli$horizontalMovementValue;

    @Unique
    private double apoli$verticalMovementValue;

    @Unique
    private class_243 apoli$prevPos;

    @Override
    public boolean apoli$isMovingHorizontally() {
        return apoli$movingHorizontally;
    }

    @Override
    public boolean apoli$isMovingVertically() {
        return apoli$movingVertically;
    }

    @Override
    public double apoli$getHorizontalMovementValue() {
        return apoli$horizontalMovementValue;
    }

    @Override
    public double apoli$getVerticalMovementValue() {
        return apoli$verticalMovementValue;
    }

    @Override
    public boolean apoli$isMoving() {
        return apoli$movingHorizontally || apoli$movingVertically;
    }

    @Inject(method = "tick", at = @At("HEAD"))
    private void apoli$resetMovingFlags(CallbackInfo ci) {
        this.apoli$movingHorizontally = false;
        this.apoli$movingVertically = false;
    }

    @Inject(method = "baseTick", at = @At("TAIL"))
    private void apoli$setMovingFlags(CallbackInfo ci) {

        if (apoli$prevPos == null) {
            this.apoli$prevPos = this.getPos();
            return;
        }

        double dx = apoli$prevPos.field_1352 - this.getX();
        double dy = apoli$prevPos.field_1351 - this.getY();
        double dz = apoli$prevPos.field_1350 - this.getZ();

        this.apoli$horizontalMovementValue = Math.sqrt(dx * dx + dz * dz);
        this.apoli$verticalMovementValue = Math.sqrt(dy * dy);

        this.apoli$prevPos = this.getPos();

        if (this.apoli$horizontalMovementValue >= 0.01) {
            this.apoli$movingHorizontally = true;
        }

        if (this.apoli$verticalMovementValue >= 0.01) {
            this.apoli$movingVertically = true;
        }

    }

    @ModifyReturnValue(method = "getType", at = @At("RETURN"))
    private class_1299<?> apoli$modifyTypeTag(class_1299<?> original) {

        if (original instanceof EntityLinkedType linkedType) {
            linkedType.apoli$setEntity((class_1297) (Object) this);
        }

        return original;

    }

    @WrapOperation(method = "handleFallDamage", at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/EntityType;isIn(Lnet/minecraft/registry/tag/TagKey;)Z"))
    private boolean apoli$fixEntityTypeCalls(class_1299<?> instance, class_6862<class_1299<?>> tag, Operation<Boolean> original) {
        return this.getType().method_20210(tag);
    }

    @Unique
    private class_4050 apoli$previousEntityPose;

    @Unique
    private class_4050 apoli$modifiedEntityPose;

    @Unique
    private ArmPoseReference apoli$modifiedArmPose;

    @Override
    public Optional<class_4050> apoli$getModifiedEntityPose() {
        return Optional.ofNullable(apoli$modifiedEntityPose);
    }

    @Override
    public void apoli$setModifiedEntityPose(class_4050 entityPose) {
        this.apoli$modifiedEntityPose = entityPose;
    }

    @Override
    public Optional<ArmPoseReference> apoli$getModifiedArmPose() {
        return Optional.ofNullable(apoli$modifiedArmPose);
    }

    @Override
    public void apoli$setModifiedArmPose(ArmPoseReference armPose) {
        this.apoli$modifiedArmPose = armPose;
    }

    @Inject(method = "tick", at = @At("TAIL"))
    private void apoli$overridePose(CallbackInfo ci) {
        PowerHolderComponent.getPowerTypes((class_1297) (Object) this, PosePowerType.class)
            .stream()
            .max(Comparator.comparing(PosePowerType::getPriority))
            .ifPresentOrElse(
                posePower -> {

                    if (!((class_1297) (Object) this instanceof class_1657) && apoli$previousEntityPose == null) {
                        this.apoli$previousEntityPose = this.getPose();
                    }

                    Optional<class_4050> replacementEntityPose = posePower.getEntityPose();

                    this.apoli$setModifiedEntityPose(replacementEntityPose.orElse(null));
                    this.apoli$setModifiedArmPose(posePower.getArmPose().orElse(null));

					replacementEntityPose.ifPresent(this::setPose);

                },
                () -> {

                    this.apoli$setModifiedEntityPose(null);
                    this.apoli$setModifiedArmPose(null);

                    if (apoli$previousEntityPose != null) {
                        this.setPose(apoli$previousEntityPose);
                    }

                    this.apoli$previousEntityPose = null;

                }
            );
    }

    @Unique
    private boolean apoli$customLeashed;

    @Override
    public boolean apoli$isCustomLeashed() {
        return apoli$customLeashed;
    }

    @Override
    public void apoli$setCustomLeashed(boolean customLeashed) {
        this.apoli$customLeashed = customLeashed;
    }

    @Unique
    private class_1297 thisAsEntity() {
        return (class_1297) (Object) this;
    }

}
