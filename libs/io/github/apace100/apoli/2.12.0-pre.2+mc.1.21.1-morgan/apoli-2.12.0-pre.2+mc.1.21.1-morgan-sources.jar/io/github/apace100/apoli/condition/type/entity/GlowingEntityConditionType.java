package io.github.apace100.apoli.condition.type.entity;

import io.github.apace100.apoli.condition.ConditionConfiguration;
import io.github.apace100.apoli.condition.context.EntityConditionContext;
import io.github.apace100.apoli.condition.type.EntityConditionType;
import io.github.apace100.apoli.condition.type.EntityConditionTypes;
import net.minecraft.class_1297;
import net.minecraft.class_310;
import org.jetbrains.annotations.NotNull;

public class GlowingEntityConditionType extends EntityConditionType {

	@Override
	public boolean test(EntityConditionContext context) {
		class_1297 entity = context.entity();
		return !entity.method_37908().method_8608()
			? entity.method_5851()
			: class_310.method_1551().method_27022(entity);
	}

	@Override
	public @NotNull ConditionConfiguration<?> getConfig() {
		return EntityConditionTypes.GLOWING;
	}

}
