package io.github.apace100.apoli.integration;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.class_310;

@Environment(EnvType.CLIENT)
public interface PostLoadTexturesCallback {

    Event<PostLoadTexturesCallback> EVENT = EventFactory.createArrayBacked(
        PostLoadTexturesCallback.class,
        callbacks -> (client, initialized) -> {

            for (PostLoadTexturesCallback callback : callbacks) {
                callback.onPostLoad(client, initialized);
            }

        }
    );

    void onPostLoad(class_310 client, boolean initialized);

}
