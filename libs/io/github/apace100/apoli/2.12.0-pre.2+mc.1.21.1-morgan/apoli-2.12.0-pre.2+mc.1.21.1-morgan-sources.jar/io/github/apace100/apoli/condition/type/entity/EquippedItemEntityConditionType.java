package io.github.apace100.apoli.condition.type.entity;

import io.github.apace100.apoli.condition.ConditionConfiguration;
import io.github.apace100.apoli.condition.ItemCondition;
import io.github.apace100.apoli.condition.context.EntityConditionContext;
import io.github.apace100.apoli.condition.type.EntityConditionType;
import io.github.apace100.apoli.condition.type.EntityConditionTypes;
import io.github.apace100.apoli.data.TypedDataObjectFactory;
import io.github.apace100.calio.data.SerializableData;
import io.github.apace100.calio.data.SerializableDataTypes;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_9274;
import org.jetbrains.annotations.NotNull;

public class EquippedItemEntityConditionType extends EntityConditionType {

    public static final TypedDataObjectFactory<EquippedItemEntityConditionType> DATA_FACTORY = TypedDataObjectFactory.simple(
        new SerializableData()
            .add("item_condition", ItemCondition.DATA_TYPE)
            .add("equipment_slot", SerializableDataTypes.ATTRIBUTE_MODIFIER_SLOT),
        data -> new EquippedItemEntityConditionType(
            data.get("item_condition"),
            data.get("equipment_slot")
        ),
        (conditionType, serializableData) -> serializableData.instance()
            .set("item_condition", conditionType.itemCondition)
            .set("equipment_slot", conditionType.equipmentSlot)
    );

    private final ItemCondition itemCondition;
    private final class_9274 equipmentSlot;

    public EquippedItemEntityConditionType(ItemCondition itemCondition, class_9274 equipmentSlot) {
        this.itemCondition = itemCondition;
        this.equipmentSlot = equipmentSlot;
    }


    @Override
    public boolean test(EntityConditionContext context) {

        if (!(context.entity() instanceof class_1309 livingEntity)) {
            return false;
        }

        for (class_1304 slot : class_1304.values()) {

            if (equipmentSlot.method_57286(slot) && itemCondition.test(livingEntity.method_37908(), livingEntity.method_6118(slot))) {
                return true;
            }

        }

        return false;

    }

    @Override
    public @NotNull ConditionConfiguration<?> getConfig() {
        return EntityConditionTypes.EQUIPPED_ITEM;
    }

}
