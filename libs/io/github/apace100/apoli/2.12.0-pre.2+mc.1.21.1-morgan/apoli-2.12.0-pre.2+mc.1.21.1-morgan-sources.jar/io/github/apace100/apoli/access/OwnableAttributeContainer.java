package io.github.apace100.apoli.access;

import net.minecraft.class_1297;
import org.jetbrains.annotations.Nullable;

public interface OwnableAttributeContainer {
    @Nullable class_1297 apoli$getOwner();
    void apoli$setOwner(class_1297 owner);
}
