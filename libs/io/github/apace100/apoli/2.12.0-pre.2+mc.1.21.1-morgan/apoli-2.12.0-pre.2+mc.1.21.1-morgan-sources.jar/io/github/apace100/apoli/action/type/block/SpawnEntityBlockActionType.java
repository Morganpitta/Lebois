package io.github.apace100.apoli.action.type.block;

import io.github.apace100.apoli.action.ActionConfiguration;
import io.github.apace100.apoli.action.EntityAction;
import io.github.apace100.apoli.action.context.BlockActionContext;
import io.github.apace100.apoli.action.type.BlockActionType;
import io.github.apace100.apoli.action.type.BlockActionTypes;
import io.github.apace100.apoli.data.TypedDataObjectFactory;
import io.github.apace100.apoli.util.MiscUtil;
import io.github.apace100.calio.data.SerializableData;
import io.github.apace100.calio.data.SerializableDataTypes;
import org.jetbrains.annotations.NotNull;

import java.util.Optional;
import net.minecraft.class_1299;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_3218;

public class SpawnEntityBlockActionType extends BlockActionType {

    public static final TypedDataObjectFactory<SpawnEntityBlockActionType> DATA_FACTORY = TypedDataObjectFactory.simple(
        new SerializableData()
            .add("entity_type", SerializableDataTypes.ENTITY_TYPE)
            .add("entity_action", EntityAction.DATA_TYPE.optional(), Optional.empty())
            .add("tag", SerializableDataTypes.NBT_COMPOUND, new class_2487()),
        data -> new SpawnEntityBlockActionType(
            data.get("entity_type"),
            data.get("entity_action"),
            data.get("tag")
        ),
        (actionType, serializableData) -> serializableData.instance()
            .set("entity_type", actionType.entityType)
            .set("entity_action", actionType.entityAction)
            .set("tag", actionType.tag)
    );

    private final class_1299<?> entityType;

    private final Optional<EntityAction> entityAction;
    private final class_2487 tag;

    public SpawnEntityBlockActionType(class_1299<?> entityType, Optional<EntityAction> entityAction, class_2487 tag) {
        this.entityType = entityType;
        this.entityAction = entityAction;
        this.tag = tag;
    }

    @Override
    public void accept(BlockActionContext context) {

        class_3218 world = context.world();
        class_2338 pos = context.pos();

        MiscUtil.getEntityWithPassengers(world, entityType, tag, pos.method_61082(), Optional.empty(), Optional.empty()).ifPresent(entity -> {
            world.method_30736(entity);
            entityAction.ifPresent(action -> action.execute(entity));
        });

    }

    @Override
    public @NotNull ActionConfiguration<?> getConfig() {
        return BlockActionTypes.SPAWN_ENTITY;
    }

}
