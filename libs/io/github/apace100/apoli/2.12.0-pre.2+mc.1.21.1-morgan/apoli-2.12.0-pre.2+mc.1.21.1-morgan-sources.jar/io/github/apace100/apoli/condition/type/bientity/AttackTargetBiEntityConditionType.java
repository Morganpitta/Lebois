package io.github.apace100.apoli.condition.type.bientity;

import io.github.apace100.apoli.condition.ConditionConfiguration;
import io.github.apace100.apoli.condition.context.BiEntityConditionContext;
import io.github.apace100.apoli.condition.type.BiEntityConditionType;
import io.github.apace100.apoli.condition.type.BiEntityConditionTypes;
import io.github.apace100.apoli.util.requirement.BiEntityRequirement;
import org.jetbrains.annotations.NotNull;

import java.util.Objects;
import net.minecraft.class_1297;
import net.minecraft.class_5354;
import net.minecraft.class_8152;

public class AttackTargetBiEntityConditionType extends BiEntityConditionType {

    @Override
    public boolean test(BiEntityConditionContext context) {

        class_1297 actor = context.actor();
        class_1297 target = context.target();

        return (actor instanceof class_8152 targeterActor && Objects.equals(target, targeterActor.method_5968()))
            || (actor instanceof class_5354 angerableActor && Objects.equals(target, angerableActor.method_5968()));

    }

    @Override
    public BiEntityRequirement getRequirement() {
        return BiEntityRequirement.BOTH;
    }

    @Override
    public @NotNull ConditionConfiguration<?> getConfig() {
        return BiEntityConditionTypes.ATTACK_TARGET;
    }

}
