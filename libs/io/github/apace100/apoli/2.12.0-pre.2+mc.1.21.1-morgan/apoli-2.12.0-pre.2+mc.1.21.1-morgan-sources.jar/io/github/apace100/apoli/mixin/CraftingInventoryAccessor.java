package io.github.apace100.apoli.mixin;

import net.minecraft.class_1703;
import net.minecraft.class_1715;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_1715.class)
public interface CraftingInventoryAccessor {

    @Accessor
    class_1703 getHandler();
}
