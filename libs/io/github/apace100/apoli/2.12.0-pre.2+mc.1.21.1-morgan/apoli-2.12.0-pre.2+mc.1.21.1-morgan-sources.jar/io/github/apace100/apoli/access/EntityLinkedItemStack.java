package io.github.apace100.apoli.access;

import net.minecraft.class_1297;

public interface EntityLinkedItemStack {
    class_1297 apoli$getEntity();

    class_1297 apoli$getEntity(boolean prioritiseVanillaHolder);

    void apoli$setEntity(class_1297 entity);
}
