package io.github.apace100.apoli.loot.condition;

import com.mojang.serialization.MapCodec;
import io.github.apace100.apoli.Apoli;
import net.minecraft.class_2378;
import net.minecraft.class_5341;
import net.minecraft.class_5342;
import net.minecraft.class_7923;

public class ApoliLootConditionTypes {

	public static final class_5342 POWER = register("power", PowerLootCondition.MAP_CODEC);

	public static void register() {

	}

	public static <C extends class_5341> class_5342 register(String path, MapCodec<C> mapCodec) {
		return class_2378.method_10230(class_7923.field_41135, Apoli.identifier(path), new class_5342(mapCodec));
	}

}
