package io.github.apace100.apoli.action.type.entity;

import io.github.apace100.apoli.action.ActionConfiguration;
import io.github.apace100.apoli.action.context.EntityActionContext;
import io.github.apace100.apoli.action.type.EntityActionType;
import io.github.apace100.apoli.action.type.EntityActionTypes;
import io.github.apace100.apoli.condition.BiEntityCondition;
import io.github.apace100.apoli.data.TypedDataObjectFactory;
import io.github.apace100.calio.data.SerializableData;
import io.github.apace100.calio.data.SerializableDataTypes;
import org.jetbrains.annotations.NotNull;

import java.util.Optional;
import net.minecraft.class_1297;
import net.minecraft.class_2394;
import net.minecraft.class_243;
import net.minecraft.class_3218;

public class SpawnParticlesEntityActionType extends EntityActionType {

    public static final TypedDataObjectFactory<SpawnParticlesEntityActionType> DATA_FACTORY = TypedDataObjectFactory.simple(
        new SerializableData()
            .add("bientity_condition", BiEntityCondition.DATA_TYPE.optional(), Optional.empty())
            .add("particle", SerializableDataTypes.PARTICLE_EFFECT_OR_TYPE)
            .add("offset_x", SerializableDataTypes.DOUBLE, 0.0D)
            .add("offset_y", SerializableDataTypes.DOUBLE, 0.5D)
            .add("offset_z", SerializableDataTypes.DOUBLE, 0.0D)
            .addFunctionedDefault("offset", SerializableDataTypes.VECTOR, data -> new class_243(data.getDouble("offset_x"), data.getDouble("offset_y"), data.getDouble("offset_z")))
            .add("spread", SerializableDataTypes.VECTOR, new class_243(0.5D, 0.5D, 0.5D))
            .add("force", SerializableDataTypes.BOOLEAN, false)
            .add("speed", SerializableDataTypes.FLOAT, 0.0F)
            .add("count", SerializableDataTypes.INT, 1),
        data -> new SpawnParticlesEntityActionType(
            data.get("bientity_condition"),
            data.get("particle"),
            data.get("offset"),
            data.get("spread"),
            data.get("force"),
            data.get("speed"),
            data.get("count")
        ),
        (actionType, serializableData) -> serializableData.instance()
            .set("bientity_condition", actionType.biEntityCondition)
            .set("particle", actionType.particle)
            .set("offset", actionType.offset)
            .set("spread", actionType.spread)
            .set("force", actionType.force)
            .set("speed", actionType.speed)
            .set("count", actionType.count)
    );

    private final Optional<BiEntityCondition> biEntityCondition;
    private final class_2394 particle;

    private final class_243 offset;
    private final class_243 spread;

    private final boolean force;
    private final float speed;
    private final int count;

    public SpawnParticlesEntityActionType(Optional<BiEntityCondition> biEntityCondition, class_2394 particle, class_243 offset, class_243 spread, boolean force, float speed, int count) {
        this.biEntityCondition = biEntityCondition;
        this.particle = particle;
        this.offset = offset;
        this.spread = spread;
        this.force = force;
        this.speed = speed;
        this.count = count;
    }

    @Override
    public void accept(EntityActionContext context) {

        class_1297 entity = context.entity();
        class_243 pos = entity.method_19538().method_1019(context.offset()).method_1019(offset);

        if (!(entity.method_37908() instanceof class_3218 serverWorld)) {
            return;
        }

        class_243 delta = spread.method_18805(entity.method_17681(), entity.method_17682(), entity.method_17681());
        serverWorld.method_18456()
            .stream()
            .filter(player -> biEntityCondition.map(condition -> condition.test(entity, player)).orElse(true))
            .forEach(player -> serverWorld.method_14166(player, particle, force, pos.method_10216(), pos.method_10214(), pos.method_10215(), count, delta.method_10216(), delta.method_10214(), delta.method_10215(), speed));

    }

    @Override
    public @NotNull ActionConfiguration<?> getConfig() {
        return EntityActionTypes.SPAWN_PARTICLES;
    }

}
