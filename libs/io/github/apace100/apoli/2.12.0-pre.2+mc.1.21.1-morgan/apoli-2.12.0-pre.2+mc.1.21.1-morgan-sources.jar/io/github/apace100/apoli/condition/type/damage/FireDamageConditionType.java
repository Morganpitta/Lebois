package io.github.apace100.apoli.condition.type.damage;

import io.github.apace100.apoli.condition.ConditionConfiguration;
import io.github.apace100.apoli.condition.type.DamageConditionTypes;
import net.minecraft.class_8103;
import org.jetbrains.annotations.NotNull;

@Deprecated(forRemoval = true)
public class FireDamageConditionType extends InTagDamageConditionType {

	public FireDamageConditionType() {
		super(class_8103.field_42246);
	}

	@Override
	public @NotNull ConditionConfiguration<?> getConfig() {
		return DamageConditionTypes.FIRE;
	}

}
