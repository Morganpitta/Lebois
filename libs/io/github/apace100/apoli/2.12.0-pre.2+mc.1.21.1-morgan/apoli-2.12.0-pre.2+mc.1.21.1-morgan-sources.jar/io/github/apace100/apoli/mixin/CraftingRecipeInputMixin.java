package io.github.apace100.apoli.mixin;

import io.github.apace100.apoli.access.PowerCraftingInventory;
import io.github.apace100.apoli.power.type.PowerType;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;

import java.util.Collection;
import java.util.LinkedList;
import net.minecraft.class_1657;
import net.minecraft.class_1715;
import net.minecraft.class_9694;

@Mixin(class_9694.class)
public abstract class CraftingRecipeInputMixin implements PowerCraftingInventory {

    @Unique
    private Collection<? extends PowerType> apoli$cachedPowerTypes = new LinkedList<>();

    @Unique
    private class_1657 apoli$cachedPlayer;

    @Unique
    private class_1715 apoli$inventory;

    @Override
    public Collection<? extends PowerType> apoli$getPowerTypes() {
        return apoli$cachedPowerTypes;
    }

    @Override
    public void apoli$setPowerTypes(Collection<? extends PowerType> powerType) {

        this.apoli$cachedPowerTypes = powerType;

        if (this.apoli$getInventory() instanceof PowerCraftingInventory pci) {
            pci.apoli$setPowerTypes(this.apoli$getPowerTypes());
        }

    }

    @Override
    public class_1657 apoli$getPlayer() {
        return apoli$cachedPlayer;
    }

    @Override
    public void apoli$setPlayer(class_1657 player) {

        this.apoli$cachedPlayer = player;

        if (this.apoli$getInventory() instanceof PowerCraftingInventory pci) {
            pci.apoli$setPlayer(this.apoli$getPlayer());
        }

    }

    @Override
    public class_1715 apoli$getInventory() {
        return apoli$inventory;
    }

    @Override
    public void apoli$setInventory(class_1715 inventory) {
        this.apoli$inventory = inventory;
    }

}
