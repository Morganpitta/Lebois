package io.github.apace100.apoli.access;

import net.minecraft.class_176;

public interface LootContextTypeHolder {

	class_176 apoli$getType();

	void apoli$setType(class_176 type);

}
