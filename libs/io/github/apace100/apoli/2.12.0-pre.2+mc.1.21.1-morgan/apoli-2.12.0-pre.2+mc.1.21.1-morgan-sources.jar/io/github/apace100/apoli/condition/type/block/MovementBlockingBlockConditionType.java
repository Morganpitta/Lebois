package io.github.apace100.apoli.condition.type.block;

import io.github.apace100.apoli.condition.ConditionConfiguration;
import io.github.apace100.apoli.condition.context.BlockConditionContext;
import io.github.apace100.apoli.condition.type.BlockConditionType;
import io.github.apace100.apoli.condition.type.BlockConditionTypes;
import net.minecraft.class_2680;
import org.jetbrains.annotations.NotNull;

public class MovementBlockingBlockConditionType extends BlockConditionType {

    @Override
    public boolean test(BlockConditionContext context) {
        class_2680 blockState = context.blockState();
        return blockState.method_51366()
            && !blockState.method_26220(context.world(), context.pos()).method_1110();
    }

    @Override
    public @NotNull ConditionConfiguration<?> getConfig() {
        return BlockConditionTypes.MOVEMENT_BLOCKING;
    }

}
