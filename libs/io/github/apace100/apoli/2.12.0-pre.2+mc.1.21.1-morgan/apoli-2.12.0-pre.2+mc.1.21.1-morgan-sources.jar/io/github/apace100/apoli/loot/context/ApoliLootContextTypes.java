package io.github.apace100.apoli.loot.context;

import com.google.common.collect.BiMap;
import io.github.apace100.apoli.Apoli;
import io.github.apace100.apoli.mixin.LootContextTypesAccessor;
import net.minecraft.class_176;
import net.minecraft.class_181;
import net.minecraft.class_2960;

public class ApoliLootContextTypes {

    public static final class_176 ANY = register(
        Apoli.identifier("any"),
        class_176.method_35554()
            .method_780(class_181.field_1226)
            .method_780(class_181.field_1233)
            .method_780(class_181.field_1231)
            .method_780(class_181.field_1230)
            .method_780(class_181.field_1227)
            .method_780(class_181.field_24424)
            .method_780(class_181.field_1224)
            .method_780(class_181.field_1228)
            .method_780(class_181.field_1229)
            .method_780(class_181.field_1225)
    );

    private ApoliLootContextTypes() {}

    private static class_176 register(class_2960 id, class_176.class_177 lootContextTypeBuilder) {

        class_176 lootContextType = lootContextTypeBuilder.method_782();
        BiMap<class_2960, class_176> idAndLootContextTypeMap = LootContextTypesAccessor.getMap();

        if (idAndLootContextTypeMap.containsKey(id)) {
            throw new IllegalStateException("Loot table parameter set \"" + id + "\" is already registered!");
        }

        idAndLootContextTypeMap.put(id, lootContextType);
        return lootContextType;

    }

}
