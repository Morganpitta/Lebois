package io.github.apace100.apoli.action.type.item;

import io.github.apace100.apoli.access.EntityLinkedItemStack;
import io.github.apace100.apoli.action.ActionConfiguration;
import io.github.apace100.apoli.action.context.ItemActionContext;
import io.github.apace100.apoli.action.type.ItemActionType;
import io.github.apace100.apoli.action.type.ItemActionTypes;
import io.github.apace100.apoli.data.TypedDataObjectFactory;
import io.github.apace100.apoli.util.MiscUtil;
import io.github.apace100.apoli.util.modifier.Modifier;
import io.github.apace100.apoli.util.modifier.ModifierUtil;
import io.github.apace100.calio.data.SerializableData;
import org.jetbrains.annotations.NotNull;

import java.util.List;
import net.minecraft.class_1657;
import net.minecraft.class_1796;
import net.minecraft.class_1799;

public class ModifyItemCooldownItemActionType extends ItemActionType {

    public static final TypedDataObjectFactory<ModifyItemCooldownItemActionType> DATA_FACTORY = TypedDataObjectFactory.simple(
        new SerializableData()
            .add("modifier", Modifier.DATA_TYPE, null)
            .addFunctionedDefault("modifiers", Modifier.LIST_TYPE, data -> MiscUtil.singletonListOrNull(data.get("modifier")))
            .validate(MiscUtil.validateAnyFieldsPresent("modifier", "modifiers")),
        data -> new ModifyItemCooldownItemActionType(
            data.get("modifiers")
        ),
        (actionType, serializableData) -> serializableData.instance()
            .set("modifiers", actionType.modifiers)
    );

    private final List<Modifier> modifiers;

    public ModifyItemCooldownItemActionType(List<Modifier> modifiers) {
        this.modifiers = modifiers;
    }

    @Override
    public void accept(ItemActionContext context) {

        class_1799 stack = context.stackReference().method_32327();
        if (stack.method_7960() || modifiers.isEmpty() || !(((EntityLinkedItemStack) stack).apoli$getEntity(true) instanceof class_1657 player)) {
            return;
        }

        class_1796 cooldownManager = player.method_7357();
        class_1796.class_1797 cooldownEntry = cooldownManager.field_8024.get(stack.method_7909());

        int oldDuration = cooldownEntry != null
            ? cooldownEntry.field_8027 - cooldownEntry.field_8028
            : 0;

        cooldownManager.method_7906(stack.method_7909(), (int) ModifierUtil.applyModifiers(player, modifiers, oldDuration));

    }

    @Override
    public @NotNull ActionConfiguration<?> getConfig() {
        return ItemActionTypes.MODIFY_ITEM_COOLDOWN;
    }

}
