package io.github.apace100.apoli.data.container;

import io.github.apace100.apoli.util.TextAlignment;
import net.minecraft.class_1263;
import net.minecraft.class_1270;
import org.jetbrains.annotations.NotNull;

public record PresetContainerType(int columns, int rows, @NotNull Factory factory) implements ContainerType {

	@Override
	public TextAlignment titleAlignment() {
		return TextAlignment.NONE;
	}

	@Override
	public class_1270 create(class_1263 inventory) {
		return factory().create(inventory, columns(), rows());
	}

	@FunctionalInterface
	public interface Factory {
		class_1270 create(class_1263 inventory, int columns, int rows);
	}

}
