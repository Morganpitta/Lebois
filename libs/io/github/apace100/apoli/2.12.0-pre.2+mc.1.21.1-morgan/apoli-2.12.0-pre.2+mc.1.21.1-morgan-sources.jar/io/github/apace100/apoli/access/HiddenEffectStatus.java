package io.github.apace100.apoli.access;

import net.minecraft.class_1293;

public interface HiddenEffectStatus {
    class_1293 apoli$getHiddenEffect();
}
