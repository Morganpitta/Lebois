package io.github.apace100.apoli.action.type.block.meta;

import io.github.apace100.apoli.action.ActionConfiguration;
import io.github.apace100.apoli.action.BlockAction;
import io.github.apace100.apoli.action.context.BlockActionContext;
import io.github.apace100.apoli.action.type.BlockActionType;
import io.github.apace100.apoli.action.type.BlockActionTypes;
import io.github.apace100.apoli.action.type.meta.ChoiceMetaActionType;
import net.minecraft.class_6032;
import org.jetbrains.annotations.NotNull;

public class ChoiceBlockActionType extends BlockActionType implements ChoiceMetaActionType<BlockActionContext, BlockAction> {

	private final class_6032<BlockAction> actions;

	public ChoiceBlockActionType(class_6032<BlockAction> actions) {
		this.actions = actions;
	}

	@Override
	public void accept(BlockActionContext context) {
		this.executeActions(context);
	}

	@Override
	public @NotNull ActionConfiguration<?> getConfig() {
		return BlockActionTypes.CHOICE;
	}

	@Override
	public class_6032<BlockAction> actions() {
		return actions;
	}

}
