package io.github.apace100.apoli.condition.type.block.meta;

import io.github.apace100.apoli.condition.BlockCondition;
import io.github.apace100.apoli.condition.ConditionConfiguration;
import io.github.apace100.apoli.condition.context.BlockConditionContext;
import io.github.apace100.apoli.condition.type.BlockConditionType;
import io.github.apace100.apoli.condition.type.BlockConditionTypes;
import io.github.apace100.apoli.data.ApoliDataTypes;
import io.github.apace100.apoli.data.TypedDataObjectFactory;
import io.github.apace100.calio.data.SerializableData;
import io.github.apace100.calio.data.SerializableDataTypes;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2382;
import org.jetbrains.annotations.NotNull;

public class OffsetBlockConditionType extends BlockConditionType {

    public static final TypedDataObjectFactory<OffsetBlockConditionType> DATA_FACTORY = TypedDataObjectFactory.simple(
        new SerializableData()
            .add("condition", BlockCondition.DATA_TYPE)
            .add("x", SerializableDataTypes.INT, 0)
            .add("y", SerializableDataTypes.INT, 0)
            .add("z", SerializableDataTypes.INT, 0)
            .addFunctionedDefault("offset", ApoliDataTypes.VECTOR_3_INT, data -> new Vec3i(data.get("x"), data.get("y"), data.get("z"))),
        data -> new OffsetBlockConditionType(
            data.get("condition"),
            data.get("offset")
        ),
        (conditionType, serializableData) -> serializableData.instance()
            .set("condition", conditionType.blockCondition)
            .set("offset", conditionType.offset)
    );

    private final BlockCondition blockCondition;
    private final class_2382 offset;

    public OffsetBlockConditionType(BlockCondition blockCondition, class_2382 offset) {
        this.blockCondition = blockCondition;
        this.offset = offset;
    }

    @Override
    public boolean test(BlockConditionContext context) {

        class_1937 world = context.world();
        class_2338 offsetBlockPos = context.pos().method_10081(offset);

        return world.method_22340(offsetBlockPos)
            && blockCondition.test(world, offsetBlockPos);

    }

    @Override
    public @NotNull ConditionConfiguration<?> getConfig() {
        return BlockConditionTypes.OFFSET;
    }

}
