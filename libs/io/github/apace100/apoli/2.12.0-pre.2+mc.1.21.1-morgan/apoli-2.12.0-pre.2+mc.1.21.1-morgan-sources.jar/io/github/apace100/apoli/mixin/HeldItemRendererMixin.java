package io.github.apace100.apoli.mixin;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import io.github.apace100.apoli.power.type.EdibleItemPowerType;
import net.minecraft.class_1268;
import net.minecraft.class_1799;
import net.minecraft.class_742;
import net.minecraft.class_759;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_759.class)
public abstract class HeldItemRendererMixin {

    @ModifyExpressionValue(method = "renderFirstPersonItem", at = @At(value = "INVOKE", target = "Lnet/minecraft/item/ItemStack;isOf(Lnet/minecraft/item/Item;)Z"))
    private boolean apoli$overrideSpecialTransforms(boolean original, class_742 player, float tickDelta, float pitch, class_1268 hand, float swingProgress, class_1799 stack) {
        return original && EdibleItemPowerType.get(stack)
            .map(EdibleItemPowerType::getFoodComponent)
            .map(fc -> player.method_7332(fc.comp_2493()))
            .orElse(true);
    }

}
