package io.github.apace100.apoli.mixin;

import com.llamalad7.mixinextras.injector.wrapmethod.WrapMethod;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import io.github.apace100.apoli.component.PowerHolderComponent;
import io.github.apace100.apoli.power.type.EffectImmunityPowerType;
import net.minecraft.class_1289;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_7923;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(targets = "net.minecraft.entity.effect.InstantHealthOrDamageStatusEffect")
public abstract class InstantHealthOrDamageStatusEffectMixin {

    @WrapMethod(method = "applyInstantEffect")
    private void apoli$instantEffectImmunity(class_1297 source, class_1297 attacker, class_1309 target, int amplifier, double proximity, Operation<Void> original) {

        if (!PowerHolderComponent.hasPowerType(target, EffectImmunityPowerType.class, p -> p.doesApply(class_7923.field_41174.method_47983((class_1289) (Object) this)))) {
            original.call(source, attacker, target, amplifier, proximity);
        }

    }

}
