package io.github.apace100.apoli.mixin;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.mojang.authlib.GameProfile;
import io.github.apace100.apoli.component.PowerHolderComponent;
import io.github.apace100.apoli.power.type.ModifyFovPowerType;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

import java.util.List;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_742;

@Mixin(class_742.class)
public abstract class AbstractClientPlayerEntityMixin extends class_1657 {

    private AbstractClientPlayerEntityMixin(class_1937 world, class_2338 pos, float yaw, GameProfile gameProfile) {
        super(world, pos, yaw, gameProfile);
    }

    @ModifyReturnValue(method = "getFovMultiplier", at = @At(value = "RETURN", ordinal = 0))
    private float apoli$modifySpyglassFov(float original) {
        return PowerHolderComponent.modify(this, ModifyFovPowerType.class, original);
    }

    @WrapOperation(method = "getFovMultiplier", at = @At(value = "INVOKE", target = "Lnet/minecraft/util/math/MathHelper;lerp(FFF)F"))
    private float apoli$modifyFov(float delta, float start, float end, Operation<Float> original) {

        List<ModifyFovPowerType> mfps = PowerHolderComponent.getPowerTypes(this, ModifyFovPowerType.class);
        boolean affectedByFovEffectScale = mfps.isEmpty() || mfps
            .stream()
            .anyMatch(ModifyFovPowerType::isAffectedByFovEffectScale);

        float newEnd = PowerHolderComponent.modify(this, ModifyFovPowerType.class, end);
        float newDelta = affectedByFovEffectScale ? delta : start;

        return original.call(newDelta, start, newEnd);

    }

}
