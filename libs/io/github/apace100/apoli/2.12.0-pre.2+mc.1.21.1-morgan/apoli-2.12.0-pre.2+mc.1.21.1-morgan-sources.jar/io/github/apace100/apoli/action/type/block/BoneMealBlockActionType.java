package io.github.apace100.apoli.action.type.block;

import io.github.apace100.apoli.action.ActionConfiguration;
import io.github.apace100.apoli.action.context.BlockActionContext;
import io.github.apace100.apoli.action.type.BlockActionType;
import io.github.apace100.apoli.action.type.BlockActionTypes;
import io.github.apace100.apoli.data.TypedDataObjectFactory;
import io.github.apace100.calio.data.SerializableData;
import io.github.apace100.calio.data.SerializableDataTypes;
import org.jetbrains.annotations.NotNull;

import java.util.Optional;
import net.minecraft.class_1752;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_6088;

public class BoneMealBlockActionType extends BlockActionType {

    public static final TypedDataObjectFactory<BoneMealBlockActionType> DATA_FACTORY = TypedDataObjectFactory.simple(
        new SerializableData()
            .add("effects", SerializableDataTypes.BOOLEAN, true)
            .addFunctionedDefault("show_effects", SerializableDataTypes.BOOLEAN, data -> data.getBoolean("effects")),
        data -> new BoneMealBlockActionType(
            data.get("show_effects")
        ),
        (actionType, serializableData) -> serializableData.instance()
            .set("show_effects", actionType.showEffects)
    );

    private final boolean showEffects;

    public BoneMealBlockActionType(boolean showEffects) {
        this.showEffects = showEffects;
    }


    @Override
    public void accept(BlockActionContext context) {

        class_1937 world = context.world();
        class_2338 pos = context.pos();

        Optional<class_2350> optDirection = context.direction();
        class_1799 stack = class_1799.field_8037;

        if (class_1752.method_7720(stack, world, pos)) {
            boneMealEvent(world, pos);
        }

        else if (optDirection.isPresent()) {

            class_2350 direction = optDirection.get();

            class_2680 blockState = world.method_8320(pos);
            class_2338 offsetPos = pos.method_10093(direction);

            if (blockState.method_26206(world, pos, direction) && class_1752.method_7719(stack, world, offsetPos, direction)) {
                boneMealEvent(world, offsetPos);
            }

        }

    }

    @Override
    public @NotNull ActionConfiguration<?> getConfig() {
        return BlockActionTypes.BONE_MEAL;
    }

    private void boneMealEvent(class_1937 world, class_2338 pos) {

        if (showEffects && !world.method_8608()) {
            world.method_20290(class_6088.field_33511, pos, 0);
        }

    }

}
