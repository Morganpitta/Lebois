package io.github.apace100.apoli.condition.type.block;

import io.github.apace100.apoli.Apoli;
import io.github.apace100.apoli.condition.ConditionConfiguration;
import io.github.apace100.apoli.condition.context.BlockConditionContext;
import io.github.apace100.apoli.condition.type.BlockConditionType;
import io.github.apace100.apoli.condition.type.BlockConditionTypes;
import io.github.apace100.apoli.data.ApoliDataTypes;
import io.github.apace100.apoli.data.TypedDataObjectFactory;
import io.github.apace100.apoli.util.Comparison;
import io.github.apace100.calio.data.SerializableData;
import io.github.apace100.calio.data.SerializableDataTypes;
import net.minecraft.class_2165;
import net.minecraft.class_2168;
import net.minecraft.class_2338;
import net.minecraft.class_241;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.server.MinecraftServer;
import org.jetbrains.annotations.NotNull;

import java.util.concurrent.atomic.AtomicInteger;

public class CommandBlockConditionType extends BlockConditionType {

    public static final TypedDataObjectFactory<CommandBlockConditionType> DATA_FACTORY = TypedDataObjectFactory.simple(
        new SerializableData()
            .add("command", SerializableDataTypes.STRING)
            .add("comparison", ApoliDataTypes.COMPARISON, Comparison.GREATER_THAN)
            .add("compare_to", SerializableDataTypes.INT, 0),
        data -> new CommandBlockConditionType(
            data.get("command"),
            data.get("comparison"),
            data.get("compare_to")
        ),
        (conditionType, serializableData) -> serializableData.instance()
            .set("command", conditionType.command)
            .set("comparison", conditionType.comparison)
            .set("compare_to", conditionType.compareTo)
    );

    private final String command;

    private final Comparison comparison;
    private final int compareTo;

    public CommandBlockConditionType(String command, Comparison comparison, int compareTo) {
        this.command = command;
        this.comparison = comparison;
        this.compareTo = compareTo;
    }

    @Override
    public boolean test(BlockConditionContext context) {

        class_2680 blockState = context.blockState();
        class_2338 pos = context.pos();

        if (!(context.world() instanceof class_3218 serverWorld)) {
            return false;
        }

        MinecraftServer server = serverWorld.method_8503();
        AtomicInteger result = new AtomicInteger();

        String blockTranslationKey = blockState.method_26204().method_9539();
        class_2168 commandSource = new class_2168(
            Apoli.config.executeCommand.showOutput ? server : class_2165.field_17395,
            pos.method_46558(),
            class_241.field_1340,
            serverWorld,
            Apoli.config.executeCommand.permissionLevel,
            blockTranslationKey,
            class_2561.method_43471(blockTranslationKey),
            server,
            null
        );

        commandSource = commandSource.method_9231((successful, returnValue) -> result.set(returnValue));
        server.method_3734().method_44252(commandSource, command);

        return comparison.compare(result.get(), compareTo);

    }

    @Override
    public @NotNull ConditionConfiguration<?> getConfig() {
        return BlockConditionTypes.COMMAND;
    }

}
