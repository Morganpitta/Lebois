package io.github.apace100.apoli.condition.context;

import io.github.apace100.apoli.util.context.ConditionContext;
import net.minecraft.class_1297;
import net.minecraft.class_1937;
import net.minecraft.class_2338;

public record EntityConditionContext(class_1297 entity) implements ConditionContext {

	public class_1937 world() {
		return entity().method_37908();
	}

	public class_2338 blockPos() {
		return entity().method_24515();
	}

}
