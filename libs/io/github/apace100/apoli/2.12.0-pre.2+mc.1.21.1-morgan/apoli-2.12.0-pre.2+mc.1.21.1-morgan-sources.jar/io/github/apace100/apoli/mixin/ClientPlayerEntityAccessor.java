package io.github.apace100.apoli.mixin;

import net.minecraft.class_310;
import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_746.class)
public interface ClientPlayerEntityAccessor {

    @Accessor
    class_310 getClient();

}
