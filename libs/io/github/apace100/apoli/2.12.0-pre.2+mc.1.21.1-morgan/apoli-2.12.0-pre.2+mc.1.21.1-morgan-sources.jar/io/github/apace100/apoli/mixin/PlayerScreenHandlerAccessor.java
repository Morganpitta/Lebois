package io.github.apace100.apoli.mixin;

import net.minecraft.class_1657;
import net.minecraft.class_1723;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_1723.class)
public interface PlayerScreenHandlerAccessor {

    @Accessor
    class_1657 getOwner();
}
