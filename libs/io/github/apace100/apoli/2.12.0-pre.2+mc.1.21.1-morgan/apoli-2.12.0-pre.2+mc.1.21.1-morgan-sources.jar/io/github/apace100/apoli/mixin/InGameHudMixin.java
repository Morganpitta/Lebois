package io.github.apace100.apoli.mixin;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Local;
import io.github.apace100.apoli.component.PowerHolderComponent;
import io.github.apace100.apoli.power.type.OverrideHudTexturePowerType;
import io.github.apace100.apoli.screen.GameHudRender;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1294;
import net.minecraft.class_1657;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_329;
import net.minecraft.class_332;
import net.minecraft.class_9080;
import org.objectweb.asm.Opcodes;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Slice;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Comparator;
import java.util.Optional;

@Mixin(class_329.class)
@Environment(EnvType.CLIENT)
public abstract class InGameHudMixin {

    @Shadow @Final private class_310 client;

    @Shadow protected abstract class_1657 getCameraPlayer();

    @Inject(method = "<init>", at = @At(value = "FIELD", target = "Lnet/minecraft/client/gui/hud/InGameHud;layeredDrawer:Lnet/minecraft/client/gui/LayeredDrawer;", opcode = Opcodes.GETFIELD))
    private void apoli$renderResourceBars(class_310 client, CallbackInfo ci, @Local(ordinal = 0) class_9080 layeredDrawer) {

        for (GameHudRender hudRender : GameHudRender.HUD_RENDERS) {
            ((LayeredDrawerAccessor) layeredDrawer).getLayers().add(3, hudRender::render);
        }

    }

    @Unique
    private static Optional<OverrideHudTexturePowerType> apoli$getOverrideHudTexturePower(class_1657 player) {
        return PowerHolderComponent.getPowerTypes(player, OverrideHudTexturePowerType.class)
            .stream()
            .max(Comparator.comparing(OverrideHudTexturePowerType::getPriority));
    }
    
    @WrapOperation(method = "renderArmor", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/DrawContext;drawGuiTexture(Lnet/minecraft/util/Identifier;IIII)V", ordinal = 0))
    private static void apoli$overrideFullArmorSprite(class_332 context, class_2960 texture, int x, int y, int width, int height, Operation<Void> original, class_332 mContext, class_1657 player) {
        apoli$getOverrideHudTexturePower(player).ifPresentOrElse(
            p -> p.drawTexture(context, texture, x, y, 34, 9, width, height),
            () -> original.call(context, texture, x, y, width, height)
        );
    }

    @WrapOperation(method = "renderArmor", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/DrawContext;drawGuiTexture(Lnet/minecraft/util/Identifier;IIII)V", ordinal = 1))
    private static void apoli$overrideHalfArmorSprite(class_332 context, class_2960 texture, int x, int y, int width, int height, Operation<Void> original, class_332 mContext, class_1657 player) {
        apoli$getOverrideHudTexturePower(player).ifPresentOrElse(
            p -> p.drawTexture(context, texture, x, y, 25, 9, width, height),
            () -> original.call(context, texture, x, y, width, height)
        );
    }

    @WrapOperation(method = "renderArmor", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/DrawContext;drawGuiTexture(Lnet/minecraft/util/Identifier;IIII)V", ordinal = 2))
    private static void apoli$overrideEmptyArmorSprite(class_332 context, class_2960 texture, int x, int y, int width, int height, Operation<Void> original, class_332 mContext, class_1657 player) {
        apoli$getOverrideHudTexturePower(player).ifPresentOrElse(
            p -> p.drawTexture(context, texture, x, y, 16, 9, width, height),
            () -> original.call(context, texture, x, y, width, height)
        );
    }

    @WrapOperation(method = "renderFood", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/DrawContext;drawGuiTexture(Lnet/minecraft/util/Identifier;IIII)V", ordinal = 0))
    private void apoli$overrideEmptyFoodSprite(class_332 context, class_2960 texture, int x, int y, int width, int height, Operation<Void> original, class_332 mContext, class_1657 player) {
        apoli$getOverrideHudTexturePower(player).ifPresentOrElse(
            p -> p.drawTexture(context, texture, x, y, this.getCameraPlayer().method_6059(class_1294.field_5903) ? 133 : 16, 27, width, height),
            () -> original.call(context, texture, x, y, width, height)
        );
    }

    @WrapOperation(method = "renderFood", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/DrawContext;drawGuiTexture(Lnet/minecraft/util/Identifier;IIII)V", ordinal = 1))
    private void apoli$overrideFullFoodSprite(class_332 context, class_2960 texture, int x, int y, int width, int height, Operation<Void> original, class_332 mContext, class_1657 player) {
        apoli$getOverrideHudTexturePower(player).ifPresentOrElse(
            p -> p.drawTexture(context, texture, x, y, this.getCameraPlayer().method_6059(class_1294.field_5903) ? 88 : 52, 27, width, height),
            () -> original.call(context, texture, x, y, width, height)
        );
    }

    @WrapOperation(method = "renderFood", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/DrawContext;drawGuiTexture(Lnet/minecraft/util/Identifier;IIII)V", ordinal = 2))
    private void apoli$overrideHalfFoodSprite(class_332 context, class_2960 texture, int x, int y, int width, int height, Operation<Void> original, class_332 mContext, class_1657 player) {
        apoli$getOverrideHudTexturePower(player).ifPresentOrElse(
            p -> p.drawTexture(context, texture, x, y, this.getCameraPlayer().method_6059(class_1294.field_5903) ? 97 : 61, 27, width, height),
            () -> original.call(context, texture, x, y, width, height)
        );
    }

    @WrapOperation(method = "renderStatusBars", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/DrawContext;drawGuiTexture(Lnet/minecraft/util/Identifier;IIII)V", ordinal = 0), slice = @Slice(from = @At(value = "INVOKE", target = "Lnet/minecraft/entity/player/PlayerEntity;isSubmergedIn(Lnet/minecraft/registry/tag/TagKey;)Z")))
    private void apoli$overrideBubbleSprite(class_332 context, class_2960 texture, int x, int y, int width, int height, Operation<Void> original) {
        apoli$getOverrideHudTexturePower(this.client.field_1724).ifPresentOrElse(
            p -> p.drawTexture(context, texture, x, y, 16, 18, width, height),
            () -> original.call(context, texture, x, y, width, height)
        );
    }

    @WrapOperation(method = "renderStatusBars", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/DrawContext;drawGuiTexture(Lnet/minecraft/util/Identifier;IIII)V", ordinal = 1), slice = @Slice(from = @At(value = "INVOKE", target = "Lnet/minecraft/entity/player/PlayerEntity;isSubmergedIn(Lnet/minecraft/registry/tag/TagKey;)Z")))
    private void apoli$overrideBurstingBubbleSprite(class_332 instance, class_2960 texture, int x, int y, int width, int height, Operation<Void> original) {
        apoli$getOverrideHudTexturePower(this.client.field_1724).ifPresentOrElse(
            p -> p.drawTexture(instance, texture, x, y, 25, 18, width, height),
            () -> original.call(instance, texture, x, y, width, height)
        );
    }

    @WrapOperation(method = "drawHeart", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/DrawContext;drawGuiTexture(Lnet/minecraft/util/Identifier;IIII)V"))
    private void apoli$overrideHeartSprite(class_332 instance, class_2960 texture, int x, int y, int width, int height, Operation<Void> original, class_332 context, class_329.class_6411 type, int mX, int mY, boolean hardcore, boolean blinking, boolean half) {
        apoli$getOverrideHudTexturePower(this.client.field_1724).ifPresentOrElse(
            p -> p.drawHeartTexture(instance, type, x, y, width, height, hardcore, blinking, half),
            () -> original.call(instance, texture, x, y, width, height)
        );
    }

    @WrapOperation(method = "renderExperienceBar", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/DrawContext;drawGuiTexture(Lnet/minecraft/util/Identifier;IIII)V"))
    private void apoli$overrideBaseExperienceBarSprite(class_332 instance, class_2960 texture, int x, int y, int width, int height, Operation<Void> original) {
        apoli$getOverrideHudTexturePower(this.client.field_1724).ifPresentOrElse(
            p -> p.drawTexture(instance, texture, x, y, 0, 64, width, height),
            () -> original.call(instance, texture, x, y, width, height)
        );
    }

    @WrapOperation(method = "renderExperienceBar", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/DrawContext;drawGuiTexture(Lnet/minecraft/util/Identifier;IIIIIIII)V"))
    private void apoli$overrideProgressExperienceBarSprite(class_332 instance, class_2960 texture, int i, int j, int k, int l, int x, int y, int width, int height, Operation<Void> original, @Local(ordinal = 1) int experienceProgress) {
        apoli$getOverrideHudTexturePower(this.client.field_1724).ifPresentOrElse(
            p -> p.drawTextureRegion(instance, texture, i, j, k, l, 0, 69, x, y, width, height),
            () -> original.call(instance, texture, i, j, k, l, x, y, width, height)
        );
    }

    @WrapOperation(method = "renderCrosshair", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/DrawContext;drawGuiTexture(Lnet/minecraft/util/Identifier;IIII)V", ordinal = 0))
    private void apoli$overrideCrosshairSprite(class_332 instance, class_2960 texture, int x, int y, int width, int height, Operation<Void> original) {
        apoli$getOverrideHudTexturePower(this.client.field_1724).ifPresentOrElse(
            p -> p.drawTexture(instance, texture, x, y, 0, 0, width, height),
            () -> original.call(instance, texture, x, y, width, height)
        );
    }

    @WrapOperation(method = "renderCrosshair", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/DrawContext;drawGuiTexture(Lnet/minecraft/util/Identifier;IIII)V", ordinal = 0), slice = @Slice(from = @At(value = "INVOKE", target = "Lnet/minecraft/client/option/GameOptions;getAttackIndicator()Lnet/minecraft/client/option/SimpleOption;"), to = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/DrawContext;drawGuiTexture(Lnet/minecraft/util/Identifier;IIIIIIII)V")))
    private void apoli$overrideFullCrosshairAttackIndicatorSprite(class_332 instance, class_2960 texture, int x, int y, int width, int height, Operation<Void> original) {
        apoli$getOverrideHudTexturePower(this.client.field_1724).ifPresentOrElse(
            p -> p.drawTexture(instance, texture, x, y, 68, 94, width, height),
            () -> original.call(instance, texture, x, y, width, height)
        );
    }

    @WrapOperation(method = "renderCrosshair", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/DrawContext;drawGuiTexture(Lnet/minecraft/util/Identifier;IIII)V", ordinal = 1), slice = @Slice(from = @At(value = "INVOKE", target = "Lnet/minecraft/client/option/GameOptions;getAttackIndicator()Lnet/minecraft/client/option/SimpleOption;"), to = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/DrawContext;drawGuiTexture(Lnet/minecraft/util/Identifier;IIIIIIII)V")))
    private void apoli$overrideBaseCrosshairAttackIndicatorSprite(class_332 instance, class_2960 texture, int x, int y, int width, int height, Operation<Void> original) {
        apoli$getOverrideHudTexturePower(this.client.field_1724).ifPresentOrElse(
            p -> p.drawTexture(instance, texture, x, y, 36, 94, width, height),
            () -> original.call(instance, texture, x, y, width, height)
        );
    }

    @WrapOperation(method = "renderCrosshair", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/DrawContext;drawGuiTexture(Lnet/minecraft/util/Identifier;IIIIIIII)V"))
    private void apoli$overrideCrosshairAttackIndicatorProgressSprite(class_332 instance, class_2960 texture, int i, int j, int k, int l, int x, int y, int width, int height, Operation<Void> original) {
        apoli$getOverrideHudTexturePower(this.client.field_1724).ifPresentOrElse(
            p -> p.drawTextureRegion(instance, texture, i, j, k, l, 52, 94, x, y, width, height),
            () -> original.call(instance, texture, i, j, k, l, x, y, width, height)
        );
    }

    @WrapOperation(method = "renderMountJumpBar", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/DrawContext;drawGuiTexture(Lnet/minecraft/util/Identifier;IIII)V"))
    private void apoli$overrideBaseMountJumpBarSprite(class_332 instance, class_2960 texture, int x, int y, int width, int height, Operation<Void> original) {
        apoli$getOverrideHudTexturePower(this.client.field_1724).ifPresentOrElse(
            p -> p.drawTexture(instance, texture, x, y, 0, 84, width, height),
            () -> original.call(instance, texture, x, y, width, height)
        );
    }

   @WrapOperation(method = "renderMountJumpBar", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/DrawContext;drawGuiTexture(Lnet/minecraft/util/Identifier;IIIIIIII)V"))
    private void apoli$overrideMountJumpBarProgressSprite(class_332 instance, class_2960 texture, int i, int j, int k, int l, int x, int y, int width, int height, Operation<Void> original) {
       apoli$getOverrideHudTexturePower(this.client.field_1724).ifPresentOrElse(
           p -> p.drawTextureRegion(instance, texture, i, j, k, l, 0, 89, x, y, width, height),
           () -> original.call(instance, texture, i, j, k, l, x, y, width, height)
       );
   }

   @WrapOperation(method = "renderMountHealth", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/DrawContext;drawGuiTexture(Lnet/minecraft/util/Identifier;IIII)V", ordinal = 0))
    private void apoli$overrideEmptyMountHeartSprite(class_332 instance, class_2960 texture, int x, int y, int width, int height, Operation<Void> original) {
        apoli$getOverrideHudTexturePower(this.client.field_1724).ifPresentOrElse(
            p -> p.drawTexture(instance, texture, x, y, 52, 9, width, height),
            () -> original.call(instance, texture, x, y, width, height)
        );
   }

    @WrapOperation(method = "renderMountHealth", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/DrawContext;drawGuiTexture(Lnet/minecraft/util/Identifier;IIII)V", ordinal = 1))
    private void apoli$overrideFullMountHeartSprite(class_332 instance, class_2960 texture, int x, int y, int width, int height, Operation<Void> original) {
        apoli$getOverrideHudTexturePower(this.client.field_1724).ifPresentOrElse(
            p -> p.drawTexture(instance, texture, x, y, 88, 9, width, height),
            () -> original.call(instance, texture, x, y, width, height)
        );
    }

    @WrapOperation(method = "renderMountHealth", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/DrawContext;drawGuiTexture(Lnet/minecraft/util/Identifier;IIII)V", ordinal = 2))
    private void apoli$overrideHalfMountHeartSprite(class_332 instance, class_2960 texture, int x, int y, int width, int height, Operation<Void> original) {
        apoli$getOverrideHudTexturePower(this.client.field_1724).ifPresentOrElse(
            p -> p.drawTexture(instance, texture, x, y, 97, 9, width, height),
            () -> original.call(instance, texture, x, y, width, height)
        );
    }

}
