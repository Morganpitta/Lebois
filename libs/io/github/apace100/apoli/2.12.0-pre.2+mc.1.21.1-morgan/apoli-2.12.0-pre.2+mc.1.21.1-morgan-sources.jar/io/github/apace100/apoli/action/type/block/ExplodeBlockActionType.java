package io.github.apace100.apoli.action.type.block;

import io.github.apace100.apoli.action.ActionConfiguration;
import io.github.apace100.apoli.action.context.BlockActionContext;
import io.github.apace100.apoli.action.type.BlockActionType;
import io.github.apace100.apoli.action.type.BlockActionTypes;
import io.github.apace100.apoli.condition.BlockCondition;
import io.github.apace100.apoli.condition.context.BlockConditionContext;
import io.github.apace100.apoli.data.TypedDataObjectFactory;
import io.github.apace100.apoli.util.MiscUtil;
import io.github.apace100.calio.data.SerializableData;
import io.github.apace100.calio.data.SerializableDataTypes;
import org.jetbrains.annotations.NotNull;

import java.util.function.Predicate;
import net.minecraft.class_1927;
import net.minecraft.class_2338;
import net.minecraft.class_3218;

public class ExplodeBlockActionType extends BlockActionType {

    public static final TypedDataObjectFactory<ExplodeBlockActionType> DATA_FACTORY = TypedDataObjectFactory.simple(
        new SerializableData()
            .add("destructible", BlockCondition.DATA_TYPE, null)
            .add("indestructible", BlockCondition.DATA_TYPE, null)
            .add("destruction_type", SerializableDataTypes.DESTRUCTION_TYPE, class_1927.class_4179.field_18687)
            .add("create_fire", SerializableDataTypes.BOOLEAN, false)
            .add("power", SerializableDataTypes.NON_NEGATIVE_FLOAT)
            .add("indestructible_resistance", SerializableDataTypes.NON_NEGATIVE_FLOAT, 10.0F),
        data -> new ExplodeBlockActionType(
            data.get("destructible"),
            data.get("indestructible"),
            data.get("destruction_type"),
            data.get("create_fire"),
            data.get("power"),
            data.get("indestructible_resistance")
        ),
        (actionType, serializableData) -> serializableData.instance()
            .set("destructible", actionType.destructibleCondition)
            .set("indestructible", actionType.indestructibleCondition)
            .set("destruction_type", actionType.destructionType)
            .set("create_fire", actionType.createFire)
            .set("power", actionType.power)
            .set("indestructible_resistance", actionType.indestructibleResistance)
    );

    private final BlockCondition destructibleCondition;
    private final BlockCondition indestructibleCondition;

    private final class_1927.class_4179 destructionType;
    private final boolean createFire;

    private final float power;
    private final float indestructibleResistance;

    public ExplodeBlockActionType(BlockCondition destructibleCondition, BlockCondition indestructibleCondition, class_1927.class_4179 destructionType, boolean createFire, float power, float indestructibleResistance) {
        this.destructibleCondition = destructibleCondition;
        this.indestructibleCondition = indestructibleCondition;
        this.destructionType = destructionType;
        this.createFire = createFire;
        this.power = power;
        this.indestructibleResistance = indestructibleResistance;
    }

    @Override
    public void accept(BlockActionContext context) {

        class_3218 world = context.world();
        class_2338 pos = context.pos();

        Predicate<BlockConditionContext> behaviorCondition = indestructibleCondition;
        if (destructibleCondition != null) {
            behaviorCondition = MiscUtil.combineOr(destructibleCondition.negate(), behaviorCondition);
        }

        MiscUtil.createExplosion(
            world,
            pos.method_46558(),
            power,
            createFire,
            destructionType,
            MiscUtil.createExplosionBehavior(behaviorCondition, indestructibleResistance)
        );

    }

    @Override
    public @NotNull ActionConfiguration<?> getConfig() {
        return BlockActionTypes.EXPLODE;
    }

}
