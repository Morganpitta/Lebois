package io.github.apace100.apoli.mixin;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import com.llamalad7.mixinextras.injector.v2.WrapWithCondition;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import io.github.apace100.apoli.access.*;
import io.github.apace100.apoli.component.PowerHolderComponent;
import io.github.apace100.apoli.data.ApoliDamageTypes;
import io.github.apace100.apoli.networking.packet.s2c.SyncAttackerS2CPacket;
import io.github.apace100.apoli.power.type.*;
import io.github.apace100.apoli.util.InventoryUtil;
import io.github.apace100.apoli.util.SyncStatusEffectsUtil;
import net.fabricmc.fabric.api.networking.v1.PlayerLookup;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_1282;
import net.minecraft.class_1291;
import net.minecraft.class_1293;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1320;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_3222;
import net.minecraft.class_3486;
import net.minecraft.class_3610;
import net.minecraft.class_4174;
import net.minecraft.class_5131;
import net.minecraft.class_5134;
import net.minecraft.class_5630;
import net.minecraft.class_6880;
import net.minecraft.class_8103;
import org.jetbrains.annotations.Nullable;
import org.objectweb.asm.Opcodes;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.Slice;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.LinkedList;
import java.util.List;
import java.util.Optional;

@SuppressWarnings({"OptionalUsedAsFieldOrParameterType", "unused"})
@Mixin(class_1309.class)
public abstract class LivingEntityMixin extends class_1297 implements ModifiableFoodEntity, MovingEntity, JumpingEntity {
    @Shadow
    protected abstract float getJumpVelocity();

    @Shadow
    public abstract float getMovementSpeed();

    @Shadow
    private Optional<class_2338> climbingPos;

    @Shadow
    public abstract boolean isHoldingOntoLadder();

    @Shadow
    public abstract void setHealth(float health);

    public LivingEntityMixin(class_1299<?> type, class_1937 world) {
        super(type, world);
    }

    @Inject(method = "onStatusEffectApplied", at = @At("TAIL"))
    private void apoli$updateStatusEffectWhenApplied(class_1293 effectInstance, class_1297 source, CallbackInfo ci) {
        SyncStatusEffectsUtil.sendStatusEffectUpdatePacket((class_1309) (Object) this, SyncStatusEffectsUtil.UpdateType.APPLY, effectInstance);
    }

    @Inject(method = "onStatusEffectUpgraded", at = @At("TAIL"))
    private void apoli$updateStatusEffectWhenUpgraded(class_1293 effectInstance, boolean reapplyEffect, class_1297 source, CallbackInfo ci) {
        SyncStatusEffectsUtil.sendStatusEffectUpdatePacket((class_1309) (Object) this, SyncStatusEffectsUtil.UpdateType.UPGRADE, effectInstance);
    }

    @Inject(method = "onStatusEffectRemoved", at = @At("TAIL"))
    private void apoli$updateStatusEffectWhenRemoved(class_1293 effectInstance, CallbackInfo ci) {
        SyncStatusEffectsUtil.sendStatusEffectUpdatePacket((class_1309) (Object) this, SyncStatusEffectsUtil.UpdateType.REMOVE, effectInstance);
    }

    @Inject(method = "clearStatusEffects", at = @At("RETURN"))
    private void apoli$updateStatusEffectWhenCleared(CallbackInfoReturnable<Boolean> cir) {
        SyncStatusEffectsUtil.sendStatusEffectUpdatePacket((class_1309) (Object) this, SyncStatusEffectsUtil.UpdateType.CLEAR, null);
    }

    @ModifyVariable(method = "addStatusEffect(Lnet/minecraft/entity/effect/StatusEffectInstance;Lnet/minecraft/entity/Entity;)Z", at = @At("HEAD"), argsOnly = true)
    private class_1293 apoli$modifyStatusEffect(class_1293 original) {

        class_6880<class_1291> effectType = original.method_5579();

        float amplifier = PowerHolderComponent.modify(this, ModifyStatusEffectAmplifierPowerType.class, original.method_5578(), p -> p.doesApply(effectType));
        float duration = PowerHolderComponent.modify(this, ModifyStatusEffectDurationPowerType.class, original.method_5584(), p -> p.doesApply(effectType));

        return new class_1293(
            effectType,
            Math.round(duration),
            Math.round(amplifier),
            original.method_5591(),
            original.method_5581(),
            original.method_5592(),
            ((HiddenEffectStatus) original).apoli$getHiddenEffect()
        );

    }

    @Inject(method = "setAttacker", at = @At("TAIL"))
    private void apoli$syncAttacker(class_1309 attacker, CallbackInfo ci) {

        if (this.method_37908().field_9236) {
            return;
        }

        Optional<Integer> attackerId = Optional.ofNullable(this.attacker).map(class_1297::method_5628);
        SyncAttackerS2CPacket syncAttackerPacket = new SyncAttackerS2CPacket(this.method_5628(), attackerId);

        for (class_3222 player : PlayerLookup.tracking(this)) {
            ServerPlayNetworking.send(player, syncAttackerPacket);
        }

    }

    @ModifyReturnValue(method = "canWalkOnFluid", at = @At("RETURN"))
    private boolean apoli$letEntitiesWalkOnFluid(boolean original, class_3610 fluidState) {
        return original
            || PowerHolderComponent.hasPowerType(this, WalkOnFluidPowerType.class, p -> fluidState.method_15767(p.getFluidTag()));
    }

    @ModifyVariable(method = "heal", at = @At("HEAD"), argsOnly = true)
    private float modifyHealingApplied(float originalValue) {
        return PowerHolderComponent.modify(this, ModifyHealingPowerType.class, originalValue);
    }

    @Unique
    private boolean apoli$hasModifiedDamage;

    @Unique
    private Optional<Boolean> apoli$shouldApplyArmor = Optional.empty();

    @Unique
    private Optional<Boolean> apoli$shouldDamageArmor = Optional.empty();

    @ModifyExpressionValue(method = "onDamaged", at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/damage/DamageSources;generic()Lnet/minecraft/entity/damage/DamageSource;"))
    private class_1282 apoli$overrideDamageSourceOnSync(class_1282 original, class_1282 source) {
        return this.method_48923().method_48795(ApoliDamageTypes.SYNC_DAMAGE_SOURCE);
    }

    @ModifyVariable(method = "damage", at = @At("HEAD"), argsOnly = true)
    private float apoli$modifyDamageTaken(float original, class_1282 source, float amount) {

        if (source.method_49708(ApoliDamageTypes.SYNC_DAMAGE_SOURCE)) {
            return original;
        }

        class_1309 thisAsLiving = (class_1309) (Object) this;
        float newValue = original;

        if (source.method_5529() != null && source.method_48789(class_8103.field_42247)) {
            newValue = PowerHolderComponent.modify(source.method_5529(), ModifyProjectileDamagePowerType.class, original,
                p -> p.doesApply(source, original, thisAsLiving),
                p -> p.executeActions(thisAsLiving));
        } else if (source.method_5529() != null) {
            newValue = PowerHolderComponent.modify(source.method_5529(), ModifyDamageDealtPowerType.class, original,
                p -> p.doesApply(source, original, thisAsLiving),
                p -> p.executeActions(thisAsLiving));
        }

        float intermediateValue = newValue;
        newValue = PowerHolderComponent.modify(this, ModifyDamageTakenPowerType.class, intermediateValue,
            p -> p.doesApply(source, intermediateValue),
            p -> p.executeActions(source.method_5529()));

        apoli$hasModifiedDamage = newValue != original;
        List<ModifyDamageTakenPowerType> modifyDamageTakenPowers = PowerHolderComponent.getPowerTypes(this, ModifyDamageTakenPowerType.class)
            .stream()
            .filter(mdtp -> mdtp.doesApply(source, original))
            .toList();

        long wantArmor = modifyDamageTakenPowers
            .stream()
            .filter(mdtp -> mdtp.modifiesArmorApplicance() && mdtp.shouldApplyArmor())
            .count();
        long dontWantArmor = modifyDamageTakenPowers
            .stream()
            .filter(mdtp -> mdtp.modifiesArmorApplicance() && !mdtp.shouldApplyArmor())
            .count();
        apoli$shouldApplyArmor = wantArmor == dontWantArmor ? Optional.empty() : Optional.of(wantArmor > dontWantArmor);

        long wantDamage = modifyDamageTakenPowers
            .stream()
            .filter(mdtp -> mdtp.modifiesArmorDamaging() && mdtp.shouldDamageArmor())
            .count();
        long dontWantDamage = modifyDamageTakenPowers
            .stream()
            .filter(mdtp -> mdtp.modifiesArmorDamaging() && !mdtp.shouldDamageArmor())
            .count();
        apoli$shouldDamageArmor = wantDamage == dontWantDamage ? Optional.empty() : Optional.of(wantDamage > dontWantDamage);

        return newValue;

    }

    @ModifyExpressionValue(method = "applyArmorToDamage", at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/damage/DamageSource;isIn(Lnet/minecraft/registry/tag/TagKey;)Z"))
    private boolean apoli$allowApplyingOrDamagingArmor(boolean original, class_1282 source, float amount) {

        if (apoli$shouldApplyArmor.isEmpty() && (original && apoli$shouldDamageArmor.orElse(false))) {
            this.damageArmor(source, amount);
        }

        return apoli$shouldApplyArmor
            .map(result -> !result)
            .orElse(original);

    }

    @WrapWithCondition(method = "applyArmorToDamage", at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/LivingEntity;damageArmor(Lnet/minecraft/entity/damage/DamageSource;F)V"))
    private boolean apoli$allowDamagingArmor(class_1309 instance, class_1282 source, float amount) {
        return apoli$shouldDamageArmor.orElse(true);
    }

    @ModifyExpressionValue(method = "applyArmorToDamage", at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/DamageUtil;getDamageLeft(Lnet/minecraft/entity/LivingEntity;FLnet/minecraft/entity/damage/DamageSource;FF)F"))
    private float apoli$allowApplyingArmor(float modified, class_1282 source, float original) {
        return apoli$shouldApplyArmor.orElse(true)
            ? modified
            : original;
    }

    @ModifyExpressionValue(method = "damage", at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/LivingEntity;isDead()Z", ordinal = 0))
    private boolean apoli$preventHitIfDamageIsZero(boolean original, class_1282 source, float amount) {
        return original || apoli$hasModifiedDamage && amount <= 0.0F;
    }

    @Inject(method = "damage", at = @At("RETURN"), slice = @Slice(from = @At(value = "INVOKE", target = "Lnet/minecraft/entity/LivingEntity;isSleeping()Z")))
    private void apoli$invokeHitActions(class_1282 source, float amount, CallbackInfoReturnable<Boolean> cir) {

        if (!cir.getReturnValue()) {
            return;
        }

        class_1297 attacker = source.method_5529();

        PowerHolderComponent.withPowerTypes(this, ActionWhenHitPowerType.class, p -> p.doesApply(attacker, source, amount), p -> p.whenHit(attacker));
        PowerHolderComponent.withPowerTypes(attacker, ActionOnHitPowerType.class, p -> p.doesApply(this, source, amount), p -> p.onHit(this));

        PowerHolderComponent.withPowerTypes(this, ActionWhenDamageTakenPowerType.class, p -> p.doesApply(source, amount), ActionWhenDamageTakenPowerType::whenHit);
        PowerHolderComponent.withPowerTypes(this, AttackerActionWhenHitPowerType.class, p -> p.doesApply(source, amount), p -> p.whenHit(attacker));

        PowerHolderComponent.withPowerTypes(attacker, SelfActionOnHitPowerType.class, p -> p.doesApply(this, source, amount), SelfActionOnHitPowerType::onHit);
        PowerHolderComponent.withPowerTypes(attacker, TargetActionOnHitPowerType.class, p -> p.doesApply(this, source, amount), p -> p.onHit(this));

    }

    @Inject(method = "damage", at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/LivingEntity;onDeath(Lnet/minecraft/entity/damage/DamageSource;)V"))
    private void invokeDeathAction(class_1282 source, float amount, CallbackInfoReturnable<Boolean> cir) {
        PowerHolderComponent.withPowerTypes(this, ActionOnDeathPowerType.class, p -> p.doesApply(source.method_5529(), source, amount), p -> p.onDeath(source.method_5529()));
    }

    @Inject(method = "damage", at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/LivingEntity;onDeath(Lnet/minecraft/entity/damage/DamageSource;)V"))
    private void invokeKillAction(class_1282 source, float amount, CallbackInfoReturnable<Boolean> cir) {
        PowerHolderComponent.withPowerTypes(source.method_5529(), SelfActionOnKillPowerType.class, p -> p.doesApply(this, source, amount), SelfActionOnKillPowerType::executeAction);
    }

    @ModifyExpressionValue(method = "baseTick", at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/LivingEntity;isWet()Z"))
    private boolean apoli$preventExtinguishingWhenPowerSwimming(boolean original) {

        if (this.method_5681() && this.method_5861(class_3486.field_15517) <= 0 && PowerHolderComponent.hasPowerType(this, SwimmingPowerType.class)) {
            return false;
        }

        else {
            return original;
        }

    }

    @Unique
    private boolean prevPowderSnowState = false;

    @Inject(method = "tickMovement", at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/LivingEntity;getFrozenTicks()I"))
    private void freezeEntityFromPower(CallbackInfo ci) {
        if(PowerHolderComponent.hasPowerType(this, FreezePowerType.class)) {
            this.prevPowderSnowState = this.field_27857;
            this.field_27857 = true;
        }
    }

    @Inject(method = "tickMovement", at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/LivingEntity;removePowderSnowSlow()V"))
    private void unfreezeEntityFromPower(CallbackInfo ci) {
        if(PowerHolderComponent.hasPowerType(this, FreezePowerType.class)) {
            this.field_27857 = this.prevPowderSnowState;
        }
    }

    @Inject(method = "canFreeze", at = @At("RETURN"), cancellable = true)
    private void allowFreezingPower(CallbackInfoReturnable<Boolean> cir) {
        if(PowerHolderComponent.hasPowerType(this, FreezePowerType.class)) {
            cir.setReturnValue(true);
        }
    }

    @Unique
    private boolean apoli$applySprintJumpingEffects;

    @Override
    public boolean apoli$applySprintJumpEffects() {
        return apoli$applySprintJumpingEffects;
    }

    // SPRINT_JUMP
    @ModifyReturnValue(method = "getJumpVelocity()F", at = @At("RETURN"))
    private float apoli$modifyJumpVelocity(float original) {

        float modified = PowerHolderComponent.modify(this, ModifyJumpPowerType.class, original, p -> true, ModifyJumpPowerType::executeAction);
        this.apoli$applySprintJumpingEffects = modified > 0;

        return modified;

    }

    @ModifyExpressionValue(method = "jump", at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/LivingEntity;isSprinting()Z"))
    private boolean apoli$shouldApplySprintJumpEffects(boolean original) {
        return original && this.apoli$applySprintJumpEffects();
    }

    // HOTBLOODED
    @ModifyReturnValue(method = "canHaveStatusEffect", at = @At("RETURN"))
    private boolean apoli$effectImmunity(boolean original, class_1293 effectInstance) {
        return original
            && !PowerHolderComponent.hasPowerType(this, EffectImmunityPowerType.class, p -> p.doesApply(effectInstance));
    }

    // CLIMBING
    @ModifyReturnValue(method = "isClimbing", at = @At("RETURN"))
    private boolean apoli$modifyClimbing(boolean original) {

        if (original) {
            return true;
        }

        List<ClimbingPowerType> climbingPowers = PowerHolderComponent.getPowerTypes(this, ClimbingPowerType.class);
        if (this.method_7325() || climbingPowers.isEmpty()) {
            return false;
        }

        this.climbingPos = Optional.of(this.method_24515());
        return true;

    }

    @ModifyReturnValue(method = "isHoldingOntoLadder", at = @At("RETURN"))
    private boolean apoli$overrideClimbHold(boolean original) {

        List<ClimbingPowerType> climbingPowers = PowerHolderComponent.getPowerTypes(this, ClimbingPowerType.class);
        if (climbingPowers.isEmpty()) {
            return original;
        }

        return climbingPowers
            .stream()
            .anyMatch(ClimbingPowerType::canHold);

    }

    // SLOW_FALLING
    @ModifyVariable(at = @At(value = "INVOKE", target = "Lnet/minecraft/world/World;getFluidState(Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/fluid/FluidState;"), method = "travel", name = "d", ordinal = 0)
    public double modifyFallingVelocity(double original) {

        if (this.method_18798().field_1351 > 0D) {
            return original;
        }

        if (ModifyFallingPowerType.shouldNegateFallDamage(this)) {
            this.field_6017 = 0;
        }

        return PowerHolderComponent.modify(this, ModifyFallingPowerType.class, original);

    }

    @Inject(method = "getAttributes", at = @At("RETURN"))
    private void apoli$setAttributeContainerOwner(CallbackInfoReturnable<class_5131> cir) {

        if (cir.getReturnValue() instanceof OwnableAttributeContainer ownableAttributeContainer) {
            ownableAttributeContainer.apoli$setOwner(this);
        }

    }

    @ModifyVariable(method = "travel", at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/LivingEntity;isOnGround()Z", opcode = Opcodes.GETFIELD, ordinal = 2))
    private float modifySlipperiness(float original) {
        return PowerHolderComponent.modify(this, ModifySlipperinessPowerType.class, original, p -> p.doesApply(method_37908(), method_23314()));
    }

    @ModifyExpressionValue(method = "damage", at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/LivingEntity;isDead()Z", ordinal = 1))
    private boolean apoli$preventDeath(boolean original, class_1282 source, float amount) {

        if (original && PreventDeathPowerType.doesPrevent(this, source, amount)) {
            this.setHealth(1.0F);
            return false;
        }

        return original;

    }

    @ModifyVariable(method = "eatFood", at = @At("HEAD"), argsOnly = true)
    private class_1799 apoli$modifyEatenStack(class_1799 original) {

        class_1309 thisAsLiving = (class_1309) (Object) this;
        if (thisAsLiving instanceof class_1657) {
            return original;
        }

        class_5630 newStackRef = InventoryUtil.createStackReference(original);
        List<ModifyFoodPowerType> modifyFoodPowers = PowerHolderComponent.getPowerTypes(this, ModifyFoodPowerType.class)
            .stream()
            .filter(mfp -> mfp.doesApply(original))
            .toList();

        for (ModifyFoodPowerType modifyFoodPower : modifyFoodPowers) {
            modifyFoodPower.setConsumedItemStackReference(newStackRef);
        }

        EdibleItemPowerType.get(original.method_7972(), this).ifPresent(this::apoli$setEdibleItemPower);

        this.apoli$setCurrentModifyFoodPowers(modifyFoodPowers);
        this.apoli$setOriginalFoodStack(original);

        return newStackRef.method_32327();

    }

    @ModifyVariable(method = "eatFood", at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/LivingEntity;applyFoodEffects(Lnet/minecraft/component/type/FoodComponent;)V", shift = At.Shift.AFTER), argsOnly = true)
    private class_1799 apoli$restoreOriginalEatenStack(class_1799 modified) {
        class_1799 original = this.apoli$getOriginalFoodStack();
        return original == null
            ? modified
            : original;
    }

    @ModifyReturnValue(method = "eatFood", at = @At("RETURN"))
    private class_1799 apoli$modifyCustomFoodAndCleanUp(class_1799 original) {

        EdibleItemPowerType edibleItemPower = this.apoli$getEdibleItemPower();
        class_1799 result = original;

        modifyCustomFood:
        if (edibleItemPower != null) {

            edibleItemPower.executeEntityAction();

            class_5630 newStackRef = InventoryUtil.createStackReference(original);
            class_5630 resultStackRef = edibleItemPower.executeItemActions(newStackRef);

            class_1799 newStack = newStackRef.method_32327();
            class_1799 resultStack = resultStackRef.method_32327();

            if (resultStackRef == class_5630.field_27860) {
                result = newStack;
                break modifyCustomFood;
            }

            else if (newStack.method_7960()) {
                result = resultStack;
                break modifyCustomFood;
            }

            else if (class_1799.method_7973(resultStack, newStack)) {
                newStack.method_7933(1);
            }

            else if ((class_1309) (Object) this instanceof class_1657 player && !player.method_7337()) {
                player.method_31548().method_7398(resultStack);
            }

            else {
                InventoryUtil.throwItem(this, resultStack, false, false);
            }

            result = newStack;

        }

        this.apoli$setCurrentModifyFoodPowers(new LinkedList<>());
        this.apoli$setOriginalFoodStack(null);
        this.apoli$setEdibleItemPower(null);

        return result;

    }

    @Inject(method = "applyFoodEffects", at = @At("HEAD"), cancellable = true)
    private void apoli$preventApplyingFoodEffects(class_4174 component, CallbackInfo ci) {
        if (this.apoli$getCurrentModifyFoodPowers().stream().anyMatch(ModifyFoodPowerType::doesPreventEffects)) {
            ci.cancel();
        }
    }

    @Shadow @Nullable private class_1309 attacker;

    @Shadow public abstract void damageArmor(class_1282 source, float amount);

    @Shadow public abstract int getArmor();

    @Shadow public abstract class_5131 getAttributes();

    @Shadow public abstract boolean isClimbing();

    @Shadow public abstract boolean isDead();

    @Shadow public abstract double getAttributeValue(class_6880<class_1320> attribute);

    @Shadow public abstract float getArmorVisibility();

    @Shadow public abstract boolean method_5643(class_1282 source, float amount);

    @Shadow protected abstract void onStatusEffectRemoved(class_1293 effect);

    @Shadow public float sidewaysSpeed;

    @Shadow public float forwardSpeed;

    @Shadow public abstract double getAttributeBaseValue(class_6880<class_1320> attribute);

    @Inject(method = "getOffGroundSpeed", at = @At("RETURN"), cancellable = true)
    private void modifyFlySpeed(CallbackInfoReturnable<Float> cir) {
        cir.setReturnValue(PowerHolderComponent.modify(this, ModifyAirSpeedPowerType.class, cir.getReturnValue()));
    }

    @WrapOperation(method = "getAttackDistanceScalingFactor", at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/LivingEntity;isInvisible()Z"))
    private boolean apoli$specificallyInvisibleTo(class_1309 livingEntity, Operation<Boolean> original, @Nullable class_1297 viewer) {

        List<InvisibilityPowerType> invisibilityPowers = PowerHolderComponent.getPowerTypes(livingEntity, InvisibilityPowerType.class, true);
        if (viewer == null || invisibilityPowers.isEmpty()) {
            return original.call(livingEntity);
        }

        return invisibilityPowers
            .stream()
            .anyMatch(p -> p.isActive() && p.doesApply(viewer));

    }

    @ModifyExpressionValue(method = "jump", at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/LivingEntity;isSprinting()Z"))
    private boolean apoli$cancelOutJumpVelocityIfNotMovingWithSprintPower(boolean original) {
        // The movement check is here so this doesn't happen if the player is moving at a sprinting amount.
        if (PowerHolderComponent.hasPowerType(this, SprintingPowerType.class) && this.apoli$getHorizontalMovementValue() < this.getAttributeValue(class_5134.field_23719)) {
            return false;
        }
        return original;
    }

    @Unique
    private List<ModifyFoodPowerType> apoli$currentModifyFoodPowers = new LinkedList<>();

    @Unique
    private class_1799 apoli$originalFoodStack;

    @Unique
    private EdibleItemPowerType apoli$edibleItemPower;

    @Override
    public List<ModifyFoodPowerType> apoli$getCurrentModifyFoodPowers() {
        return apoli$currentModifyFoodPowers;
    }

    @Override
    public void apoli$setCurrentModifyFoodPowers(List<ModifyFoodPowerType> powers) {
        apoli$currentModifyFoodPowers = powers;
    }

    @Override
    public class_1799 apoli$getOriginalFoodStack() {
        return apoli$originalFoodStack;
    }

    @Override
    public void apoli$setOriginalFoodStack(class_1799 original) {
        apoli$originalFoodStack = original;
    }

    @Override
    public EdibleItemPowerType apoli$getEdibleItemPower() {
        return apoli$edibleItemPower;
    }

    @Override
    public void apoli$setEdibleItemPower(EdibleItemPowerType power) {
        this.apoli$edibleItemPower = power;
    }

    @Inject(method = "baseTick", at = @At("TAIL"))
    private void updateItemStackHolder(CallbackInfo ci) {
        InventoryUtil.forEachStack(this, stack -> ((EntityLinkedItemStack) stack).apoli$setEntity(this));
    }

}
