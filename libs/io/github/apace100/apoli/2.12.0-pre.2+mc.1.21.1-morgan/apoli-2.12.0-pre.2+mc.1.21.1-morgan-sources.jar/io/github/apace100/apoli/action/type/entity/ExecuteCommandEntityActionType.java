package io.github.apace100.apoli.action.type.entity;

import io.github.apace100.apoli.Apoli;
import io.github.apace100.apoli.action.ActionConfiguration;
import io.github.apace100.apoli.action.context.EntityActionContext;
import io.github.apace100.apoli.action.type.EntityActionType;
import io.github.apace100.apoli.action.type.EntityActionTypes;
import io.github.apace100.apoli.data.TypedDataObjectFactory;
import io.github.apace100.calio.data.SerializableData;
import io.github.apace100.calio.data.SerializableDataTypes;
import net.minecraft.class_1297;
import net.minecraft.class_2165;
import net.minecraft.class_2168;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;
import org.jetbrains.annotations.NotNull;

public class ExecuteCommandEntityActionType extends EntityActionType {

    public static final TypedDataObjectFactory<ExecuteCommandEntityActionType> DATA_FACTORY = TypedDataObjectFactory.simple(
        new SerializableData()
            .add("command", SerializableDataTypes.STRING),
        data -> new ExecuteCommandEntityActionType(
            data.get("command")
        ),
        (actionType, serializableData) -> serializableData.instance()
            .set("command", actionType.command)
    );

    private final String command;

    public ExecuteCommandEntityActionType(String command) {
        this.command = command;
    }

    @Override
    public void accept(EntityActionContext context) {

        class_1297 entity = context.entity();

        if (!(entity.method_37908() instanceof class_3218 serverWorld)) {
            return;
        }

        MinecraftServer server = serverWorld.method_8503();
        class_2168 commandSource = entity.method_5671()
            .method_9206(Apoli.config.executeCommand.permissionLevel)
            .method_36321(class_2165.field_17395);

        if (Apoli.config.executeCommand.showOutput) {

            class_2165 output = entity instanceof class_3222 serverPlayer && serverPlayer.field_13987 != null
                ? serverPlayer
                : server;

            commandSource = commandSource.method_36321(output);

        }

        server.method_3734().method_44252(commandSource, command);

    }

    @Override
    public @NotNull ActionConfiguration<?> getConfig() {
        return EntityActionTypes.EXECUTE_COMMAND;
    }

}
