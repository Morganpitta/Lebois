package io.github.apace100.apoli.command;

import com.mojang.brigadier.arguments.BoolArgumentType;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.tree.CommandNode;
import com.mojang.brigadier.tree.LiteralCommandNode;
import com.mojang.serialization.JsonOps;
import io.github.apace100.apoli.Apoli;
import io.github.apace100.apoli.command.argument.PowerArgumentType;
import io.github.apace100.apoli.command.argument.PowerHolderArgumentType;
import io.github.apace100.apoli.command.argument.suggestion.PowerSuggestionProvider;
import io.github.apace100.apoli.component.PowerHolderComponent;
import io.github.apace100.apoli.power.Power;
import io.github.apace100.apoli.util.JsonTextFormatter;
import io.github.apace100.apoli.util.MiscUtil;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import it.unimi.dsi.fastutil.objects.ObjectOpenHashSet;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Function;
import java.util.stream.Collectors;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_2168;
import net.minecraft.class_2232;
import net.minecraft.class_2561;
import net.minecraft.class_2564;
import net.minecraft.class_2568;
import net.minecraft.class_2583;
import net.minecraft.class_2960;

import static net.minecraft.class_2170.method_9244;
import static net.minecraft.class_2170.method_9247;

public class PowerCommand {

	public static class_2960 POWER_SOURCE = Apoli.identifier("command");

	public static void register(CommandNode<class_2168> baseNode) {

		//	The main node of the command
		var powerNode = method_9247("power")
			.requires(source -> source.method_9259(2))
			.build();

		//	Add the sub-nodes as children of the main node
		powerNode.addChild(GrantNode.get());
		powerNode.addChild(RevokeNode.get());
		powerNode.addChild(ListNode.get());
		powerNode.addChild(HasNode.get());
		powerNode.addChild(SourcesNode.get());
		powerNode.addChild(RemoveNode.get());
		powerNode.addChild(ClearNode.get());
		powerNode.addChild(DumpNode.get());

		//	Add the main node as a child of the base node
		baseNode.addChild(powerNode);

	}

	public static class GrantNode {

		public static LiteralCommandNode<class_2168> get() {
			return method_9247("grant")
				.then(method_9244("targets", PowerHolderArgumentType.holders())
					.then(method_9244("power", PowerArgumentType.power())
						.executes(context -> execute(context, false))
						.then(method_9244("source", class_2232.method_9441())
							.executes(context -> execute(context, true))))).build();
		}

		public static int execute(CommandContext<class_2168> context, boolean specifiedSource) throws CommandSyntaxException {

			List<class_1309> targets = PowerHolderArgumentType.getHolders(context, "targets");
			Power power = PowerArgumentType.getPower(context, "power");

			class_2960 source = specifiedSource
				? class_2232.method_9443(context, "source")
				: POWER_SOURCE;

			class_2168 commandSource = context.getSource();
			List<class_1309> processedTargets = targets.stream()
				.filter(e -> PowerHolderComponent.grantPower(e, power, source, true))
				.toList();

			if (processedTargets.isEmpty()) {

				if (targets.size() == 1) {
					commandSource.method_9213(class_2561.method_43469("commands.apoli.grant.fail.single", targets.getFirst().method_5477(), power.getName(), source.toString()));
				}

				else {
					commandSource.method_9213(class_2561.method_43469("commands.apoli.grant.fail.multiple", targets.size(), power.getName(), source.toString()));
				}

			}

			else if (specifiedSource) {

				if (processedTargets.size() == 1) {
					commandSource.method_9226(() -> class_2561.method_43469("commands.apoli.grant_from_source.success.single", processedTargets.getFirst().method_5477(), power.getName(), source.toString()), true);
				}

				else {
					commandSource.method_9226(() -> class_2561.method_43469("commands.apoli.grant_from_source.success.multiple", processedTargets.size(), power.getName(), source.toString()), true);
				}

			}

			else {

				if (processedTargets.size() == 1) {
					commandSource.method_9226(() -> class_2561.method_43469("commands.apoli.grant.success.single", processedTargets.getFirst().method_5477(), power.getName()), true);
				}

				else {
					commandSource.method_9226(() -> class_2561.method_43469("commands.apoli.grant.success.multiple", processedTargets.size(), power.getName()), true);
				}

			}

			return processedTargets.size();

		}

	}

	public static class RevokeNode {

		public static LiteralCommandNode<class_2168> get() {
			return method_9247("revoke")
				.then(method_9244("targets", PowerHolderArgumentType.holders())
					.then(method_9244("power", PowerArgumentType.power())
						.suggests(PowerSuggestionProvider.powersFromEntities("targets"))
						.executes(context -> executeSingle(context, false))
						.then(method_9244("source", class_2232.method_9441())
							.executes(context -> executeSingle(context, true))))
					.then(method_9247("all")
						.then(method_9244("source", class_2232.method_9441())
							.executes(RevokeNode::executeAll)))).build();
		}

		public static int executeSingle(CommandContext<class_2168> context, boolean specifiedSource) throws CommandSyntaxException {

			List<class_1309> targets = PowerHolderArgumentType.getHolders(context, "targets");
			Power power = PowerArgumentType.getPower(context, "power");

			class_2960 source = specifiedSource
				? class_2232.method_9443(context, "source")
				: POWER_SOURCE;

			class_2168 commandSource = context.getSource();
			List<class_1309> processedTargets = targets.stream()
				.filter(target -> PowerHolderComponent.revokePower(target, power, source, true))
				.toList();

			if (processedTargets.isEmpty()) {

				if (targets.size() == 1) {
					commandSource.method_9213(class_2561.method_43469("commands.apoli.revoke.fail.single", targets.getFirst().method_5477(), power.getName(), source.toString()));
				}

				else {
					commandSource.method_9213(class_2561.method_43469("commands.apoli.revoke.fail.multiple", power.getName(), source.toString()));
				}

			}

			else if (specifiedSource) {

				if (processedTargets.size() == 1) {
					commandSource.method_9226(() -> class_2561.method_43469("commands.apoli.revoke_from_source.success.single", processedTargets.getFirst().method_5477(), power.getName(), source.toString()), true);
				}

				else {
					commandSource.method_9226(() -> class_2561.method_43469("commands.apoli.revoke_from_source.success.multiple", processedTargets.size(), power.getName(), source.toString()), true);
				}

			}

			else {

				if (processedTargets.size() == 1) {
					commandSource.method_9226(() -> class_2561.method_43469("commands.apoli.revoke.success.single", processedTargets.getFirst().method_5477(), power.getName()), true);
				}

				else {
					commandSource.method_9226(() -> class_2561.method_43469("commands.apoli.revoke.success.multiple", processedTargets.size(), power.getName()), true);
				}

			}

			return processedTargets.size();

		}

		public static int executeAll(CommandContext<class_2168> context) throws CommandSyntaxException {

			List<class_1309> targets = PowerHolderArgumentType.getHolders(context, "targets");
			class_2960 source = class_2232.method_9443(context, "source");

			class_2168 commandSource = context.getSource();
			List<class_1309> processedTargets = new ObjectArrayList<>();

			AtomicInteger revokedPowers = new AtomicInteger();
			for (class_1309 target : targets) {

				int revokedPowersFromSource = PowerHolderComponent.revokeAllPowersFromSource(target, source, true);
				revokedPowers.accumulateAndGet(revokedPowersFromSource, Integer::sum);

				if (revokedPowersFromSource > 0) {
					processedTargets.add(target);
				}

			}

			if (processedTargets.isEmpty()) {

				if (targets.size() == 1) {
					commandSource.method_9213(class_2561.method_43469("commands.apoli.revoke_all.fail.single", targets.getFirst().method_5477(), source.toString()));
				}

				else {
					commandSource.method_9213(class_2561.method_54159("commands.apoli.revoke_all.fail.multiple", source));
				}

			}

			else {

				if (processedTargets.size() == 1) {
					commandSource.method_9226(() -> class_2561.method_43469("commands.apoli.revoke_all.success.single", processedTargets.getFirst().method_5477(), revokedPowers.get(), source.toString()), true);
				}

				else {
					commandSource.method_9226(() -> class_2561.method_43469("commands.apoli.revoke_all.success.multiple", processedTargets.size(), revokedPowers.get(), source.toString()), true);
				}

			}

			return revokedPowers.get();

		}

	}

	public static class ListNode {

		public static LiteralCommandNode<class_2168> get() {
			return method_9247("list")
				.executes(context -> execute(context, true, false))
				.then(method_9244("target", PowerHolderArgumentType.holder())
					.executes(context -> execute(context, false, false))
					.then(method_9244("subPowers", BoolArgumentType.bool())
						.executes(context -> execute(context, false, BoolArgumentType.getBool(context, "subPowers"))))).build();
		}

		public static int execute(CommandContext<class_2168> context, boolean self, boolean includeSubPowers) throws CommandSyntaxException {

			class_2168 commandSource = context.getSource();
			class_1297 target = self
				? commandSource.method_9229()
				: PowerHolderArgumentType.getHolder(context, "target");

			PowerHolderComponent powerComponent = PowerHolderComponent.KEY
				.maybeGet(target)
				.orElseThrow(() -> PowerHolderArgumentType.HOLDER_NOT_FOUND.create(target.method_5477()));

			List<class_2561> powersTooltip = new ObjectArrayList<>();
			for (Power power : powerComponent.getPowers(includeSubPowers)) {

				List<class_2561> sourcesTooltip = powerComponent.getSources(power)
					.stream()
					.map(class_2561::method_54154)
					.toList();

				class_2561 joinedSourcesTooltip = class_2561.method_43469("commands.apoli.list.sources", class_2564.method_37112(sourcesTooltip, class_2561.method_30163(", ")));
				class_2568 sourceHoverEvent = new class_2568(class_2568.class_5247.field_24342, joinedSourcesTooltip);

				powersTooltip.add(class_2561
					.method_43470(power.getId().toString())
					.setStyle(class_2583.field_24360.method_10949(sourceHoverEvent)));

			}

			if (powersTooltip.isEmpty()) {
				commandSource.method_9213(class_2561.method_43469("commands.apoli.list.fail", target.method_5477()));
			}

			else {
				commandSource.method_9226(() -> class_2561.method_43469("commands.apoli.list.pass", target.method_5477(), powersTooltip.size(), class_2564.method_37112(powersTooltip, class_2561.method_30163(", "))), false);
			}

			return powersTooltip.size();

		}

	}

	public static class HasNode {

		public static LiteralCommandNode<class_2168> get() {
			return method_9247("has")
				.then(method_9244("targets", PowerHolderArgumentType.holders())
					.then(method_9244("power", PowerArgumentType.power())
						.executes(HasNode::execute))).build();
		}

		public static int execute(CommandContext<class_2168> context) throws CommandSyntaxException {

			List<class_1309> targets = PowerHolderArgumentType.getHolders(context, "targets");
			Power power = PowerArgumentType.getPower(context, "power");

			class_2168 commandSource = context.getSource();
			List<class_1309> processedTargets = targets.stream()
				.filter(target -> PowerHolderComponent.KEY.get(target).hasPower(power))
				.toList();

			if (processedTargets.isEmpty()) {

				if (targets.size() == 1) {
					commandSource.method_9213(class_2561.method_43471("commands.execute.conditional.fail"));
				}

				else {
					commandSource.method_9213(class_2561.method_43469("commands.execute.conditional.fail_count", targets.size()));
				}

			}

			else {

				if (processedTargets.size() == 1) {
					commandSource.method_9226(() -> class_2561.method_43471("commands.execute.conditional.pass"), false);
				}

				else {
					commandSource.method_9226(() -> class_2561.method_43469("commands.execute.conditional.pass_count", processedTargets.size()), false);
				}

			}

			return processedTargets.size();

		}

	}

	public static class SourcesNode {

		public static LiteralCommandNode<class_2168> get() {
			return method_9247("sources")
				.then(method_9244("target", PowerHolderArgumentType.holder())
					.then(method_9244("power", PowerArgumentType.power())
						.suggests(PowerSuggestionProvider.powersFromEntity("target"))
						.executes(SourcesNode::execute)
						.then(method_9247("")))).build();
		}

		public static int execute(CommandContext<class_2168> context) throws CommandSyntaxException {

			class_1297 target = PowerHolderArgumentType.getHolder(context, "target");
			Power power = PowerArgumentType.getPower(context, "power");

			class_2168 commandSource = context.getSource();
			PowerHolderComponent powerComponent = PowerHolderComponent.KEY.get(target);

			List<class_2960> sources = powerComponent.getSources(power);
			String joinedSources = sources
				.stream()
				.map(class_2960::toString)
				.collect(Collectors.joining(", "));

			if (sources.isEmpty()) {
				commandSource.method_9213(class_2561.method_43469("commands.apoli.sources.fail", target.method_5477(), power.getName()));
			}

			else {
				commandSource.method_9226(() -> class_2561.method_43469("commands.apoli.sources.pass", target.method_5477(), sources.size(), power.getName(), joinedSources), false);
			}

			return sources.size();

		}

	}

	public static class RemoveNode {

		public static LiteralCommandNode<class_2168> get() {
			return method_9247("remove")
				.then(method_9244("targets", PowerHolderArgumentType.holders())
					.then(method_9244("power", PowerArgumentType.power())
						.suggests(PowerSuggestionProvider.powersFromEntities("targets"))
						.executes(RemoveNode::execute)
						.then(method_9247("")))).build();
		}

		public static int execute(CommandContext<class_2168> context) throws CommandSyntaxException {

			List<class_1309> targets = PowerHolderArgumentType.getHolders(context, "targets");
			Power power = PowerArgumentType.getPower(context, "power");

			class_2168 commandSource = context.getSource();
			List<class_1309> processedTargets = new ObjectArrayList<>();

			for (class_1309 target : targets) {

				Map<class_2960, Collection<Power>> powers = PowerHolderComponent.KEY.get(target).getSources(power)
					.stream()
					.collect(Collectors.toMap(Function.identity(), id -> ObjectOpenHashSet.of(power), MiscUtil.mergeCollections()));

				if (PowerHolderComponent.revokePowers(target, powers, true)) {
					processedTargets.add(target);
				}

			}

			if (processedTargets.isEmpty()) {

				if (targets.size() == 1) {
					commandSource.method_9213(class_2561.method_43469("commands.apoli.remove.fail.single", targets.getFirst().method_5477(), power.getName()));
				}

				else {
					commandSource.method_9213(class_2561.method_43469("commands.apoli.remove.fail.multiple", power.getName()));
				}

			}

			else {

				if (processedTargets.size() == 1) {
					commandSource.method_9226(() -> class_2561.method_43469("commands.apoli.remove.success.single", processedTargets.getFirst().method_5477(), power.getName()), true);
				}

				else {
					commandSource.method_9226(() -> class_2561.method_43469("commands.apoli.remove.success.multiple", processedTargets.size(), power.getName()), false);
				}

			}

			return processedTargets.size();

		}

	}

	public static class ClearNode {

		public static LiteralCommandNode<class_2168> get() {
			return method_9247("clear")
				.executes(context -> execute(context, true))
				.then(method_9244("targets", PowerHolderArgumentType.holders())
					.executes(context -> execute(context, false))).build();
		}

		public static int execute(CommandContext<class_2168> context, boolean self) throws CommandSyntaxException {

			List<class_1297> targets = new ObjectArrayList<>();
			List<class_1297> processedTargets = new ObjectArrayList<>();

			class_2168 commandSource = context.getSource();
			AtomicInteger clearedPowers = new AtomicInteger();

			if (self) {

				class_1297 selfEntity = commandSource.method_9229();

				PowerHolderComponent.KEY.maybeGet(selfEntity)
					.map(powerComponent -> targets.add(selfEntity))
					.orElseThrow(() -> PowerHolderArgumentType.HOLDER_NOT_FOUND.create(selfEntity.method_5477()));

			}

			else {
				targets.addAll(PowerHolderArgumentType.getHolders(context, "targets"));
			}

			for (class_1297 target : targets) {

				PowerHolderComponent component = PowerHolderComponent.KEY.get(target);
				List<class_2960> sources = component.getPowers(false)
					.stream()
					.map(component::getSources)
					.flatMap(Collection::stream)
					.toList();

				if (sources.isEmpty()) {
					continue;
				}

				clearedPowers.accumulateAndGet(PowerHolderComponent.revokeAllPowersFromAllSources(target, sources, true), Integer::sum);
				processedTargets.add(target);

			}

			if (processedTargets.isEmpty()) {

				if (targets.size() == 1) {
					commandSource.method_9213(class_2561.method_43469("commands.apoli.clear.fail.single", targets.getFirst().method_5477()));
				}

				else {
					commandSource.method_9213(class_2561.method_43471("commands.apoli.clear.fail.multiple"));
				}

			}

			else {

				if (processedTargets.size() == 1) {
					commandSource.method_9226(() -> class_2561.method_43469("commands.apoli.clear.success.single", processedTargets.getFirst().method_5477(), clearedPowers.get()), true);
				}

				else {
					commandSource.method_9226(() -> class_2561.method_43469("commands.apoli.clear.success.multiple", processedTargets.size(), clearedPowers.get()), true);
				}

			}

			return clearedPowers.get();

		}

	}

	public static class DumpNode {

		public static LiteralCommandNode<class_2168> get() {
			return method_9247("dump")
				.then(method_9244("power", PowerArgumentType.power())
					.executes(context -> execute(context, 4))
					.then(method_9244("indent", IntegerArgumentType.integer(0))
						.executes(context -> execute(context, IntegerArgumentType.getInteger(context, "indent"))))).build();
		}

		public static int execute(CommandContext<class_2168> context, int indent) throws CommandSyntaxException {

			Power power = PowerArgumentType.getPower(context, "power");
			class_2168 commandSource = context.getSource();

			return Power.DATA_TYPE.write(commandSource.method_30497().method_57093(JsonOps.INSTANCE), power)
				.ifSuccess(powerJson -> commandSource.method_9226(() -> new JsonTextFormatter(indent).apply(powerJson), false))
				.ifError(error -> commandSource.method_9213(class_2561.method_43470(error.message())))
				.mapOrElse(jsonElement -> 1, error -> 0);

		}

	}

}
