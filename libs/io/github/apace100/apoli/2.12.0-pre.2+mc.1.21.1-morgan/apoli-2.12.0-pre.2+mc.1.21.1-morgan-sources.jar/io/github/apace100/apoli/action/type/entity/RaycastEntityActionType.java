package io.github.apace100.apoli.action.type.entity;

import io.github.apace100.apoli.Apoli;
import io.github.apace100.apoli.action.ActionConfiguration;
import io.github.apace100.apoli.action.BiEntityAction;
import io.github.apace100.apoli.action.BlockAction;
import io.github.apace100.apoli.action.EntityAction;
import io.github.apace100.apoli.action.context.EntityActionContext;
import io.github.apace100.apoli.action.type.EntityActionType;
import io.github.apace100.apoli.action.type.EntityActionTypes;
import io.github.apace100.apoli.condition.BiEntityCondition;
import io.github.apace100.apoli.data.ApoliDataTypes;
import io.github.apace100.apoli.data.TypedDataObjectFactory;
import io.github.apace100.apoli.util.MiscUtil;
import io.github.apace100.apoli.util.Space;
import io.github.apace100.calio.data.SerializableData;
import io.github.apace100.calio.data.SerializableDataTypes;
import net.minecraft.class_1297;
import net.minecraft.class_1301;
import net.minecraft.class_1675;
import net.minecraft.class_2165;
import net.minecraft.class_2168;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_3222;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_3966;
import net.minecraft.class_5134;
import net.minecraft.server.MinecraftServer;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.joml.Vector3f;

import java.util.Optional;
import java.util.function.Predicate;
import java.util.function.UnaryOperator;

public class RaycastEntityActionType extends EntityActionType {

    public static final TypedDataObjectFactory<RaycastEntityActionType> DATA_FACTORY = TypedDataObjectFactory.simple(
        new SerializableData()
            .add("before_action", EntityAction.DATA_TYPE.optional(), Optional.empty())
            .add("hit_action", EntityAction.DATA_TYPE.optional(), Optional.empty())
            .add("miss_action", EntityAction.DATA_TYPE.optional(), Optional.empty())
            .add("bientity_action", BiEntityAction.DATA_TYPE.optional(), Optional.empty())
            .add("block_action", BlockAction.DATA_TYPE.optional(), Optional.empty())
            .add("bientity_condition", BiEntityCondition.DATA_TYPE.optional(), Optional.empty())
            .add("shape_type", SerializableDataTypes.SHAPE_TYPE, class_3959.class_3960.field_17559)
            .add("fluid_handling", SerializableDataTypes.FLUID_HANDLING, class_3959.class_242.field_1347)
            .add("direction", SerializableDataTypes.VECTOR.optional(), Optional.empty())
            .add("space", ApoliDataTypes.SPACE, Space.WORLD)
            .add("entity_distance", SerializableDataTypes.POSITIVE_DOUBLE.optional(), Optional.empty())
            .add("block_distance", SerializableDataTypes.POSITIVE_DOUBLE.optional(), Optional.empty())
            .add("distance", SerializableDataTypes.POSITIVE_DOUBLE.optional(), Optional.empty())
            .add("command_at_hit", SerializableDataTypes.STRING.optional(), Optional.empty())
            .add("command_along_ray", SerializableDataTypes.STRING.optional(), Optional.empty())
            .add("command_hit_offset", SerializableDataTypes.DOUBLE.optional(), Optional.empty())
            .add("command_step", SerializableDataTypes.DOUBLE, 1.0D)
            .add("command_along_ray_only_on_hit", SerializableDataTypes.BOOLEAN, false)
            .add("entity", SerializableDataTypes.BOOLEAN, true)
            .add("block", SerializableDataTypes.BOOLEAN, true),
        data -> new RaycastEntityActionType(
            data.get("before_action"),
            data.get("hit_action"),
            data.get("miss_action"),
            data.get("bientity_action"),
            data.get("block_action"),
            data.get("bientity_condition"),
            data.get("shape_type"),
            data.get("fluid_handling"),
            data.get("direction"),
            data.get("space"),
            data.get("entity_distance"),
            data.get("block_distance"),
            data.get("distance"),
            data.get("command_at_hit"),
            data.get("command_along_ray"),
            data.get("command_hit_offset"),
            data.get("command_step"),
            data.get("command_along_ray_only_on_hit"),
            data.get("entity"),
            data.get("block")
        ),
        (actionType, serializableData) -> serializableData.instance()
            .set("before_action", actionType.beforeAction)
            .set("hit_action", actionType.hitAction)
            .set("miss_action", actionType.missAction)
            .set("bientity_action", actionType.biEntityAction)
            .set("block_action", actionType.blockAction)
            .set("bientity_condition", actionType.biEntityCondition)
            .set("shape_type", actionType.shapeType)
            .set("fluid_handling", actionType.fluidHandling)
            .set("direction", actionType.direction)
            .set("space", actionType.space)
            .set("entity_distance", actionType.entityDistance)
            .set("block_distance", actionType.blockDistance)
            .set("distance", actionType.distance)
            .set("command_at_hit", actionType.commandAtHit)
            .set("command_along_ray", actionType.commandAlongRay)
            .set("command_hit_offset", actionType.commandHitOffset)
            .set("command_step", actionType.commandStep)
            .set("command_along_ray_only_on_hit", actionType.commandAlongRayOnlyOnHit)
            .set("entity", actionType.entity)
            .set("block", actionType.block)
    );

    private final Optional<EntityAction> beforeAction;
    private final Optional<EntityAction> hitAction;
    private final Optional<EntityAction> missAction;

    private final Optional<BiEntityAction> biEntityAction;
    private final Optional<BlockAction> blockAction;

    private final Optional<BiEntityCondition> biEntityCondition;

    private final class_3959.class_3960 shapeType;
    private final class_3959.class_242 fluidHandling;

    private final Optional<class_243> direction;
    private final Space space;

    private final Optional<Double> entityDistance;
    private final Optional<Double> blockDistance;
    private final Optional<Double> distance;

    private final Optional<String> commandAtHit;
    private final Optional<String> commandAlongRay;

    private final Optional<Double> commandHitOffset;
    private final double commandStep;

    private final boolean commandAlongRayOnlyOnHit;

    private final boolean entity;
    private final boolean block;

    public RaycastEntityActionType(Optional<EntityAction> beforeAction, Optional<EntityAction> hitAction, Optional<EntityAction> missAction, Optional<BiEntityAction> biEntityAction, Optional<BlockAction> blockAction, Optional<BiEntityCondition> biEntityCondition, class_3959.class_3960 shapeType, class_3959.class_242 fluidHandling, Optional<class_243> direction, Space space, Optional<Double> entityDistance, Optional<Double> blockDistance, Optional<Double> distance, Optional<String> commandAtHit, Optional<String> commandAlongRay, Optional<Double> commandHitOffset, double commandStep, boolean commandAlongRayOnlyOnHit, boolean entity, boolean block) {
        this.beforeAction = beforeAction;
        this.hitAction = hitAction;
        this.missAction = missAction;
        this.biEntityAction = biEntityAction;
        this.blockAction = blockAction;
        this.biEntityCondition = biEntityCondition;
        this.shapeType = shapeType;
        this.fluidHandling = fluidHandling;
        this.direction = direction;
        this.space = space;
        this.entityDistance = entityDistance;
        this.blockDistance = blockDistance;
        this.distance = distance;
        this.commandAtHit = commandAtHit;
        this.commandAlongRay = commandAlongRay;
        this.commandHitOffset = commandHitOffset;
        this.commandStep = commandStep;
        this.commandAlongRayOnlyOnHit = commandAlongRayOnlyOnHit;
        this.entity = entity;
        this.block = block;
    }

    @Override
    public void accept(EntityActionContext context) {

        beforeAction.ifPresent(self -> self.accept(context));

        Entity entity = context.entity();
        boolean success = false;

        HitResult result = null;
        Vec3d directionVec = direction
            .map(self -> this.transformDirection(entity, self))
            .orElseGet(() -> entity.getRotationVec(1.0F));

        Vec3d origin = MiscUtil.getPoseDependentEyePos(entity).add(context.offset());
        Vec3d destination = distance.map(directionVec::multiply).orElse(null);

        if (this.entity) {
            destination = origin.add(directionVec.multiply(this.getEntityReach(entity)));
            result = this.entityRaycast(entity, origin, destination);
        }

        if (this.block) {

            Vec3d blockDestination = origin.add(directionVec.multiply(this.getBlockReach(entity)));
            BlockHitResult blockResult = this.blockRaycast(entity, origin, blockDestination);

            if (blockResult.getType() != HitResult.Type.MISS && overrideHitResult(entity, result, blockResult)) {
                destination = blockDestination;
                result = blockResult;
            }

        }

        if (result != null && result.getType() != HitResult.Type.MISS) {

            success = true;

            if (commandAtHit.isPresent()) {

                Offset offset = this.getOffset(entity, result, directionVec);
                Vec3d hitPos = offset.apply(result.getPos());

                this.executeCommandAtHit(entity, hitPos);

            }

        }

        if (destination != null && commandAlongRay.isPresent() && (!commandAlongRayOnlyOnHit || success)) {
            this.executeCommandAtSteps(entity, origin, success ? result.getPos() : destination);
        }

        if (success) {

            switch (result) {
                case BlockHitResult blockResult ->
                    blockAction.ifPresent(self -> self.execute(entity.getWorld(), blockResult.getBlockPos(), Optional.of(blockResult.getSide())));
                case EntityHitResult entityResult ->
                    biEntityAction.ifPresent(self -> self.execute(entity, entityResult.getEntity()));
                default -> {
                    //  No-op; unsupported
                }
            }

            hitAction.ifPresent(self -> self.execute(entity));

        }

        else {
            missAction.ifPresent(self -> self.execute(entity));
        }

    }

    @Override
    public @NotNull ActionConfiguration<?> getConfig() {
        return EntityActionTypes.RAYCAST;
    }

    private record Offset(class_243 direction, double amount) implements UnaryOperator<class_243> {

        @Override
        public class_243 apply(class_243 vec) {
            return vec.method_1020(direction().method_1021(amount()));
        }

    }

    private class_3966 entityRaycast(class_1297 caster, class_243 origin, class_243 destination) {

        class_243 ray = destination.method_1020(origin);
        class_238 box = caster.method_5829().method_18804(ray).method_1014(1.0D);

        Predicate<class_1297> intersectPredicate = class_1301.field_6155
            .and(intersected -> biEntityCondition
                .map(condition -> condition.test(caster, intersected))
                .orElse(true));

        return class_1675.method_18075(
            caster,
            origin,
            destination,
            box,
            intersectPredicate,
            ray.method_1027()
        );

    }

    private class_3965 blockRaycast(class_1297 caster, class_243 origin, class_243 destination) {
        class_3959 context = new class_3959(origin, destination, shapeType, fluidHandling, caster);
        return caster.method_37908().method_17742(context);
    }

    private class_243 transformDirection(class_1297 entity, class_243 direction) {

        Vector3f normalizedDirection = new Vector3f((float) direction.method_10216(), (float) direction.method_10214(), (float) direction.method_10215()).normalize();
        space.toGlobal(normalizedDirection, entity);

        return new class_243(normalizedDirection);

    }

    private Offset getOffset(class_1297 entity, class_239 hitResult, class_243 direction) {

        if (commandHitOffset.isPresent()) {
            return new Offset(direction, commandHitOffset.get());
        }

        else {

            class_243 offsetDirection = direction;
            double offset = 0.0D;

            if (hitResult instanceof class_3965 blockResult) {

                class_2350 hitSide = blockResult.method_17780();

                switch (hitSide) {
                    case field_11033 ->
                        offset = entity.method_17682();
                    case field_11036 ->
                        offset = 0;
                    default -> {

                        double offsetX = hitSide.method_10148();
                        double offsetY = hitSide.method_10164();
                        double offsetZ = hitSide.method_10165();

                        offset = entity.method_17681() / 2;
                        offsetDirection = new class_243(offsetX, offsetY, offsetZ).method_22882();

                    }
                }

            }

            offset += 0.05;
            return new Offset(offsetDirection, offset);

        }

    }

    private static boolean overrideHitResult(class_1297 caster, @Nullable class_239 prev, class_239 next) {
        return prev == null
            || prev.method_17783() == class_239.class_240.field_1333
            || prev.method_24801(caster) > next.method_24801(caster);
    }

    private double getEntityReach(class_1297 entity) {
        return entityDistance
            .or(() -> distance)
            .orElseGet(() -> MiscUtil.getAttributeValueOrElse(entity, class_5134.field_47759, 1.0));
    }

    private double getBlockReach(class_1297 entity) {
        return blockDistance
            .or(() -> distance)
            .orElseGet(() -> MiscUtil.getAttributeValueOrElse(entity, class_5134.field_47758, 1.0));
    }

    private void executeCommandAtSteps(class_1297 entity, class_243 origin, class_243 destination) {

        MinecraftServer server = entity.method_5682();
        String commandAlongRay = this.commandAlongRay.orElse("");

        if (server == null || commandAlongRay.isEmpty()) {
            return;
        }

        class_243 direction = destination.method_1020(origin).method_1029();
        double distance = origin.method_1022(destination);

        class_2168 commandSource = entity.method_5671()
            .method_36321(class_2165.field_17395)
            .method_9206(Apoli.config.executeCommand.permissionLevel);

        if (Apoli.config.executeCommand.showOutput) {
            commandSource = commandSource.method_36321(entity instanceof class_3222 serverPlayer && serverPlayer.field_13987 != null
                ? serverPlayer
                : server);
        }

        for (double steps = 0; steps < distance; steps += commandStep) {

            class_243 offsetPos = direction.method_1021(steps);
            class_243 newPos = origin.method_1019(offsetPos);

            server.method_3734().method_44252(commandSource.method_9208(newPos), commandAlongRay);

        }

    }

    private void executeCommandAtHit(class_1297 entity, class_243 hitPos) {

        MinecraftServer server = entity.method_5682();
        String commandAtHit = this.commandAtHit.orElse("");

        if (server == null || commandAtHit.isEmpty()) {
            return;
        }

        class_2168 commandSource = entity.method_5671()
            .method_36321(class_2165.field_17395)
            .method_9208(hitPos)
            .method_9206(Apoli.config.executeCommand.permissionLevel);

        if (Apoli.config.executeCommand.showOutput) {
            commandSource = commandSource.method_36321(entity instanceof class_3222 serverPlayer && serverPlayer.field_13987 != null
                ? serverPlayer
                : server);
        }

        server.method_3734().method_44252(commandSource, commandAtHit);

    }

}
