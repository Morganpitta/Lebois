package io.github.apace100.apoli.action.context;

import io.github.apace100.apoli.condition.context.EntityConditionContext;
import io.github.apace100.apoli.util.context.ActionContext;
import net.minecraft.class_1297;
import net.minecraft.class_243;

public record EntityActionContext(class_1297 entity, class_243 offset) implements ActionContext<EntityConditionContext> {

	public EntityActionContext(class_1297 entity) {
		this(entity, class_243.field_1353);
	}

	@Override
	public EntityConditionContext forCondition() {
		return new EntityConditionContext(entity());
	}

}
