package io.github.apace100.apoli.loot.condition;

import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.apace100.apoli.component.PowerHolderComponent;
import io.github.apace100.apoli.data.ApoliDataTypes;
import io.github.apace100.apoli.power.PowerReference;
import java.util.Optional;
import net.minecraft.class_1297;
import net.minecraft.class_2960;
import net.minecraft.class_47;
import net.minecraft.class_5341;
import net.minecraft.class_5342;

public record PowerLootCondition(class_47.class_50 target, PowerReference power, Optional<class_2960> sourceId) implements class_5341 {

    public static final MapCodec<PowerLootCondition> MAP_CODEC = RecordCodecBuilder.mapCodec(instance -> instance.group(
        class_47.class_50.field_45792.optionalFieldOf("entity", class_47.class_50.field_935).forGetter(PowerLootCondition::target),
        ApoliDataTypes.POWER_REFERENCE.codec().fieldOf("power").forGetter(PowerLootCondition::power),
        class_2960.field_25139.optionalFieldOf("source").forGetter(PowerLootCondition::sourceId)
    ).apply(instance, PowerLootCondition::new));

    @Override
    public class_5342 method_29325() {
        return ApoliLootConditionTypes.POWER;
    }

    @Override
    public boolean test(class_47 lootContext) {
        class_1297 entity = lootContext.method_296(target().method_315());
        return PowerHolderComponent.KEY.maybeGet(entity)
            .map(this::hasPower)
            .orElse(false);
    }

    private boolean hasPower(PowerHolderComponent component) {
        return sourceId()
            .map(id -> component.hasPower(power(), id))
            .orElseGet(() -> component.hasPower(power()));
    }

}
