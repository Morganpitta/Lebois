package io.github.apace100.apoli.mixin;

import io.github.apace100.apoli.component.PowerHolderComponent;
import io.github.apace100.apoli.power.type.ParticlePowerType;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1937;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_4048;
import net.minecraft.class_4050;
import net.minecraft.class_746;
import net.minecraft.entity.*;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(EnvType.CLIENT)
@Mixin(class_1309.class)
public abstract class EntityParticleMixin extends class_1297 {

    @Shadow public abstract class_4048 method_18377(class_4050 pose);

    public EntityParticleMixin(class_1299<?> type, class_1937 world) {
        super(type, world);
    }

    @Inject(method = "tick", at = @At("HEAD"))
    private void apoli$emitParticles(CallbackInfo ci) {

        class_746 player = class_310.method_1551().field_1724;
        boolean inFirstPerson = class_310.method_1551().field_1690.method_31044().method_31034();

        if (player == null) {
            return;
        }

        double velocityX;
        double velocityY;
        double velocityZ;

        for (ParticlePowerType particlePower : PowerHolderComponent.getPowerTypes(this, ParticlePowerType.class)) {

            if (!particlePower.doesApply(player, inFirstPerson)) {
                continue;
            }

            class_243 spread = particlePower
                .getSpread()
                .method_18805(this.method_17681(), this.method_18381(this.method_18376()), this.method_17681());
            class_243 particlePos = this
                .method_19538()
                .method_1031(particlePower.getOffsetX(), particlePower.getOffsetY(), particlePower.getOffsetZ());

            if (particlePower.getCount() == 0) {

                velocityX = spread.method_10216() * particlePower.getSpeed();
                velocityY = spread.method_10214() * particlePower.getSpeed();
                velocityZ = spread.method_10215() * particlePower.getSpeed();

                this.method_37908().method_8466(particlePower.getParticle(), particlePower.shouldForce(), particlePos.method_10216(), particlePos.method_10214(), particlePos.method_10215(), velocityX, velocityY, velocityZ);

            } else {

                for (int i = 0; i < particlePower.getCount(); i++) {

                    class_243 newSpread = spread.method_18805(this.field_5974.method_43059(), this.field_5974.method_43059(), this.field_5974.method_43059());
                    class_243 newParticlePos = particlePos.method_1019(newSpread);

                    velocityX = (2.0 * this.field_5974.method_43058() - 1.0) * particlePower.getSpeed();
                    velocityY = (2.0 * this.field_5974.method_43058() - 1.0) * particlePower.getSpeed();
                    velocityZ = (2.0 * this.field_5974.method_43058() - 1.0) * particlePower.getSpeed();

                    this.method_37908().method_8466(particlePower.getParticle(), particlePower.shouldForce(), newParticlePos.method_10216(), newParticlePos.method_10214(), newParticlePos.method_10215(), velocityX, velocityY, velocityZ);

                }

            }

        }

    }

}
