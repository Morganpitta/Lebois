package io.github.apace100.apoli.condition.type.bientity;

import io.github.apace100.apoli.condition.ConditionConfiguration;
import io.github.apace100.apoli.condition.context.BiEntityConditionContext;
import io.github.apace100.apoli.condition.type.BiEntityConditionType;
import io.github.apace100.apoli.condition.type.BiEntityConditionTypes;
import io.github.apace100.apoli.data.ApoliDataTypes;
import io.github.apace100.apoli.data.TypedDataObjectFactory;
import io.github.apace100.apoli.util.Comparison;
import io.github.apace100.apoli.util.requirement.BiEntityRequirement;
import io.github.apace100.calio.data.SerializableData;
import io.github.apace100.calio.data.SerializableDataType;
import io.github.apace100.calio.data.SerializableDataTypes;
import org.jetbrains.annotations.NotNull;

import java.util.EnumSet;
import java.util.function.Function;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_3532;

public class RelativeRotationBiEntityConditionType extends BiEntityConditionType {

    public static final TypedDataObjectFactory<RelativeRotationBiEntityConditionType> DATA_FACTORY = TypedDataObjectFactory.simple(
        new SerializableData()
            .add("actor_rotation", SerializableDataType.enumValue(RotationType.class), RotationType.HEAD)
            .add("target_rotation", SerializableDataType.enumValue(RotationType.class), RotationType.BODY)
            .add("axes", SerializableDataTypes.AXIS_SET, EnumSet.allOf(class_2350.class_2351.class))
            .add("comparison", ApoliDataTypes.COMPARISON)
            .add("compare_to", SerializableDataTypes.DOUBLE),
        data -> new RelativeRotationBiEntityConditionType(
            data.get("actor_rotation"),
            data.get("target_rotation"),
            data.get("axes"),
            data.get("comparison"),
            data.get("compare_to")
        ),
        (conditionType, serializableData) -> serializableData.instance()
            .set("actor_rotation", conditionType.actorRotationType)
            .set("target_rotation", conditionType.targetRotationType)
            .set("axes", conditionType.axes)
            .set("comparison", conditionType.comparison)
            .set("compare_to", conditionType.compareTo)
    );

    private final RotationType actorRotationType;
    private final RotationType targetRotationType;

    private final EnumSet<class_2350.class_2351> axes;

    private final Comparison comparison;
    private final double compareTo;

    public RelativeRotationBiEntityConditionType(RotationType actorRotationType, RotationType targetRotationType, EnumSet<class_2350.class_2351> axes, Comparison comparison, double compareTo) {
        this.actorRotationType = actorRotationType;
        this.targetRotationType = targetRotationType;
        this.axes = axes;
        this.comparison = comparison;
        this.compareTo = compareTo;
    }

    @Override
    public boolean test(BiEntityConditionContext context) {

        class_243 actorRotation = actorRotationType.getRotation(context.actor());
        class_243 targetRotation = targetRotationType.getRotation(context.target());

        actorRotation = reduceAxes(actorRotation, axes);
        targetRotation = reduceAxes(targetRotation, axes);

        return comparison.compare(getAngleBetween(actorRotation, targetRotation), compareTo);

    }

    @Override
    public BiEntityRequirement getRequirement() {
        return BiEntityRequirement.BOTH;
    }

    @Override
    public @NotNull ConditionConfiguration<?> getConfig() {
        return BiEntityConditionTypes.RELATIVE_ROTATION;
    }

    private static double getAngleBetween(class_243 a, class_243 b) {
        double dot = a.method_1026(b);
        return dot / (a.method_1033() * b.method_1033());
    }

    private static class_243 reduceAxes(class_243 vector, EnumSet<class_2350.class_2351> axesToKeep) {
        return new class_243(
            axesToKeep.contains(class_2350.class_2351.field_11048) ? vector.field_1352 : 0,
            axesToKeep.contains(class_2350.class_2351.field_11052) ? vector.field_1351 : 0,
            axesToKeep.contains(class_2350.class_2351.field_11051) ? vector.field_1350 : 0
        );
    }

    private static class_243 getBodyRotationVector(class_1297 entity) {

        if (!(entity instanceof class_1309 livingEntity)) {
            return entity.method_5828(1.0f);
        }

        float f = livingEntity.method_36455() * ((float) Math.PI / 180);
        float g = -livingEntity.method_36454() * ((float) Math.PI / 180);

        float h = class_3532.method_15362(g);
        float i = class_3532.method_15374(g);
        float j = class_3532.method_15362(f);
        float k = class_3532.method_15374(f);

        return new class_243(i * j, -k, h * j);

    }

    public enum RotationType {

        HEAD(e -> e.method_5828(1.0F)),
        BODY(RelativeRotationBiEntityConditionType::getBodyRotationVector);

        private final Function<class_1297, class_243> function;
        RotationType(Function<class_1297, class_243> function) {
            this.function = function;
        }

        public class_243 getRotation(class_1297 entity) {
            return function.apply(entity);
        }

    }

}
