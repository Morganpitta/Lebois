package io.github.apace100.apoli.mixin;

import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1322;
import net.minecraft.class_5630;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_1309.class)
public interface LivingEntityAccessor {

    @Accessor("SPRINTING_SPEED_BOOST")
    static class_1322 apoli$getSprintingSpeedBoost() {
        throw new RuntimeException();
    }

    @Invoker
    static class_5630 callGetStackReference(class_1309 entity, class_1304 slot) {
        throw new AssertionError();
    }

}
