package io.github.apace100.apoli.command.argument;

import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.exceptions.DynamicCommandExceptionType;
import com.mojang.brigadier.exceptions.SimpleCommandExceptionType;
import java.util.LinkedList;
import java.util.List;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_2168;
import net.minecraft.class_2186;
import net.minecraft.class_2561;

public class PowerHolderArgumentType extends class_2186 {

    public static final SimpleCommandExceptionType HOLDERS_NOT_FOUND = new SimpleCommandExceptionType(
        class_2561.method_43471("argument.apoli.power_holder.not_found.multiple")
    );

    public static final DynamicCommandExceptionType HOLDER_NOT_FOUND = new DynamicCommandExceptionType(
        o -> class_2561.method_43469("argument.apoli.power_holder.not_found.single", o)
    );

    protected PowerHolderArgumentType(boolean singleTarget) {
        super(singleTarget, false);
    }

    public static PowerHolderArgumentType holder() {
        return new PowerHolderArgumentType(true);
    }

    public static PowerHolderArgumentType holders() {
        return new PowerHolderArgumentType(false);
    }

    public static class_1309 getHolder(CommandContext<class_2168> context, String name) throws CommandSyntaxException {

        class_1297 entity = method_9313(context, name);
        if (!(entity instanceof class_1309 livingEntity)) {
            throw HOLDER_NOT_FOUND.create(entity.method_5477());
        }

        return livingEntity;

    }

    public static List<class_1309> getHolders(CommandContext<class_2168> context, String name) throws CommandSyntaxException {

        List<? extends class_1297> entities = new LinkedList<>(method_9317(context, name));
        List<class_1309> holders = entities.stream()
            .filter(e -> e instanceof class_1309)
            .map(e -> (class_1309) e)
            .toList();

        if (holders.isEmpty()) {

            if (entities.size() == 1) {
                throw HOLDER_NOT_FOUND.create(entities.getFirst().method_5477());
            }

            else {
                throw HOLDERS_NOT_FOUND.create();
            }

        }

        return holders;

    }

}
