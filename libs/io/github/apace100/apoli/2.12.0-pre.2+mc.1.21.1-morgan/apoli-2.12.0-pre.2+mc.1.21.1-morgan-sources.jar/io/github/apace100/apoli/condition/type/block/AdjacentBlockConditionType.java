package io.github.apace100.apoli.condition.type.block;

import io.github.apace100.apoli.condition.BlockCondition;
import io.github.apace100.apoli.condition.ConditionConfiguration;
import io.github.apace100.apoli.condition.context.BlockConditionContext;
import io.github.apace100.apoli.condition.type.BlockConditionType;
import io.github.apace100.apoli.condition.type.BlockConditionTypes;
import io.github.apace100.apoli.data.ApoliDataTypes;
import io.github.apace100.apoli.data.TypedDataObjectFactory;
import io.github.apace100.apoli.util.Comparison;
import io.github.apace100.calio.data.SerializableData;
import io.github.apace100.calio.data.SerializableDataTypes;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import org.jetbrains.annotations.NotNull;

public class AdjacentBlockConditionType extends BlockConditionType {

    public static final TypedDataObjectFactory<AdjacentBlockConditionType> DATA_FACTORY = TypedDataObjectFactory.simple(
        new SerializableData()
            .add("adjacent_condition", BlockCondition.DATA_TYPE)
            .add("comparison", ApoliDataTypes.COMPARISON)
            .add("compare_to", SerializableDataTypes.INT),
        data -> new AdjacentBlockConditionType(
            data.get("adjacent_condition"),
            data.get("comparison"),
            data.get("compare_to")
        ),
        (conditionType, serializableData) -> serializableData.instance()
            .set("adjacent_condition", conditionType.adjacentCondition)
            .set("comparison", conditionType.comparison)
            .set("compare_to", conditionType.compareTo)
    );

    private final BlockCondition adjacentCondition;
    private final Comparison comparison;

    private final int compareTo;

    public AdjacentBlockConditionType(BlockCondition adjacentCondition, Comparison comparison, int compareTo) {
        this.adjacentCondition = adjacentCondition;
        this.comparison = comparison;
        this.compareTo = compareTo;
    }

    @Override
    public boolean test(BlockConditionContext context) {

        class_1937 world = context.world();
        class_2338 pos = context.pos();

        int matches = 0;

        for (class_2350 direction : class_2350.values()) {

            class_2338 offsetPos = pos.method_10093(direction);

            if (world.method_22340(offsetPos) && adjacentCondition.test(world, offsetPos)) {
                matches++;
            }

        }

        return comparison.compare(matches, compareTo);

    }

    @Override
    public @NotNull ConditionConfiguration<?> getConfig() {
        return BlockConditionTypes.ADJACENT;
    }

}
