package io.github.apace100.apoli.integration;

import com.google.gson.JsonElement;
import io.github.apace100.apoli.power.Power;
import net.minecraft.class_2960;

/**
 * Use this callback by registering an additional data field with `PowerTypes.registerAdditionalData(...)`.
 */
public interface AdditionalPowerDataCallback {

    void readAdditionalPowerData(class_2960 powerId, class_2960 factoryId, boolean isSubPower, JsonElement data, Power power);
}
