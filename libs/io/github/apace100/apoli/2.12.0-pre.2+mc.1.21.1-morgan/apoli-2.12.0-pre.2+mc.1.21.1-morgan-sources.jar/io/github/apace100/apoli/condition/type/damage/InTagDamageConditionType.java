package io.github.apace100.apoli.condition.type.damage;

import io.github.apace100.apoli.condition.ConditionConfiguration;
import io.github.apace100.apoli.condition.context.DamageConditionContext;
import io.github.apace100.apoli.condition.type.DamageConditionType;
import io.github.apace100.apoli.condition.type.DamageConditionTypes;
import io.github.apace100.apoli.data.TypedDataObjectFactory;
import io.github.apace100.calio.data.SerializableData;
import io.github.apace100.calio.data.SerializableDataType;
import net.minecraft.class_6862;
import net.minecraft.class_7924;
import net.minecraft.class_8110;
import org.jetbrains.annotations.NotNull;

public class InTagDamageConditionType extends DamageConditionType {

    public static final TypedDataObjectFactory<InTagDamageConditionType> DATA_FACTORY = TypedDataObjectFactory.simple(
        new SerializableData()
            .add("tag", SerializableDataType.tagKey(class_7924.field_42534)),
        data -> new InTagDamageConditionType(
            data.get("tag")
        ),
        (t, serializableData) -> serializableData.instance()
            .set("tag", t.tag)
    );

    private final class_6862<class_8110> tag;

    public InTagDamageConditionType(class_6862<class_8110> tag) {
        this.tag = tag;
    }

    @Override
    public boolean test(DamageConditionContext context) {
        return context.source().method_48789(tag);
    }

    @Override
    public @NotNull ConditionConfiguration<?> getConfig() {
        return DamageConditionTypes.IN_TAG;
    }

}
