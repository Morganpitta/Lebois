package io.github.apace100.apoli.mixin;

import com.google.common.collect.BiMap;
import net.minecraft.class_173;
import net.minecraft.class_176;
import net.minecraft.class_2960;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_173.class)
public interface LootContextTypesAccessor {

    @Accessor("MAP")
    static BiMap<class_2960, class_176> getMap() {
        throw new AssertionError();
    }

}
