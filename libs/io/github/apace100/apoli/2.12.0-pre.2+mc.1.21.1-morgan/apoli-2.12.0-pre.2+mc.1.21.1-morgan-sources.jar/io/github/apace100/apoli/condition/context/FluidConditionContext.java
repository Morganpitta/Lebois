package io.github.apace100.apoli.condition.context;

import io.github.apace100.apoli.util.context.ConditionContext;
import net.minecraft.class_3610;

public record FluidConditionContext(class_3610 fluidState) implements ConditionContext {

}
