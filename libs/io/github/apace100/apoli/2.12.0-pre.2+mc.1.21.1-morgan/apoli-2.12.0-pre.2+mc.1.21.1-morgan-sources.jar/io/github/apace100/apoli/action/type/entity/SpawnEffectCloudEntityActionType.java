package io.github.apace100.apoli.action.type.entity;

import io.github.apace100.apoli.action.ActionConfiguration;
import io.github.apace100.apoli.action.context.EntityActionContext;
import io.github.apace100.apoli.action.type.EntityActionType;
import io.github.apace100.apoli.action.type.EntityActionTypes;
import io.github.apace100.apoli.data.TypedDataObjectFactory;
import io.github.apace100.calio.data.SerializableData;
import io.github.apace100.calio.data.SerializableDataTypes;
import net.minecraft.class_1295;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1844;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import org.jetbrains.annotations.NotNull;

public class SpawnEffectCloudEntityActionType extends EntityActionType {

    public static final TypedDataObjectFactory<SpawnEffectCloudEntityActionType> DATA_FACTORY = TypedDataObjectFactory.simple(
        new SerializableData()
            .add("effect_component", SerializableDataTypes.POTION_CONTENTS_COMPONENT, class_1844.field_49274)
            .add("wait_time", SerializableDataTypes.INT, 10)
            .add("radius", SerializableDataTypes.FLOAT, 3.0F)
            .add("radius_on_use", SerializableDataTypes.FLOAT, -0.5F)
            .add("duration", SerializableDataTypes.INT, 600)
            .add("duration_on_use", SerializableDataTypes.INT, 0),
        data -> new SpawnEffectCloudEntityActionType(
            data.get("effect_component"),
            data.get("wait_time"),
            data.get("radius"),
            data.get("radius_on_use"),
            data.get("duration"),
            data.get("duration_on_use")
        ),
        (actionType, serializableData) -> serializableData.instance()
            .set("effect_component", actionType.effectComponent)
            .set("wait_time", actionType.waitTime)
            .set("radius", actionType.radius)
            .set("radius_on_use", actionType.radiusOnUse)
            .set("duration", actionType.duration)
            .set("duration_on_use", actionType.durationOnUse)
    );

    private final class_1844 effectComponent;
    private final int waitTime;

    private final float radius;
    private final float radiusOnUse;

    private final int duration;
    private final int durationOnUse;

    public SpawnEffectCloudEntityActionType(class_1844 effectComponent, int waitTime, float radius, float radiusOnUse, int duration, int durationOnUse) {
        this.effectComponent = effectComponent;
        this.waitTime = waitTime;
        this.radius = radius;
        this.radiusOnUse = radiusOnUse;
        this.duration = duration;
        this.durationOnUse = durationOnUse;
    }

    @Override
    public void accept(EntityActionContext context) {

        class_1297 entity = context.entity();
        class_243 pos = entity.method_19538().method_1019(context.offset());

        if (!(entity.method_37908() instanceof class_3218 serverWorld)) {
            return;
        }

        class_1295 aec = new class_1295(entity.method_37908(), pos.method_10216(), pos.method_10214(), pos.method_10215());

        if (entity instanceof class_1309 living) {
            aec.method_5607(living);
        }

        aec.method_57280(effectComponent);
        aec.method_5603(radius);
        aec.method_5609(radiusOnUse);
        aec.method_5604(duration);
        aec.method_35043(durationOnUse);
        aec.method_5595(waitTime);

        serverWorld.method_8649(aec);

    }

    @Override
    public @NotNull ActionConfiguration<?> getConfig() {
        return EntityActionTypes.SPAWN_EFFECT_CLOUD;
    }

}
