package io.github.apace100.apoli.action.type.entity;

import io.github.apace100.apoli.action.ActionConfiguration;
import io.github.apace100.apoli.action.context.EntityActionContext;
import io.github.apace100.apoli.action.type.EntityActionType;
import io.github.apace100.apoli.action.type.EntityActionTypes;
import net.minecraft.class_1270;
import net.minecraft.class_1657;
import net.minecraft.class_1707;
import net.minecraft.class_2561;
import net.minecraft.class_3468;
import net.minecraft.class_747;
import org.jetbrains.annotations.NotNull;

public class EnderChestEntityActionType extends EntityActionType {

    @Override
    public void accept(EntityActionContext context) {

        if (context.entity() instanceof class_1657 player) {

            class_1270 handlerFactory = (syncId, playerInventory, _player) -> class_1707.method_19245(syncId, playerInventory, player.method_7274());
            player.method_17355(new class_747(handlerFactory, class_2561.method_43471("container.enderchest")));

            player.method_7281(class_3468.field_15424);

        }

    }

    @Override
    public @NotNull ActionConfiguration<?> getConfig() {
        return EntityActionTypes.ENDER_CHEST;
    }

}
