package io.github.apace100.apoli.mixin;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Share;
import com.llamalad7.mixinextras.sugar.ref.LocalRef;
import io.github.apace100.apoli.power.type.ActionOnBlockUsePowerType;
import io.github.apace100.apoli.power.type.ActiveInteractionPowerType;
import io.github.apace100.apoli.power.type.PreventBlockUsePowerType;
import io.github.apace100.apoli.power.type.Prioritized;
import io.github.apace100.apoli.util.ActionResultUtil;
import io.github.apace100.apoli.util.BlockUsagePhase;
import io.github.apace100.apoli.util.PriorityPhase;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Slice;

import java.util.List;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2680;
import net.minecraft.class_3965;
import net.minecraft.class_636;
import net.minecraft.class_746;
import net.minecraft.class_9062;

@Mixin(class_636.class)
public abstract class ClientPlayerInteractionManagerMixin {

    @WrapOperation(method = "interactBlockInternal", at = @At(value = "INVOKE", target = "Lnet/minecraft/block/BlockState;onUse(Lnet/minecraft/world/World;Lnet/minecraft/entity/player/PlayerEntity;Lnet/minecraft/util/hit/BlockHitResult;)Lnet/minecraft/util/ActionResult;"))
    private class_1269 apoli$beforeUseBlock(class_2680 state, class_1937 world, class_1657 player, class_3965 hitResult, Operation<class_1269> original, class_746 mPlayer, class_1268 mHand, @Share("zeroPriority$useBlock") LocalRef<class_1269> zeroPriority$useBlockRef) {

        class_1799 stackInHand = player.method_5998(mHand);
        BlockUsagePhase usePhase = BlockUsagePhase.BLOCK;

        if (PreventBlockUsePowerType.doesPrevent(player, usePhase, hitResult, stackInHand, mHand)) {
            return class_1269.field_5814;
        }

        Prioritized.CallInstance<ActiveInteractionPowerType> aipci = new Prioritized.CallInstance<>();
        aipci.add(player, ActionOnBlockUsePowerType.class, p -> p.shouldExecute(usePhase, PriorityPhase.BEFORE, hitResult, mHand, stackInHand));

        for (int i = aipci.getMaxPriority(); i >= aipci.getMinPriority(); i--) {

            if (!aipci.hasPowerTypes(i)) {
                continue;
            }

            List<ActiveInteractionPowerType> aips = aipci.getPowerTypes(i);
            class_1269 previousResult = class_1269.field_5811;

            for (ActiveInteractionPowerType aip : aips) {

                class_1269 currentResult = aip instanceof ActionOnBlockUsePowerType aobup
                    ? aobup.executeAction(hitResult, mHand)
                    : class_1269.field_5811;

                if (ActionResultUtil.shouldOverride(previousResult, currentResult)) {
                    previousResult = currentResult;
                }

            }

            if (i == 0) {
                zeroPriority$useBlockRef.set(previousResult);
                continue;
            }

            if (previousResult == class_1269.field_5811) {
                continue;
            }

            if (previousResult.method_23666()) {
                player.method_6104(mHand);
            }

            return previousResult;

        }

        return original.call(state, world, player, hitResult);

    }

    @ModifyReturnValue(method = "interactBlockInternal", at = @At(value = "RETURN", ordinal = 0), slice = @Slice(from = @At(value = "INVOKE", target = "Lnet/minecraft/util/ActionResult;isAccepted()Z")))
    private class_1269 apoli$afterUseBlock(class_1269 original, class_746 player, class_1268 hand, class_3965 hitResult, @Share("zeroPriority$useBlock") LocalRef<class_1269> zeroPriority$useBlockRef) {

        class_1799 stackInHand = player.method_5998(hand);

        class_1269 zeroPriority$useBlock = zeroPriority$useBlockRef.get();
        class_1269 newResult = class_1269.field_5811;

        if (zeroPriority$useBlock != null && zeroPriority$useBlock != class_1269.field_5811) {
            newResult = zeroPriority$useBlock;
        }

        else if (original == class_1269.field_5811) {

            Prioritized.CallInstance<ActiveInteractionPowerType> aipci = new Prioritized.CallInstance<>();
            aipci.add(player, ActionOnBlockUsePowerType.class, p -> p.shouldExecute(BlockUsagePhase.BLOCK, PriorityPhase.AFTER, hitResult, hand, stackInHand));

            for (int i = aipci.getMaxPriority(); i >= aipci.getMinPriority(); i--) {

                if (!aipci.hasPowerTypes(i)) {
                    continue;
                }

                List<ActiveInteractionPowerType> aips = aipci.getPowerTypes(i);
                class_1269 previousResult = class_1269.field_5811;

                for (ActiveInteractionPowerType aip : aips) {

                    class_1269 currentResult = aip instanceof ActionOnBlockUsePowerType aobup
                        ? aobup.executeAction(hitResult, hand)
                        : class_1269.field_5811;

                    if (ActionResultUtil.shouldOverride(previousResult, currentResult)) {
                        previousResult = currentResult;
                    }

                }

                if (previousResult != class_1269.field_5811) {
                    newResult = previousResult;
                    break;
                }

            }

        }

        if (newResult.method_23666()) {
            player.method_6104(hand);
        }

        return ActionResultUtil.shouldOverride(original, newResult)
            ? newResult
            : original;

    }

    @WrapOperation(method = "interactBlockInternal", at = @At(value = "INVOKE", target = "Lnet/minecraft/block/BlockState;onUseWithItem(Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/player/PlayerEntity;Lnet/minecraft/util/Hand;Lnet/minecraft/util/hit/BlockHitResult;)Lnet/minecraft/util/ItemActionResult;"))
    private class_9062 apoli$beforeItemUseOnBlock(class_2680 state, class_1799 stack, class_1937 world, class_1657 player, class_1268 hand, class_3965 hitResult, Operation<class_9062> original, @Share("zeroPriority$itemUseOnBlock") LocalRef<class_1269> zeroPriority$itemUseOnBlockRef) {

        class_1799 stackInHand = player.method_5998(hand);
        BlockUsagePhase usePhase = BlockUsagePhase.ITEM;

        if (PreventBlockUsePowerType.doesPrevent(player, usePhase, hitResult, stackInHand, hand)) {
            return class_9062.field_47733;
        }

        Prioritized.CallInstance<ActiveInteractionPowerType> aipci = new Prioritized.CallInstance<>();
        aipci.add(player, ActionOnBlockUsePowerType.class, p -> p.shouldExecute(usePhase, PriorityPhase.BEFORE, hitResult, hand, stackInHand));

        for (int i = aipci.getMaxPriority(); i >= aipci.getMinPriority(); i--) {

            if (!aipci.hasPowerTypes(i)) {
                continue;
            }

            List<ActiveInteractionPowerType> aips = aipci.getPowerTypes(i);
            class_1269 previousResult = class_1269.field_5811;

            for (ActiveInteractionPowerType aip : aips) {

                class_1269 currentResult = aip instanceof ActionOnBlockUsePowerType aobup
                    ? aobup.executeAction(hitResult, hand)
                    : class_1269.field_5811;

                if (ActionResultUtil.shouldOverride(previousResult, currentResult)) {
                    previousResult = currentResult;
                }

            }

            if (i == 0) {
                zeroPriority$itemUseOnBlockRef.set(previousResult);
                continue;
            }

            if (previousResult == class_1269.field_5811) {
                continue;
            }

            if (previousResult.method_23666()) {
                player.method_6104(hand);
            }

            return switch (previousResult) {
                case field_5812, field_51370 ->
                    class_9062.field_47728;
                case field_21466 ->
                    class_9062.field_47729;
                case field_33562 ->
                    class_9062.field_47730;
                case field_5814 ->
                    class_9062.field_47733;
                default ->
                    throw new IllegalStateException("Unexpected value: " + previousResult);
            };

        }

        return original.call(state, stack, world, player, hand, hitResult);

    }

    @ModifyReturnValue(method = "interactBlockInternal", at = @At(value = "RETURN", ordinal = 0), slice = @Slice(from = @At(value = "INVOKE", target = "Lnet/minecraft/util/ItemActionResult;isAccepted()Z")))
    private class_1269 apoli$afterItemUseOnBlock(class_1269 original, class_746 player, class_1268 hand, class_3965 hitResult, @Share("zeroPriority$itemUseOnBlock") LocalRef<class_1269> zeroPriority$itemUseOnBlockRef) {

        class_1269 zeroPriority$itemUseOnBlock = zeroPriority$itemUseOnBlockRef.get();
        class_1269 newResult = class_1269.field_5811;

        if (zeroPriority$itemUseOnBlock != null && zeroPriority$itemUseOnBlock != class_1269.field_5811) {
            newResult = zeroPriority$itemUseOnBlock;
        }

        else if (original == class_1269.field_5811) {

            Prioritized.CallInstance<ActiveInteractionPowerType> aipci = new Prioritized.CallInstance<>();
            aipci.add(player, ActionOnBlockUsePowerType.class, p -> p.shouldExecute(BlockUsagePhase.ITEM, PriorityPhase.AFTER, hitResult, hand, player.method_5998(hand)));

            for (int i = aipci.getMaxPriority(); i >= aipci.getMinPriority(); i--) {

                if (!aipci.hasPowerTypes(i)) {
                    continue;
                }

                List<ActiveInteractionPowerType> aips = aipci.getPowerTypes(i);
                class_1269 previousResult = class_1269.field_5811;

                for (ActiveInteractionPowerType aip : aips) {

                    class_1269 currentResult = aip instanceof ActionOnBlockUsePowerType aobup
                        ? aobup.executeAction(hitResult, hand)
                        : class_1269.field_5811;

                    if (ActionResultUtil.shouldOverride(previousResult, currentResult)) {
                        previousResult = currentResult;
                    }

                }

                if (previousResult != class_1269.field_5811) {
                    newResult = previousResult;
                    break;
                }

            }

        }

        if (newResult.method_23666()) {
            player.method_6104(hand);
        }

        return ActionResultUtil.shouldOverride(original, newResult)
            ? newResult
            : original;

    }

}
