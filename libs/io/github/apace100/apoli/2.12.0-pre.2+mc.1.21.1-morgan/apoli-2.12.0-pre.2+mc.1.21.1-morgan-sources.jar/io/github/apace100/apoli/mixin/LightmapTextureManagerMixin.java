package io.github.apace100.apoli.mixin;

import io.github.apace100.apoli.component.PowerHolderComponent;
import io.github.apace100.apoli.power.type.NightVisionPowerType;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_310;
import net.minecraft.class_765;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(class_765.class)
@Environment(EnvType.CLIENT)
public abstract class LightmapTextureManagerMixin implements AutoCloseable {

    @Shadow
    @Final
    private class_310 client;

    @ModifyVariable(method = "update", at = @At("STORE"), ordinal = 6)
    private float apoli$modifyNightVisionStrength(float original) {
        return PowerHolderComponent.getPowerTypes(this.client.field_1724, NightVisionPowerType.class)
            .stream()
            .map(NightVisionPowerType::getStrength)
            .max(Float::compareTo)
            .map(newValue -> Math.max(newValue, original))
            .orElse(original);
    }

}
