package io.github.apace100.apoli.mixin;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import io.github.apace100.apoli.power.type.ModifyGrindstonePowerType;
import net.minecraft.class_1263;
import net.minecraft.class_1799;
import net.minecraft.class_3803;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(targets = "net/minecraft/screen/GrindstoneScreenHandler$3")
public class GrindstoneScreenHandlerBottomInputSlotMixin {

    @Unique
    private class_3803 apoli$grindstoneHandler;

    @Inject(method = "<init>", at = @At("TAIL"))
    private void apoli$cacheGrindstone(class_3803 grindstoneScreenHandler, class_1263 inventory, int i, int j, int k, CallbackInfo ci) {
        this.apoli$grindstoneHandler = grindstoneScreenHandler;
    }

    @ModifyReturnValue(method = "canInsert", at = @At("RETURN"))
    private boolean apoli$allowPowerStacks(boolean original, class_1799 stack) {
        return original
            || ModifyGrindstonePowerType.allowsInBottomSlot(apoli$grindstoneHandler, stack);
    }

}
