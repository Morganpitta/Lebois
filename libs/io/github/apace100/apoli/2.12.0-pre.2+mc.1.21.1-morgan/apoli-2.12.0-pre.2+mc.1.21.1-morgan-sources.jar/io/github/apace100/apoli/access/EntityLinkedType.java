package io.github.apace100.apoli.access;

import net.minecraft.class_1297;

public interface EntityLinkedType {
    class_1297 apoli$getEntity();
    void apoli$setEntity(class_1297 entity);
}
