package io.github.apace100.apoli.mixin;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.llamalad7.mixinextras.sugar.Share;
import com.llamalad7.mixinextras.sugar.ref.LocalBooleanRef;
import com.llamalad7.mixinextras.sugar.ref.LocalRef;
import com.mojang.authlib.GameProfile;
import io.github.apace100.apoli.access.CustomToastViewer;
import io.github.apace100.apoli.access.PowerCraftingObject;
import io.github.apace100.apoli.access.WaterMovingEntity;
import io.github.apace100.apoli.component.PowerHolderComponent;
import io.github.apace100.apoli.data.CustomToastData;
import io.github.apace100.apoli.power.type.*;
import io.github.apace100.apoli.screen.toast.CustomToast;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.List;
import java.util.function.Predicate;
import net.minecraft.class_1656;
import net.minecraft.class_299;
import net.minecraft.class_310;
import net.minecraft.class_3469;
import net.minecraft.class_4050;
import net.minecraft.class_634;
import net.minecraft.class_638;
import net.minecraft.class_742;
import net.minecraft.class_746;

@Mixin(class_746.class)
public abstract class ClientPlayerEntityMixin extends class_742 implements WaterMovingEntity, CustomToastViewer {

    @Unique
    private boolean apoli$isMoving = false;

    @Shadow
    @Final
    protected class_310 client;

    @Shadow
    protected abstract boolean isWalking();

    @Shadow @Final private class_299 recipeBook;

    private ClientPlayerEntityMixin(class_638 world, GameProfile profile) {
        super(world, profile);
    }

    @Inject(at = @At("HEAD"), method = "isSubmergedInWater", cancellable = true)
    private void allowSwimming(CallbackInfoReturnable<Boolean> cir)  {
        if(PowerHolderComponent.hasPowerType(this, SwimmingPowerType.class)) {
            cir.setReturnValue(true);
        } else if(PowerHolderComponent.hasPowerType(this, IgnoreWaterPowerType.class)) {
            cir.setReturnValue(false);
        }
    }

    @Inject(at = @At("HEAD"), method = "tickMovement")
    private void beginMovementPhase(CallbackInfo ci) {
        apoli$isMoving = true;
    }

    @Inject(at = @At("TAIL"), method = "tickMovement")
    private void endMovementPhase(CallbackInfo ci) {
        apoli$isMoving = false;
    }

    @Override
    public boolean apoli$isInMovementPhase() {
        return apoli$isMoving;
    }

    @Redirect(method = "tickMovement", at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/player/PlayerAbilities;getFlySpeed()F"))
    private float modifyFlySpeed(class_1656 playerAbilities){
        return PowerHolderComponent.modify(this, ModifyAirSpeedPowerType.class, playerAbilities.method_7252());
    }

    @Override
    public void apoli$showToast(CustomToastData toastData) {
        class_310 client = class_310.method_1551();
        client.execute(() -> {
            CustomToast toast = new CustomToast(toastData);
            client.method_1566().method_1999(toast);
        });
    }

    @Inject(method = "tickMovement", at = @At("HEAD"))
    private void apoli$cacheSprintingPowers(CallbackInfo ci, @Share("sprintingPowers") LocalRef<List<SprintingPowerType>> sprintingPowersRef, @Share("preventSprinting") LocalBooleanRef preventSprintingRef) {
        sprintingPowersRef.set(PowerHolderComponent.getPowerTypes(this, SprintingPowerType.class));
        preventSprintingRef.set(PowerHolderComponent.hasPowerType(this, PreventSprintingPowerType.class));
    }

    @ModifyExpressionValue(method = "tickMovement", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/network/ClientPlayerEntity;canStartSprinting()Z"))
    private boolean apoli$allowActivePowerSprinting(boolean original, @Share("sprintingPowers") LocalRef<List<SprintingPowerType>> sprintingPowersRef, @Share("preventSprinting") LocalBooleanRef preventSprintingRef) {
        return original || (this.isWalking() && sprintingPowersRef.get()
            .stream()
            .anyMatch(SprintingPowerType::shouldRequireInput));
    }

    @Inject(method = "tickMovement", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/network/ClientPlayerEntity;isSprinting()Z"))
    private void apoli$allowPassivePowerSprinting(CallbackInfo ci, @Share("sprintingPowers") LocalRef<List<SprintingPowerType>> sprintingPowersRef, @Share("preventSprinting") LocalBooleanRef preventSprintingRef) {

        if (this.method_5624() || preventSprintingRef.get()) {
            return;
        }

        this.method_5728(sprintingPowersRef.get()
            .stream()
            .anyMatch(Predicate.not(SprintingPowerType::shouldRequireInput)));

    }

    @ModifyExpressionValue(method = "tickMovement", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/network/ClientPlayerEntity;canSprint()Z"))
    private boolean apoli$accountForSprintingPowersWhenCancelling(boolean original, @Share("sprintingPowers") LocalRef<List<SprintingPowerType>> sprintingPowersRef, @Share("preventSprinting") LocalBooleanRef preventSprintingRef) {
        return (original || !sprintingPowersRef.get().isEmpty())
            && !preventSprintingRef.get();
    }

    @ModifyExpressionValue(method = "tickMovement", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/network/ClientPlayerEntity;isSneaking()Z"))
    private boolean apoli$forceSneakingPose(boolean original) {
        return original || PosePowerType.hasEntityPose(this, class_4050.field_18081);
    }

    @Inject(method = "<init>", at = @At("TAIL"))
    private void apoli$cachePlayerToRecipeBook(class_310 client, class_638 world, class_634 networkHandler, class_3469 stats, class_299 recipeBook, boolean lastSneaking, boolean lastSprinting, CallbackInfo ci) {

        if (this.recipeBook instanceof PowerCraftingObject pco) {
            pco.apoli$setPlayer(this);
        }

    }

}
