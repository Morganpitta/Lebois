package io.github.apace100.apoli.command;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.tree.CommandNode;
import io.github.apace100.apoli.command.argument.PowerArgumentType;
import io.github.apace100.apoli.command.argument.PowerHolderArgumentType;
import io.github.apace100.apoli.command.argument.PowerOperationArgumentType;
import io.github.apace100.apoli.command.argument.suggestion.PowerSuggestionProvider;
import io.github.apace100.apoli.component.PowerHolderComponent;
import io.github.apace100.apoli.power.Power;
import io.github.apace100.apoli.power.type.PowerType;
import io.github.apace100.apoli.util.PowerUtil;
import net.minecraft.class_1297;
import net.minecraft.class_2168;
import net.minecraft.class_2214;
import net.minecraft.class_2233;
import net.minecraft.class_2561;
import net.minecraft.class_266;
import net.minecraft.class_9014;
import net.minecraft.class_9015;

import static net.minecraft.class_2170.method_9244;
import static net.minecraft.class_2170.method_9247;

public class ResourceCommand {

    public static void register(CommandNode<class_2168> baseNode) {

        //  The main node of the command
        var resourceNode = method_9247("resource")
            .requires(source -> source.method_9259(2))
            .build();

        //  Add the sub-nodes as children of the main node
        resourceNode.addChild(HasNode.get());
        resourceNode.addChild(GetNode.get());
        resourceNode.addChild(SetNode.get());
        resourceNode.addChild(ChangeNode.get());
        resourceNode.addChild(OperationNode.get());

        //  Add the main node as a child of the base node
        baseNode.addChild(resourceNode);

    }

    public static class HasNode {

        public static CommandNode<class_2168> get() {
            return method_9247("has")
                .then(method_9244("target", PowerHolderArgumentType.holder())
                    .then(method_9244("resource", PowerArgumentType.resource())
                        .executes(HasNode::execute))).build();
        }

        public static int execute(CommandContext<class_2168> context) throws CommandSyntaxException {

            class_1297 target = PowerHolderArgumentType.getHolder(context, "target");
            Power power = PowerArgumentType.getResource(context, "resource");

            class_2168 commandSource = context.getSource();
            PowerType powerType = PowerUtil.getOptionalPowerType(power, target).orElseThrow(() -> PowerArgumentType.POWER_NOT_GRANTED.create(target.method_5477(), power.getId().toString()));

            if (powerType != null) {
                commandSource.method_9226(() -> class_2561.method_43471("commands.execute.conditional.pass"), false);
                return 1;
            }

            else {
                commandSource.method_9213(class_2561.method_43471("commands.execute.conditional.fail"));
                return 0;
            }

        }

    }

    public static class GetNode {

        public static CommandNode<class_2168> get() {
            return method_9247("get")
                .then(method_9244("target", PowerHolderArgumentType.holder())
                    .then(method_9244("resource", PowerArgumentType.resource())
                        .suggests(PowerSuggestionProvider.resourcesFromEntity("target"))
                        .executes(GetNode::execute)
                        .then(method_9247("")))).build();
        }

        public static int execute(CommandContext<class_2168> context) throws CommandSyntaxException {

            class_1297 target = PowerHolderArgumentType.getHolder(context, "target");
            Power power = PowerArgumentType.getResource(context, "resource");

            class_2168 commandSource = context.getSource();
            PowerType powerType = PowerUtil.getOptionalPowerType(power, target).orElseThrow(() -> PowerArgumentType.POWER_NOT_GRANTED.create(target.method_5477(), power.getId().toString()));

            if (powerType != null) {

                int value = PowerUtil.getResourceValue(powerType);
                commandSource.method_9226(() -> class_2561.method_43469("commands.scoreboard.players.get.success", target.method_5477(), value, power.getId().toString()), false);

                return value;

            }

            else {
                commandSource.method_9213(class_2561.method_43469("commands.scoreboard.players.get.null", power.getId().toString(), target.method_5477()));
                return 0;
            }

        }

    }

    public static class SetNode {

        public static CommandNode<class_2168> get() {
            return method_9247("set")
                .then(method_9244("target", PowerHolderArgumentType.holder())
                    .then(method_9244("resource", PowerArgumentType.resource())
                        .suggests(PowerSuggestionProvider.resourcesFromEntity("target"))
                        .then(method_9244("value", IntegerArgumentType.integer())
                            .executes(SetNode::execute)))).build();
        }

        public static int execute(CommandContext<class_2168> context) throws CommandSyntaxException {

            class_1297 target = PowerHolderArgumentType.getHolder(context, "target");
            Power power = PowerArgumentType.getResource(context, "resource");

            int value = IntegerArgumentType.getInteger(context, "value");
            int newValue;

            class_2168 commandSource = context.getSource();
            PowerType powerType = PowerUtil.getOptionalPowerType(power, target).orElseThrow(() -> PowerArgumentType.POWER_NOT_GRANTED.create(target.method_5477(), power.getId().toString()));

            if (PowerUtil.setResourceValue(powerType, value)) {
                PowerHolderComponent.syncPower(target, power);
            }

            newValue = PowerUtil.getResourceValue(powerType);
            commandSource.method_9226(() -> class_2561.method_43469("commands.scoreboard.players.set.success.single", power.getId().toString(), target.method_5477(), newValue), true);

            return newValue;

        }

    }

    public static class ChangeNode {

        public static CommandNode<class_2168> get() {
            return method_9247("change")
                .then(method_9244("target", PowerHolderArgumentType.holder())
                    .then(method_9244("resource", PowerArgumentType.resource())
                        .suggests(PowerSuggestionProvider.resourcesFromEntity("target"))
                        .then(method_9244("value", IntegerArgumentType.integer())
                            .executes(ChangeNode::execute)))).build();
        }

        public static int execute(CommandContext<class_2168> context) throws CommandSyntaxException {

            class_1297 target = PowerHolderArgumentType.getHolder(context, "target");
            Power resource = PowerArgumentType.getResource(context, "resource");
            
            int value = IntegerArgumentType.getInteger(context, "value");
            int newValue;
            
            class_2168 commandSource = context.getSource();
            PowerType powerType = PowerUtil.getOptionalPowerType(resource, target).orElseThrow(() -> PowerArgumentType.POWER_NOT_GRANTED.create(target.method_5477(), resource.getId().toString()));
            
            if (PowerUtil.changeResourceValue(powerType, value)) {
                PowerHolderComponent.syncPower(target, resource);
            }
            
            newValue = PowerUtil.getResourceValue(powerType);
            commandSource.method_9226(() -> class_2561.method_43469("commands.scoreboard.players.add.success.single", value, resource.getId().toString(), target.method_5477(), newValue), true);
            
            return newValue;

        }

    }

    public static class OperationNode {

        public static CommandNode<class_2168> get() {
            return method_9247("operation")
                .then(method_9244("target", PowerHolderArgumentType.holder())
                    .then(method_9244("resource", PowerArgumentType.resource())
                        .suggests(PowerSuggestionProvider.resourcesFromEntity("target"))
                        .then(method_9244("operation", PowerOperationArgumentType.operation())
                            .then(method_9244("source", class_2233.method_9447())
                                .then(method_9244("objective", class_2214.method_9391())
                                    .executes(OperationNode::execute)))))).build();
        }

        public static int execute(CommandContext<class_2168> context) throws CommandSyntaxException {

            class_1297 target = PowerHolderArgumentType.getHolder(context, "target");
            Power resource = PowerArgumentType.getResource(context, "resource");

            PowerOperationArgumentType.Operation operation = PowerOperationArgumentType.getOperation(context, "operation");

            class_9015 source = class_2233.method_9452(context, "source");
            class_266 objective = class_2214.method_9395(context, "objective");

            class_2168 commandSource = context.getSource();
            PowerType powerType = PowerUtil.getOptionalPowerType(resource, target).orElseThrow(() -> PowerArgumentType.POWER_NOT_GRANTED.create(target.method_5477(), resource.getId().toString()));

            class_9014 scoreAccess = commandSource.method_9211().method_3845().method_1180(source, objective);

            boolean operated = operation.apply(powerType, scoreAccess);
            int newValue = PowerUtil.getResourceValue(powerType);

            if (operated) {
                PowerHolderComponent.syncPower(target, resource);
            }

            commandSource.method_9226(() -> class_2561.method_43469("commands.scoreboard.players.operation.success.single", resource.getId().toString(), target.method_5477(), newValue), true);
            return newValue;

        }

    }

}
