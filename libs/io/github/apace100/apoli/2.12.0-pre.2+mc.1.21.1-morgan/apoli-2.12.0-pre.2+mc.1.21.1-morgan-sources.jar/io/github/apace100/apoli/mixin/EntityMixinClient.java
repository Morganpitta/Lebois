package io.github.apace100.apoli.mixin;

import io.github.apace100.apoli.access.PseudoRenderDataHolder;
import io.github.apace100.apoli.power.type.PosePowerType;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_4050;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(EnvType.CLIENT)
@Mixin(class_1297.class)
public abstract class EntityMixinClient implements PseudoRenderDataHolder {

    @Unique
    private int apoli$pseudoDeathTicks;

    @Unique
    private int apoli$pseudoFallFlyingTicks;

    @Override
    public int apoli$getPseudoDeathTicks() {
        return apoli$pseudoDeathTicks;
    }

    @Override
    public int apoli$getPseudoFallFlyingTicks() {
        return apoli$pseudoFallFlyingTicks;
    }

    @Inject(method = "tick", at = @At("TAIL"))
    private void apoli$tickPseudoVars(CallbackInfo ci) {

        class_1297 thisAsEntity = (class_1297) (Object) this;
        if (PosePowerType.hasEntityPose(thisAsEntity, class_4050.field_18082)) {
            ++this.apoli$pseudoDeathTicks;
        }

        else  {
            this.apoli$pseudoDeathTicks = 0;
        }

        if (PosePowerType.hasEntityPose(thisAsEntity, class_4050.field_18077)) {
            ++this.apoli$pseudoFallFlyingTicks;
        }

        else {
            this.apoli$pseudoFallFlyingTicks = 0;
        }

    }

}
