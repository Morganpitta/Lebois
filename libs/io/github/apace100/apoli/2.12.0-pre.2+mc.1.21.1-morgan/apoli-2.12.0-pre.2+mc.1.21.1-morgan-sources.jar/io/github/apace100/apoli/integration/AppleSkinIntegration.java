package io.github.apace100.apoli.integration;

import io.github.apace100.apoli.component.PowerHolderComponent;
import io.github.apace100.apoli.power.type.EdibleItemPowerType;
import io.github.apace100.apoli.power.type.ModifyFoodPowerType;
import io.github.apace100.apoli.util.modifier.Modifier;
import io.github.apace100.apoli.util.modifier.ModifierUtil;
import squeek.appleskin.api.AppleSkinApi;
import squeek.appleskin.api.event.FoodValuesEvent;

import java.util.List;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_4174;

public class AppleSkinIntegration implements AppleSkinApi {

    @Override
    public void registerEvents() {

        FoodValuesEvent.EVENT.register(event -> {

            class_1657 player = event.player;
            class_1799 stack = event.itemStack;

            EdibleItemPowerType.get(stack, player)
                .map(EdibleItemPowerType::getFoodComponent)
                .ifPresent(foodComponent -> event.modifiedFoodComponent = foodComponent);

            List<ModifyFoodPowerType> modifyFoodPowers = PowerHolderComponent.getPowerTypes(player, ModifyFoodPowerType.class)
                .stream()
                .filter(p -> p.doesApply(stack))
                .toList();
            if (modifyFoodPowers.isEmpty()) {
                return;
            }

            class_4174 originalFoodComponent = !event.modifiedFoodComponent.equals(event.defaultFoodComponent)
                ? event.modifiedFoodComponent
                : event.defaultFoodComponent;

            List<Modifier> nutritionModifiers = modifyFoodPowers
                .stream()
                .flatMap(p -> p.getFoodModifiers().stream())
                .toList();
            List<Modifier> saturationModifiers = modifyFoodPowers
                .stream()
                .flatMap(p -> p.getSaturationModifiers().stream())
                .toList();

            int newNutrition = (int) ModifierUtil.applyModifiers(player, nutritionModifiers, originalFoodComponent.comp_2491());
            float newSaturation = (float) ModifierUtil.applyModifiers(player, saturationModifiers, originalFoodComponent.comp_2492());

            event.modifiedFoodComponent = new class_4174(
                newNutrition,
                newSaturation,
                originalFoodComponent.comp_2493(),
                originalFoodComponent.comp_2494(),
                originalFoodComponent.comp_2794(),
                originalFoodComponent.comp_2495()
            );

        });

    }

}
