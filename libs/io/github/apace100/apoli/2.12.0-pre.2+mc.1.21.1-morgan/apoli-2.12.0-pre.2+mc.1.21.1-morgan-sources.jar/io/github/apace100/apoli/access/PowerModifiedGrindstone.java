package io.github.apace100.apoli.access;

import io.github.apace100.apoli.power.type.ModifyGrindstonePowerType;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import net.minecraft.class_1657;
import net.minecraft.class_2338;

public interface PowerModifiedGrindstone {

    List<ModifyGrindstonePowerType> apoli$getAppliedPowers();

    class_1657 apoli$getPlayer();

    @Nullable
    class_2338 apoli$getPos();

}
