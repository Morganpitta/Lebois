package io.github.apace100.apoli.condition.type.entity;

import io.github.apace100.apoli.condition.ConditionConfiguration;
import io.github.apace100.apoli.condition.context.EntityConditionContext;
import io.github.apace100.apoli.condition.type.EntityConditionType;
import io.github.apace100.apoli.condition.type.EntityConditionTypes;
import io.github.apace100.apoli.data.ApoliDataTypes;
import io.github.apace100.apoli.data.TypedDataObjectFactory;
import io.github.apace100.apoli.power.type.ModifyEnchantmentLevelPowerType;
import io.github.apace100.apoli.util.Comparison;
import io.github.apace100.calio.data.SerializableData;
import io.github.apace100.calio.data.SerializableDataType;
import io.github.apace100.calio.data.SerializableDataTypes;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_1887;
import net.minecraft.class_5321;
import net.minecraft.class_6880;
import net.minecraft.class_7924;
import org.jetbrains.annotations.NotNull;

public class EnchantmentEntityConditionType extends EntityConditionType {

    public static final TypedDataObjectFactory<EnchantmentEntityConditionType> DATA_FACTORY = TypedDataObjectFactory.simple(
        new SerializableData()
            .add("enchantment", SerializableDataTypes.ENCHANTMENT)
            .add("use_modifications", SerializableDataTypes.BOOLEAN, true)
            .add("calculation", SerializableDataType.enumValue(Calculation.class), Calculation.SUM)
            .add("comparison", ApoliDataTypes.COMPARISON)
            .add("compare_to", SerializableDataTypes.INT),
        data -> new EnchantmentEntityConditionType(
            data.get("enchantment"),
            data.get("use_modifications"),
            data.get("calculation"),
            data.get("comparison"),
            data.get("compare_to")
        ),
        (conditionType, serializableData) -> serializableData.instance()
            .set("enchantment", conditionType.enchantmentKey)
            .set("use_modifications", conditionType.useModifications)
            .set("calculation", conditionType.calculation)
            .set("comparison", conditionType.comparison)
            .set("compare_to", conditionType.compareTo)
    );

    private final class_5321<class_1887> enchantmentKey;
    private final boolean useModifications;

    private final Calculation calculation;

    private final Comparison comparison;
    private final int compareTo;

    public EnchantmentEntityConditionType(class_5321<class_1887> enchantmentKey, boolean useModifications, Calculation calculation, Comparison comparison, int compareTo) {
        this.enchantmentKey = enchantmentKey;
        this.useModifications = useModifications;
        this.calculation = calculation;
        this.comparison = comparison;
        this.compareTo = compareTo;
    }

    @Override
    public boolean test(EntityConditionContext context) {

        if (context.entity() instanceof class_1309 livingEntity) {

            class_6880<class_1887> enchantment = livingEntity.method_56673().method_30530(class_7924.field_41265).method_40290(enchantmentKey);
            int level = calculation.queryTotalLevel(livingEntity, enchantment, useModifications);

            return comparison.compare(level, compareTo);

        }

        else {
            return false;
        }

    }

    @Override
    public @NotNull ConditionConfiguration<?> getConfig() {
        return EntityConditionTypes.ENCHANTMENT;
    }

    public enum Calculation {

        SUM {

            @Override
            public int queryLevel(class_1799 stack, class_6880<class_1887> enchantmentEntry, boolean useModifications, int totalLevel) {
                return ModifyEnchantmentLevelPowerType.getEnchantments(stack, useModifications).method_57536(enchantmentEntry);
            }

        },

        MAX {

            @Override
            public int queryLevel(class_1799 stack, class_6880<class_1887> enchantmentEntry, boolean useModifications, int totalLevel) {

                int potentialLevel = ModifyEnchantmentLevelPowerType.getEnchantments(stack, useModifications).method_57536(enchantmentEntry);

                if (potentialLevel >= totalLevel) {
                    return potentialLevel;
                }

                else {
                    return 0;
                }

            }

        };

        public int queryTotalLevel(class_1309 entity, class_6880<class_1887> enchantmentEntry, boolean useModifications) {

            class_1887 enchantment = enchantmentEntry.comp_349();
            int totalLevel = 0;

            for (class_1799 stack : enchantment.method_8185(entity).values()) {
                totalLevel += this.queryLevel(stack, enchantmentEntry, useModifications, totalLevel);
            }

            return totalLevel;

        }

        public abstract int queryLevel(class_1799 stack, class_6880<class_1887> enchantmentEntry, boolean useModifications, int totalLevel);

    }

}
