package io.github.apace100.apoli.action.type.bientity;

import io.github.apace100.apoli.action.ActionConfiguration;
import io.github.apace100.apoli.action.context.BiEntityActionContext;
import io.github.apace100.apoli.action.type.BiEntityActionType;
import io.github.apace100.apoli.action.type.BiEntityActionTypes;
import io.github.apace100.apoli.component.PowerHolderComponent;
import io.github.apace100.apoli.data.ApoliDataTypes;
import io.github.apace100.apoli.data.TypedDataObjectFactory;
import io.github.apace100.apoli.power.PowerReference;
import io.github.apace100.apoli.power.type.EntitySetPowerType;
import io.github.apace100.apoli.util.requirement.BiEntityRequirement;
import io.github.apace100.calio.data.SerializableData;
import io.github.apace100.calio.data.SerializableDataTypes;
import org.jetbrains.annotations.NotNull;

import java.util.Optional;
import net.minecraft.class_1297;

public class AddToEntitySetBiEntityActionType extends BiEntityActionType {

    public static final TypedDataObjectFactory<AddToEntitySetBiEntityActionType> DATA_FACTORY = TypedDataObjectFactory.simple(
        new SerializableData()
            .add("set", ApoliDataTypes.POWER_REFERENCE)
            .add("time_limit", SerializableDataTypes.POSITIVE_INT.optional(), Optional.empty()),
        data -> new AddToEntitySetBiEntityActionType(
            data.get("set"),
            data.get("time_limit")
        ),
        (actionType, serializableData) -> serializableData.instance()
            .set("set", actionType.set)
            .set("time_limit", actionType.timeLimit)
    );

    private final PowerReference set;
    private final Optional<Integer> timeLimit;

    public AddToEntitySetBiEntityActionType(PowerReference set, Optional<Integer> timeLimit) {
        this.set = set;
        this.timeLimit = timeLimit;
    }

    @Override
    public void accept(BiEntityActionContext context) {

        class_1297 actor = context.actor();

        if (set.getNullablePowerType(actor) instanceof EntitySetPowerType entitySet && entitySet.add(context.target(), timeLimit)) {
            PowerHolderComponent.syncPower(actor, set);
        }

    }

    @Override
    public @NotNull ActionConfiguration<?> getConfig() {
        return BiEntityActionTypes.ADD_TO_ENTITY_SET;
    }

    @Override
    public BiEntityRequirement getRequirement() {
        return BiEntityRequirement.BOTH;
    }

}
