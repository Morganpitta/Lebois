package io.github.apace100.apoli.access;

import net.minecraft.class_1922;
import net.minecraft.class_2338;
import net.minecraft.class_265;
import net.minecraft.class_3726;

public interface BlockStateCollisionShapeAccess {
    class_265 apoli$getOriginalCollisionShape(class_1922 world, class_2338 pos, class_3726 context);
}
