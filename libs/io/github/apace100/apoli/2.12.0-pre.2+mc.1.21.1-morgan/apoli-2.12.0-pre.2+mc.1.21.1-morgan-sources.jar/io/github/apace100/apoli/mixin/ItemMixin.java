package io.github.apace100.apoli.mixin;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.llamalad7.mixinextras.sugar.Local;
import io.github.apace100.apoli.component.PowerHolderComponent;
import io.github.apace100.apoli.power.type.ModifyFoodPowerType;
import net.minecraft.class_1268;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_1792.class)
public abstract class ItemMixin {

    @ModifyExpressionValue(method = "use", at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/player/PlayerEntity;canConsume(Z)Z"))
    private boolean apoli$makeItemAlwaysEdible(boolean original, class_1937 world, class_1657 user, class_1268 hand, @Local class_1799 stackInHand) {
        return original || PowerHolderComponent.hasPowerType(user, ModifyFoodPowerType.class, mfp -> mfp.doesMakeAlwaysEdible() && mfp.doesApply(stackInHand));
    }

}
