package io.github.apace100.apoli.action.context;

import io.github.apace100.apoli.condition.context.BiEntityConditionContext;
import io.github.apace100.apoli.util.context.ActionContext;
import net.minecraft.class_1297;

public record BiEntityActionContext(class_1297 actor, class_1297 target) implements ActionContext<BiEntityConditionContext> {

	@Override
	public BiEntityConditionContext forCondition() {
		return new BiEntityConditionContext(actor(), target());
	}

}
