package io.github.apace100.apoli.condition.type.biome;

import io.github.apace100.apoli.condition.ConditionConfiguration;
import io.github.apace100.apoli.condition.context.BiomeConditionContext;
import io.github.apace100.apoli.condition.type.BiomeConditionType;
import io.github.apace100.apoli.condition.type.BiomeConditionTypes;
import io.github.apace100.apoli.data.TypedDataObjectFactory;
import io.github.apace100.calio.data.SerializableData;
import io.github.apace100.calio.data.SerializableDataType;
import net.minecraft.class_1959;
import org.jetbrains.annotations.NotNull;

public class PrecipitationBiomeConditionType extends BiomeConditionType {

    public static final TypedDataObjectFactory<PrecipitationBiomeConditionType> DATA_FACTORY = TypedDataObjectFactory.simple(
        new SerializableData()
            .add("precipitation", SerializableDataType.enumValue(class_1959.class_1963.class)),
        data -> new PrecipitationBiomeConditionType(
            data.get("precipitation")
        ),
        (conditionType, serializableData) -> serializableData.instance()
            .set("precipitation", conditionType.precipitation)
    );

    private final class_1959.class_1963 precipitation;

    public PrecipitationBiomeConditionType(class_1959.class_1963 precipitation) {
        this.precipitation = precipitation;
    }

    @Override
    public boolean test(BiomeConditionContext context) {
        return context.biomeEntry().comp_349().method_48162(context.pos()) == precipitation;
    }

    @Override
    public @NotNull ConditionConfiguration<?> getConfig() {
        return BiomeConditionTypes.PRECIPITATION;
    }

}
