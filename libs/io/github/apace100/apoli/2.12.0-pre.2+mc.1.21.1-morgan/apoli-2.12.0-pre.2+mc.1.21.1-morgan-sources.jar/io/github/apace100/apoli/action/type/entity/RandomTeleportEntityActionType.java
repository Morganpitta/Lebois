package io.github.apace100.apoli.action.type.entity;

import io.github.apace100.apoli.action.ActionConfiguration;
import io.github.apace100.apoli.action.EntityAction;
import io.github.apace100.apoli.action.context.EntityActionContext;
import io.github.apace100.apoli.action.type.EntityActionType;
import io.github.apace100.apoli.action.type.EntityActionTypes;
import io.github.apace100.apoli.condition.BlockCondition;
import io.github.apace100.apoli.condition.EntityCondition;
import io.github.apace100.apoli.data.TypedDataObjectFactory;
import io.github.apace100.calio.data.SerializableData;
import io.github.apace100.calio.data.SerializableDataType;
import io.github.apace100.calio.data.SerializableDataTypes;
import org.jetbrains.annotations.NotNull;

import java.util.Optional;
import net.minecraft.class_1297;
import net.minecraft.class_1314;
import net.minecraft.class_1923;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2902;
import net.minecraft.class_3218;
import net.minecraft.class_3230;
import net.minecraft.class_3532;
import net.minecraft.class_5819;

public class RandomTeleportEntityActionType extends EntityActionType {

    public static final TypedDataObjectFactory<RandomTeleportEntityActionType> DATA_FACTORY = TypedDataObjectFactory.simple(
        new SerializableData()
            .add("success_action", EntityAction.DATA_TYPE.optional(), Optional.empty())
            .add("fail_action", EntityAction.DATA_TYPE.optional(), Optional.empty())
            .add("landing_condition", EntityCondition.DATA_TYPE.optional(), Optional.empty())
            .add("landing_block_condition", BlockCondition.DATA_TYPE.optional(), Optional.empty())
            .add("heightmap", SerializableDataType.enumValue(class_2902.class_2903.class).optional(), Optional.empty())
            .add("landing_offset", SerializableDataTypes.VECTOR, class_243.field_1353)
            .add("area_width", SerializableDataTypes.POSITIVE_DOUBLE, 8.0D)
            .add("area_height", SerializableDataTypes.POSITIVE_DOUBLE, 8.0D)
            .add("loaded_chunks_only", SerializableDataTypes.BOOLEAN, true)
            .addFunctionedDefault("attempts", SerializableDataTypes.POSITIVE_INT, data -> (int) ((data.getDouble("area_width") * 2) + (data.getDouble("area_height") * 2))),
        data -> new RandomTeleportEntityActionType(
            data.get("success_action"),
            data.get("fail_action"),
            data.get("landing_condition"),
            data.get("landing_block_condition"),
            data.get("heightmap"),
            data.get("landing_offset"),
            data.getDouble("area_width"),
            data.getDouble("area_height"),
            data.get("loaded_chunks_only"),
            data.get("attempts")
        ),
        (actionType, serializableData) -> serializableData.instance()
            .set("success_action", actionType.successAction)
            .set("fail_action", actionType.failAction)
            .set("landing_condition", actionType.landingCondition)
            .set("landing_block_condition", actionType.landingBlockCondition)
            .set("heightmap", actionType.heightmapType)
            .set("landing_offset", actionType.landingOffset)
            .set("area_width", actionType.areaWidth)
            .set("area_height", actionType.areaHeight)
            .set("loaded_chunks_only", actionType.loadedChunksOnly)
            .set("attempts", actionType.attempts)
    );

    private final Optional<EntityAction> successAction;
    private final Optional<EntityAction> failAction;

    private final Optional<EntityCondition> landingCondition;
    private final Optional<BlockCondition> landingBlockCondition;

    private final Optional<class_2902.class_2903> heightmapType;
    private final class_243 landingOffset;

    private final double areaWidth;
    private final double areaHeight;

    private final boolean loadedChunksOnly;
    private final int attempts;

    public RandomTeleportEntityActionType(Optional<EntityAction> successAction, Optional<EntityAction> failAction, Optional<EntityCondition> landingCondition, Optional<BlockCondition> landingBlockCondition, Optional<class_2902.class_2903> heightmapType, class_243 landingOffset, double areaWidth, double areaHeight, boolean loadedChunksOnly, int attempts) {
        this.successAction = successAction;
        this.failAction = failAction;
        this.landingCondition = landingCondition;
        this.landingBlockCondition = landingBlockCondition;
        this.heightmapType = heightmapType;
        this.landingOffset = landingOffset;
        this.loadedChunksOnly = loadedChunksOnly;
        this.attempts = attempts;
        this.areaWidth = areaWidth * 2;
        this.areaHeight = areaHeight * 2;
    }

    @Override
    public void accept(EntityActionContext context) {

        class_1297 entity = context.entity();
        class_1937 world = entity.method_37908();

        if (!(world instanceof class_3218 serverWorld)) {
            return;
        }

        class_5819 random = class_5819.method_43047();
        boolean succeeded = false;

        double x, y, z;

        for (int i = 0; i < attempts; i++) {

            x = entity.method_23317() + (random.method_43058() - 0.5) * areaWidth;
            y = class_3532.method_15350(entity.method_23318() + (random.method_43048(Math.max((int) areaHeight, 1)) - (areaHeight / 2)), serverWorld.method_31607(), serverWorld.method_31607() + (serverWorld.method_32819() - 1));
            z = entity.method_23321() + (random.method_43058() - 0.5) * areaWidth;

            if (this.attemptToTeleport(entity, serverWorld, x, y, z)) {

                successAction.ifPresent(action -> action.execute(entity));
                entity.method_38785();

                succeeded = true;
                break;

            }

        }

        if (!succeeded) {
            failAction.ifPresent(action -> action.execute(entity));
        }

    }

    @Override
    public @NotNull ActionConfiguration<?> getConfig() {
        return EntityActionTypes.RANDOM_TELEPORT;
    }

    private boolean attemptToTeleport(class_1297 entity, class_3218 serverWorld, double destX, double destY, double destZ) {

        class_2338.class_2339 destBlockPos = class_2338.method_49637(destX, destY, destZ).method_25503();
        boolean foundSurface = false;

        if (heightmapType.isPresent()) {

            destBlockPos.method_10101(serverWorld.method_8598(heightmapType.get(), destBlockPos).method_10074());
            foundSurface = this.shouldLandOnBlock(serverWorld, destBlockPos);

            if (foundSurface) {
                destBlockPos.method_10101(destBlockPos.method_10084());
            }

        }

        for (double decrements = 0; !foundSurface && decrements < areaHeight / 2; ++decrements) {

            destBlockPos.method_10101(destBlockPos.method_10074());
            foundSurface = this.shouldLandOnBlock(serverWorld, destBlockPos);

            if (foundSurface) {
                destBlockPos.method_10101(destBlockPos.method_10084());
            }

        }

        if (!foundSurface) {
            return false;
        }

        destX = landingOffset.method_10216() == 0 ? destX : class_3532.method_15357(destX) + landingOffset.method_10216();
        destY = destBlockPos.method_10264() + landingOffset.method_10214();
        destZ = landingOffset.method_10215() == 0 ? destZ : class_3532.method_15357(destZ) + landingOffset.method_10215();

        destBlockPos.method_10102(destX, destY, destZ);

        double prevX = entity.method_23317();
        double prevY = entity.method_23318();
        double prevZ = entity.method_23321();

        class_1923 destChunkPos = new class_1923(destBlockPos);
        if (!loadedChunksOnly && !serverWorld.method_8393(destChunkPos.field_9181, destChunkPos.field_9180)) {
            serverWorld.method_14178().method_17297(class_3230.field_19347, destChunkPos, 0, entity.method_5628());
            serverWorld.method_8497(destChunkPos.field_9181, destChunkPos.field_9180);
        }

        entity.method_5859(destX, destY, destZ);

        if (!this.shouldLand(entity)) {
            entity.method_5859(prevX, prevY, prevZ);
            return false;
        }

        if (entity instanceof class_1314 pathAwareEntity) {
            pathAwareEntity.method_5942().method_6340();
        }

        return true;

    }

    private boolean shouldLandOnBlock(class_1937 world, class_2338 pos) {
        return landingBlockCondition
            .map(condition -> condition.test(world, pos))
            .orElseGet(() -> world.method_8320(pos).method_51366());
    }

    private boolean shouldLand(class_1297 entity) {
        return landingCondition
            .map(condition -> condition.test(entity))
            .orElseGet(() -> entity.method_37908().method_17892(entity) && !entity.method_37908().method_22345(entity.method_5829()));
    }

}
