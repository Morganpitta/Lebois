package io.github.apace100.apoli.data;

import io.github.apace100.apoli.Apoli;
import io.github.apace100.apoli.data.container.ContainerType;
import io.github.apace100.apoli.data.container.PresetContainerType;
import io.github.apace100.apoli.registry.ApoliRegistries;
import io.github.apace100.calio.data.SerializableDataType;
import io.github.apace100.calio.util.IdentifierAlias;
import java.util.Objects;
import java.util.stream.Collectors;
import net.minecraft.class_1707;
import net.minecraft.class_1716;
import net.minecraft.class_1722;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3917;

public class ApoliContainerTypes {

	public static final IdentifierAlias ALIASES = new IdentifierAlias();
	public static final SerializableDataType<ContainerType> REGISTRY_DATA_TYPE = SerializableDataType.registry(ApoliRegistries.CONTAINER_TYPE, Apoli.MODID, ALIASES, (containerTypes, id) -> "Container type \"" + id + "\" is undefined! Expected to be any of " + containerTypes.method_10235().stream().map(class_2960::toString).collect(Collectors.joining(", ")));

	//	Presets for generic container screen handlers
	public static final PresetContainerType GENERIC_3X3 = register("generic_3x3", new PresetContainerType(3, 3, (inventory, columns, rows) -> (syncId, playerInventory, player) -> new class_1716(syncId, playerInventory, inventory)));
	public static final PresetContainerType GENERIC_9X1	= register("generic_9x1", new PresetContainerType(9, 1, (inventory, columns, rows) -> (syncId, playerInventory, player) -> new class_1707(class_3917.field_18664, syncId, playerInventory, inventory, rows)));
	public static final PresetContainerType GENERIC_9X2 = register("generic_9x2", new PresetContainerType(9, 2, (inventory, columns, rows) -> (syncId, playerInventory, player) -> new class_1707(class_3917.field_18665, syncId, playerInventory, inventory, rows)));
	public static final PresetContainerType GENERIC_9X3 = register("generic_9x3", new PresetContainerType(9, 3, (inventory, columns, rows) -> (syncId, playerInventory, player) -> new class_1707(class_3917.field_17326, syncId, playerInventory, inventory, rows)));
	public static final PresetContainerType GENERIC_9X4 = register("generic_9x4", new PresetContainerType(9, 4, (inventory, columns, rows) -> (syncId, playerInventory, player) -> new class_1707(class_3917.field_18666, syncId, playerInventory, inventory, rows)));
	public static final PresetContainerType GENERIC_9X5 = register("generic_9x5", new PresetContainerType(9, 5, (inventory, columns, rows) -> (syncId, playerInventory, player) -> new class_1707(class_3917.field_18667, syncId, playerInventory, inventory, rows)));
	public static final PresetContainerType GENERIC_9X6 = register("generic_9x6", new PresetContainerType(9, 6, (inventory, columns, rows) -> (syncId, playerInventory, player) -> new class_1707(class_3917.field_17327, syncId, playerInventory, inventory, rows)));

	//	Presets for other container screen handlers
	public static final PresetContainerType HOPPER = register("hopper", new PresetContainerType(5, 1, (inventory, columns, rows) -> (syncId, playerInventory, player) -> new class_1722(syncId, playerInventory, inventory)));

	public static void register() {
		ALIASES.addPathAlias("double_chest", getPath(GENERIC_9X6));
		ALIASES.addPathAlias("chest", getPath(GENERIC_9X3));
		ALIASES.addPathAlias("dropper", getPath(GENERIC_3X3));
		ALIASES.addPathAlias("dispenser", getPath(GENERIC_3X3));
	}

	private static String getPath(ContainerType containerType) {
		return Objects.requireNonNull(ApoliRegistries.CONTAINER_TYPE.method_10221(containerType)).method_12832();
	}

	public static <T extends ContainerType> T register(String name, T containerType) {
		return class_2378.method_10230(ApoliRegistries.CONTAINER_TYPE, Apoli.identifier(name), containerType);
	}

}
