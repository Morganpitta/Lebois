package io.github.apace100.apoli.condition.context;

import io.github.apace100.apoli.util.context.ConditionContext;
import net.minecraft.class_1297;

public record BiEntityConditionContext(class_1297 actor, class_1297 target) implements ConditionContext {

}
