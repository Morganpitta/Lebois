package io.github.apace100.apoli.access;

import java.util.Optional;
import net.minecraft.class_2960;

public interface SlotState {
    Optional<class_2960> apoli$getState();
    void apoli$setState(class_2960 state);
}
