package io.github.apace100.apoli.mixin.misc.command_tags_sync;

import io.github.apace100.apoli.networking.packet.s2c.SyncCommandTagsS2CPacket;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_1297;
import net.minecraft.class_3222;
import net.minecraft.class_3231;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_3231.class)
public abstract class EntityTrackerEntryMixin {

	@Shadow
	@Final
	private class_1297 entity;

	@Inject(method = "startTracking", at = @At("TAIL"))
	private void syncCommandTagsAfterTracking(class_3222 player, CallbackInfo ci) {

		SyncCommandTagsS2CPacket packet = new SyncCommandTagsS2CPacket(this.entity);

		if (ServerPlayNetworking.canSend(player, packet.method_56479())) {
			ServerPlayNetworking.send(player, packet);
		}

	}

}
