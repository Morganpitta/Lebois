package io.github.apace100.apoli.mixin;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import io.github.apace100.apoli.access.EntityLinkedType;
import io.github.apace100.apoli.power.type.ModifyTypeTagPowerType;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;

import java.lang.ref.WeakReference;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_6862;
import net.minecraft.class_6885;

@Mixin(class_1299.class)
public abstract class EntityTypeMixin implements EntityLinkedType {

    @Unique
    private final ThreadLocal<WeakReference<class_1297>> apoli$currentEntity = new ThreadLocal<>();

    @Override
    public class_1297 apoli$getEntity() {
        final WeakReference<class_1297> reference = apoli$currentEntity.get();
        if (reference != null) {
            return reference.get();
        }
        return null;
    }

    @Override
    public void apoli$setEntity(class_1297 entity) {
        this.apoli$currentEntity.set(new WeakReference<>(entity));
    }

    @ModifyReturnValue(method = "isIn(Lnet/minecraft/registry/tag/TagKey;)Z", at = @At("RETURN"))
    private boolean apoli$inTagProxy(boolean original, class_6862<class_1299<?>> tag) {
        return original
            || ModifyTypeTagPowerType.doesApply(this.apoli$getEntity(), tag);
    }

    @ModifyReturnValue(method = "isIn(Lnet/minecraft/registry/entry/RegistryEntryList;)Z", at = @At("RETURN"))
    private boolean apoli$inTagEntryListProxy(boolean original, class_6885<class_1299<?>> entryList) {
        return original
            || ModifyTypeTagPowerType.doesApply(this.apoli$getEntity(), entryList);
    }

}
