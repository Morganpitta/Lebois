package io.github.apace100.apoli.condition.type.bientity;

import io.github.apace100.apoli.condition.ConditionConfiguration;
import io.github.apace100.apoli.condition.context.BiEntityConditionContext;
import io.github.apace100.apoli.condition.type.BiEntityConditionType;
import io.github.apace100.apoli.condition.type.BiEntityConditionTypes;
import io.github.apace100.apoli.util.requirement.BiEntityRequirement;
import org.jetbrains.annotations.NotNull;

import java.util.Objects;
import net.minecraft.class_1297;
import net.minecraft.class_6025;
import net.minecraft.class_8046;

public class OwnerBiEntityConditionType extends BiEntityConditionType {

	@Override
	public boolean test(BiEntityConditionContext context) {

		class_1297 actor = context.actor();
		class_1297 target = context.target();

		return (target instanceof class_6025 tameableTarget && Objects.equals(actor, tameableTarget.method_35057()))
			|| (target instanceof class_8046 ownableTarget && Objects.equals(actor, ownableTarget.method_24921()));

	}

	@Override
	public BiEntityRequirement getRequirement() {
		return BiEntityRequirement.BOTH;
	}

	@Override
	public @NotNull ConditionConfiguration<?> getConfig() {
		return BiEntityConditionTypes.OWNER;
	}

}
