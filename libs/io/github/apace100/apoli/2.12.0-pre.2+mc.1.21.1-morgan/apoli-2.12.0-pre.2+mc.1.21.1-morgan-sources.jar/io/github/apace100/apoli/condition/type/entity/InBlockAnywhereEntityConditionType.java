package io.github.apace100.apoli.condition.type.entity;

import io.github.apace100.apoli.condition.BlockCondition;
import io.github.apace100.apoli.condition.ConditionConfiguration;
import io.github.apace100.apoli.condition.context.EntityConditionContext;
import io.github.apace100.apoli.condition.type.EntityConditionType;
import io.github.apace100.apoli.condition.type.EntityConditionTypes;
import io.github.apace100.apoli.data.ApoliDataTypes;
import io.github.apace100.apoli.data.TypedDataObjectFactory;
import io.github.apace100.apoli.util.Comparison;
import io.github.apace100.calio.data.SerializableData;
import io.github.apace100.calio.data.SerializableDataTypes;
import net.minecraft.class_1297;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import org.jetbrains.annotations.NotNull;

public class InBlockAnywhereEntityConditionType extends EntityConditionType {

    public static final TypedDataObjectFactory<InBlockAnywhereEntityConditionType> DATA_FACTORY = TypedDataObjectFactory.simple(
        new SerializableData()
            .add("block_condition", BlockCondition.DATA_TYPE)
            .add("comparison", ApoliDataTypes.COMPARISON, Comparison.GREATER_THAN)
            .add("compare_to", SerializableDataTypes.INT, 0),
        data -> new InBlockAnywhereEntityConditionType(
            data.get("block_condition"),
            data.get("comparison"),
            data.get("compare_to")
        ),
        (conditionType, serializableData) -> serializableData.instance()
            .set("block_condition", conditionType.blockCondition)
            .set("comparison", conditionType.comparison)
            .set("compare_to", conditionType.compareTo)
    );

    private final BlockCondition blockCondition;
    private final Comparison comparison;

    private final int compareTo;
    private final int threshold;

    public InBlockAnywhereEntityConditionType(BlockCondition blockCondition, Comparison comparison, int compareTo) {
        this.blockCondition = blockCondition;
        this.comparison = comparison;
        this.compareTo = compareTo;
        this.threshold = switch (comparison) {
            case EQUAL, LESS_THAN_OR_EQUAL, GREATER_THAN ->
                compareTo + 1;
            case LESS_THAN, GREATER_THAN_OR_EQUAL ->
                compareTo;
            default ->
                -1;
        };
    }

    @Override
    public boolean test(EntityConditionContext context) {

        class_1297 entity = context.entity();

        class_238 boundingBox = entity.method_5829();
        class_2338.class_2339 mutablePos = new class_2338.class_2339();

        class_2338 minPos = class_2338.method_49637(boundingBox.field_1323 + 0.001D, boundingBox.field_1322 + 0.001D, boundingBox.field_1321 + 0.001D);
        class_2338 maxPos = class_2338.method_49637(boundingBox.field_1320 - 0.001D, boundingBox.field_1325 - 0.001D, boundingBox.field_1324 - 0.001D);

        int matches = 0;
        for (int x = minPos.method_10263(); x <= maxPos.method_10263() && matches < threshold; x++) {
            for (int y = minPos.method_10264(); y <= maxPos.method_10264() && matches < threshold; y++) {
                for (int z = minPos.method_10260(); z <= maxPos.method_10260() && matches < threshold; z++) {

                    mutablePos.method_10103(x, y, z);

                    if (blockCondition.test(entity.method_37908(), mutablePos)) {
                        ++matches;
                    }

                }
            }
        }

        return comparison.compare(matches, compareTo);

    }

    @Override
    public @NotNull ConditionConfiguration<?> getConfig() {
        return EntityConditionTypes.IN_BLOCK_ANYWHERE;
    }

}
