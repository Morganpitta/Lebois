package io.github.apace100.apoli.access;

import net.minecraft.class_1657;

public interface PowerCraftingObject {

    class_1657 apoli$getPlayer();
    void apoli$setPlayer(class_1657 player);

}
