package io.github.apace100.apoli.access;

import net.minecraft.class_1657;
import org.jetbrains.annotations.Nullable;

public interface PowerCraftingObject {

    @Nullable
    class_1657 apoli$getPlayer();

    void apoli$setPlayer(@Nullable class_1657 player);

}
