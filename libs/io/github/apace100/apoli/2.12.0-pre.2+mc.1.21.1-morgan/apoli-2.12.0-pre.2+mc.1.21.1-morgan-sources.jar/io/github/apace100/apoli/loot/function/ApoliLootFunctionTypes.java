package io.github.apace100.apoli.loot.function;

import com.mojang.serialization.MapCodec;
import io.github.apace100.apoli.Apoli;
import net.minecraft.class_117;
import net.minecraft.class_2378;
import net.minecraft.class_5339;
import net.minecraft.class_7923;

public class ApoliLootFunctionTypes {

	public static final class_5339<AddPowerLootFunction> ADD_POWER = register("add_power", AddPowerLootFunction.MAP_CODEC);
	public static final class_5339<RemovePowerLootFunction> REMOVE_POWER = register("remove_power", RemovePowerLootFunction.MAP_CODEC);

	public static void register() {

	}

	public static <F extends class_117> class_5339<F> register(String path, MapCodec<F> mapCodec) {
		return class_2378.method_10230(class_7923.field_41134, Apoli.identifier(path), new class_5339<>(mapCodec));
	}

}
