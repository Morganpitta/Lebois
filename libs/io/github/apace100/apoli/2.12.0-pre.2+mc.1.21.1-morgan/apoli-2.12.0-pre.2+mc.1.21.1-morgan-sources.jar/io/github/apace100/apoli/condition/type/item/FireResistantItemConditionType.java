package io.github.apace100.apoli.condition.type.item;

import io.github.apace100.apoli.condition.ConditionConfiguration;
import io.github.apace100.apoli.condition.context.ItemConditionContext;
import io.github.apace100.apoli.condition.type.ItemConditionType;
import io.github.apace100.apoli.condition.type.ItemConditionTypes;
import net.minecraft.class_9334;
import org.jetbrains.annotations.NotNull;

public class FireResistantItemConditionType extends ItemConditionType {

	@Override
	public boolean test(ItemConditionContext context) {
		return context.stack().method_57826(class_9334.field_50076);
	}

	@Override
	public @NotNull ConditionConfiguration<?> getConfig() {
		return ItemConditionTypes.FIRE_RESISTANT;
	}

}
