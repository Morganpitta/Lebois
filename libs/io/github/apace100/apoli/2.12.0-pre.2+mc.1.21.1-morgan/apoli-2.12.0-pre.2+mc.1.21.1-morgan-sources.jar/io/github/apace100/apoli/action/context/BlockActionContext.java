package io.github.apace100.apoli.action.context;

import io.github.apace100.apoli.condition.context.BlockConditionContext;
import io.github.apace100.apoli.util.context.ActionContext;
import java.util.Optional;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_3218;

public record BlockActionContext(class_3218 world, class_2338 pos, Optional<class_2350> direction) implements ActionContext<BlockConditionContext> {

	@Override
	public BlockConditionContext forCondition() {
		return new BlockConditionContext(world(), pos());
	}

}
