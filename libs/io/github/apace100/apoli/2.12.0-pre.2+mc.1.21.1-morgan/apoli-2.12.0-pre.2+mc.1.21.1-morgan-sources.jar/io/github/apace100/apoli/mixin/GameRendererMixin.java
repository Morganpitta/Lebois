package io.github.apace100.apoli.mixin;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.llamalad7.mixinextras.injector.wrapmethod.WrapMethod;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import io.github.apace100.apoli.component.PowerHolderComponent;
import io.github.apace100.apoli.power.type.*;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1922;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2404;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_279;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3300;
import net.minecraft.class_4184;
import net.minecraft.class_5636;
import net.minecraft.class_757;
import net.minecraft.class_9779;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.*;

@Environment(EnvType.CLIENT)
@Mixin(class_757.class)
public abstract class GameRendererMixin {

    @Shadow
    @Final
    private class_4184 camera;

    @Shadow
    @Final
    class_310 client;

    @Shadow
    protected abstract void loadPostProcessor(class_2960 identifier);

    @Shadow
    class_279 postProcessor;
    @Shadow
    private boolean postProcessorEnabled;

    @Shadow
    @Final
    private class_3300 resourceManager;

    @Shadow
    public abstract void disablePostProcessor();

    @Unique
    private class_2960 apoli$currentlyLoadedShader;

    @Inject(at = @At("TAIL"), method = "onCameraEntitySet")
    private void apoli$loadShaderFromPowerOnCameraEntity(class_1297 entity, CallbackInfo ci) {

        PowerHolderComponent.getPowerTypes(client.method_1560(), ShaderPowerType.class)
            .stream()
            .filter(p -> resourceManager.method_14486(p.getShaderLocation()).isPresent())
            .max(Comparator.comparing(ShaderPowerType::getPriority))
            .ifPresent(p -> {

                class_2960 shaderLocation = p.getShaderLocation();

                loadPostProcessor(shaderLocation);
                apoli$currentlyLoadedShader = shaderLocation;

            });

    }

    @Inject(at = @At("HEAD"), method = "render")
    private void apoli$loadShaderFromPower(class_9779 tickCounter, boolean tick, CallbackInfo ci) {

        //  Load a shader from a shader power with a high priority
        PowerHolderComponent.getPowerTypes(client.method_1560(), ShaderPowerType.class)
            .stream()
            .filter(p -> resourceManager.method_14486(p.getShaderLocation()).isPresent())
            .max(Comparator.comparing(ShaderPowerType::getPriority))
            .ifPresent(p -> {
                class_2960 shaderLocation = p.getShaderLocation();
                if (shaderLocation != apoli$currentlyLoadedShader) {
                    loadPostProcessor(shaderLocation);
                    apoli$currentlyLoadedShader = shaderLocation;
                }
            });

        //  Remove the currently loaded shader if the entity doesn't have any shader powers
        if (!PowerHolderComponent.hasPowerType(client.method_1560(), ShaderPowerType.class) && apoli$currentlyLoadedShader != null) {

            if (postProcessor != null) {
                disablePostProcessor();
            }

            postProcessorEnabled = false;
            apoli$currentlyLoadedShader = null;

        }

    }

    @Inject(method = "render", at = @At(value = "FIELD", target = "Lnet/minecraft/client/option/GameOptions;hudHidden:Z"))
    private void apoli$renderOverlayPowersBelowHud(class_9779 tickCounter, boolean tick, CallbackInfo ci) {
        PowerHolderComponent.getPowerTypes(client.method_1560(), OverlayPowerType.class)
            .stream()
            .filter(p -> p.shouldRender(client.field_1690, OverlayPowerType.DrawPhase.BELOW_HUD))
            .sorted(Comparator.comparing(OverlayPowerType::getPriority))
            .forEach(OverlayPowerType::render);
    }

    @Inject(method = "render", at = @At(value = "INVOKE", target = "Lnet/minecraft/util/profiler/Profiler;pop()V", ordinal = 0))
    private void apoli$renderOverlayPowersAboveHud(class_9779 tickCounter, boolean tick, CallbackInfo ci) {
        PowerHolderComponent.getPowerTypes(client.method_1560(), OverlayPowerType.class)
            .stream()
            .filter(p -> p.shouldRender(client.field_1690, OverlayPowerType.DrawPhase.ABOVE_HUD))
            .sorted(Comparator.comparing(OverlayPowerType::getPriority))
            .forEach(OverlayPowerType::render);
    }

    @Inject(at = @At("HEAD"), method = "togglePostProcessorEnabled", cancellable = true)
    private void disableShaderToggle(CallbackInfo ci) {
        PowerHolderComponent.withPowerType(client.method_1560(), ShaderPowerType.class, p -> true, shaderPower -> {
            class_2960 shaderLoc = shaderPower.getShaderLocation();
            if(!shaderPower.isToggleable() && apoli$currentlyLoadedShader == shaderLoc) {
                ci.cancel();
            }
        });
    }

    // NightVisionPower
    @WrapMethod(method = "getNightVisionStrength")
    private static float apoli$modifyNightVisionStrength(class_1309 entity, float tickDelta, Operation<Float> original) {
        return PowerHolderComponent.getPowerTypes(entity, NightVisionPowerType.class)
            .stream()
            .map(NightVisionPowerType::getStrength)
            .max(Float::compareTo)
            .orElseGet(() -> original.call(entity, tickDelta));
    }

    @ModifyExpressionValue(method = "getFov", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/render/Camera;getSubmersionType()Lnet/minecraft/block/enums/CameraSubmersionType;"))
    private class_5636 apoli$modifySubmersionTypeFov(class_5636 original, class_4184 camera) {
        return PowerHolderComponent.getPowerTypes(camera.method_19331(), ModifyCameraSubmersionTypePowerType.class, true)
            .stream()
            .filter(p -> p.doesModify(original) && p.isActive())
            .findFirst()
            .map(ModifyCameraSubmersionTypePowerType::getNewType)
            .orElse(original);
    }

    @Unique
    private final HashMap<class_2338, class_2680> savedStates = new HashMap<>();

    // PHASING: remove_blocks
    @Inject(at = @At(value = "HEAD"), method = "render")
    private void beforeRender(class_9779 tickCounter, boolean tick, CallbackInfo ci) {
        List<PhasingPowerType> phasings = PowerHolderComponent.getPowerTypes(camera.method_19331(), PhasingPowerType.class);
        if (phasings.stream().anyMatch(pp -> pp.getRenderType() == PhasingPowerType.RenderType.REMOVE_BLOCKS)) {
            float view = phasings.stream().filter(pp -> pp.getRenderType() == PhasingPowerType.RenderType.REMOVE_BLOCKS).map(PhasingPowerType::getViewDistance).min(Float::compareTo).get();
            Set<class_2338> eyePositions = getEyePos(0.25F, 0.05F, 0.25F);
            Set<class_2338> noLongerEyePositions = new HashSet<>();
            for (class_2338 p : savedStates.keySet()) {
                if (!eyePositions.contains(p)) {
                    noLongerEyePositions.add(p);
                }
            }
            for (class_2338 eyePosition : noLongerEyePositions) {
                class_2680 state = savedStates.get(eyePosition);
                client.field_1687.method_8501(eyePosition, state);
                savedStates.remove(eyePosition);
            }
            for (class_2338 p : eyePositions) {
                class_2680 stateAtP = client.field_1687.method_8320(p);
                if (!savedStates.containsKey(p) && !client.field_1687.method_22347(p) && !(stateAtP.method_26204() instanceof class_2404)) {
                    savedStates.put(p, stateAtP);
                    client.field_1687.method_8501(p, class_2246.field_10124.method_9564());
                }
            }
        } else if (savedStates.size() > 0) {
            Set<class_2338> noLongerEyePositions = new HashSet<>(savedStates.keySet());
            for (class_2338 eyePosition : noLongerEyePositions) {
                class_2680 state = savedStates.get(eyePosition);
                client.field_1687.method_8501(eyePosition, state);
                savedStates.remove(eyePosition);
            }
        }
    }

    // PHASING
    @Redirect(at = @At(value = "INVOKE", target = "Lnet/minecraft/client/render/Camera;update(Lnet/minecraft/world/BlockView;Lnet/minecraft/entity/Entity;ZZF)V"), method = "renderWorld")
    private void preventThirdPerson(class_4184 camera, class_1922 area, class_1297 focusedEntity, boolean thirdPerson, boolean inverseView, float tickDelta) {
        if (PowerHolderComponent.getPowerTypes(camera.method_19331(), PhasingPowerType.class).stream().anyMatch(pp -> pp.getRenderType() == PhasingPowerType.RenderType.REMOVE_BLOCKS)) {
            camera.method_19321(area, focusedEntity, false, false, tickDelta);
        } else {
            camera.method_19321(area, focusedEntity, thirdPerson, inverseView, tickDelta);
        }
    }

    @Unique
    private Set<class_2338> getEyePos(float rangeX, float rangeY, float rangeZ) {
        class_243 pos = camera.method_19331().method_19538().method_1031(0, camera.method_19331().method_18381(camera.method_19331().method_18376()), 0);
        class_238 cameraBox = new class_238(pos, pos);
        cameraBox = cameraBox.method_1009(rangeX, rangeY, rangeZ);
        HashSet<class_2338> set = new HashSet<>();
        class_2338.method_29715(cameraBox).forEach(p -> set.add(p.method_10062()));
        return set;
    }

    @ModifyExpressionValue(method = "method_18144", at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/Entity;canHit()Z"))
    private static boolean apoli$preventEntitySelection(boolean original, class_1297 target) {
        class_1297 cameraEntity = class_310.method_1551().method_1560();
        return original
            && !PowerHolderComponent.hasPowerType(cameraEntity, PreventEntitySelectionPowerType.class, p -> p.doesPrevent(target));
    }

}
