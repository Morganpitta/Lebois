package io.github.apace100.apoli.condition.type.damage;

import io.github.apace100.apoli.condition.ConditionConfiguration;
import io.github.apace100.apoli.condition.EntityCondition;
import io.github.apace100.apoli.condition.context.DamageConditionContext;
import io.github.apace100.apoli.condition.type.DamageConditionType;
import io.github.apace100.apoli.condition.type.DamageConditionTypes;
import io.github.apace100.apoli.data.TypedDataObjectFactory;
import io.github.apace100.calio.data.SerializableData;
import io.github.apace100.calio.data.SerializableDataTypes;
import org.jetbrains.annotations.NotNull;

import java.util.Optional;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_8103;

public class ProjectileDamageConditionType extends DamageConditionType {

    public static final TypedDataObjectFactory<ProjectileDamageConditionType> DATA_FACTORY = TypedDataObjectFactory.simple(
        new SerializableData()
            .add("projectile", SerializableDataTypes.ENTITY_TYPE.optional(), Optional.empty())
            .add("projectile_condition", EntityCondition.DATA_TYPE.optional(), Optional.empty()),
        data -> new ProjectileDamageConditionType(
            data.get("projectile"),
            data.get("projectile_condition")
        ),
        (conditionType, serializableData) -> serializableData.instance()
            .set("projectile", conditionType.projectile)
            .set("projectile_condition", conditionType.projectileCondition)
    );

    private final Optional<class_1299<?>> projectile;
    private final Optional<EntityCondition> projectileCondition;

    public ProjectileDamageConditionType(Optional<class_1299<?>> projectile, Optional<EntityCondition> projectileCondition) {
        this.projectile = projectile;
        this.projectileCondition = projectileCondition;
    }

    @Override
    public boolean test(DamageConditionContext context) {

        class_1282 damageSource = context.source();
        class_1297 entitySource = damageSource.method_5526();

        return damageSource.method_48789(class_8103.field_42247)
            && entitySource != null
            && projectile.map(entitySource.method_5864()::equals).orElse(true)
            && projectileCondition.map(condition -> condition.test(entitySource)).orElse(true);

    }

    @Override
    public @NotNull ConditionConfiguration<?> getConfig() {
        return DamageConditionTypes.PROJECTILE;
    }

}
