package io.github.apace100.apoli.mixin.internal;

import org.jetbrains.annotations.ApiStatus;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

import java.util.Map;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_5132;
import net.minecraft.class_5135;

/**
 * Proxy to propagate
 *
 * @author Ampflower
 **/
@ApiStatus.Internal
@Mixin(class_5135.class)
public interface DefaultAttributeRegistryAccessor {

    @Accessor("DEFAULT_ATTRIBUTE_REGISTRY")
    static Map<class_1299<? extends class_1309>, class_5132> apoli$getRegistry() {
        throw new AssertionError();
    }
}
