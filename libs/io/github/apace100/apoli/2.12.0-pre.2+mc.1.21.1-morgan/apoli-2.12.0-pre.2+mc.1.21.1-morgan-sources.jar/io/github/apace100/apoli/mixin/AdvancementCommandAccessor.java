package io.github.apace100.apoli.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

import java.util.List;
import net.minecraft.class_3008;
import net.minecraft.class_8779;
import net.minecraft.class_8781;

@Mixin(class_3008.class)
public interface AdvancementCommandAccessor {

    @Invoker
    static void callAddChildrenRecursivelyToList(class_8781 parent, List<class_8779> children) {
        throw new AssertionError();
    }

}
