package io.github.apace100.apoli.mixin;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.llamalad7.mixinextras.sugar.Local;
import io.github.apace100.apoli.component.PowerHolderComponent;
import io.github.apace100.apoli.power.type.ModifyInsomniaTicksPowerType;
import net.minecraft.class_2910;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_2910.class)
public class PhantomSpawnerMixin {

    @ModifyExpressionValue(method = "spawn", at = @At(value = "INVOKE", target = "Lnet/minecraft/stat/ServerStatHandler;getStat(Lnet/minecraft/stat/Stat;)I"))
    private int apoli$modifyEffectiveTimeSinceRestValue(int original, class_3218 world, boolean spawnMonsters, boolean spawnAnimals, @Local class_3222 player) {
        return (int) PowerHolderComponent.modify(player, ModifyInsomniaTicksPowerType.class, original);
    }

}
