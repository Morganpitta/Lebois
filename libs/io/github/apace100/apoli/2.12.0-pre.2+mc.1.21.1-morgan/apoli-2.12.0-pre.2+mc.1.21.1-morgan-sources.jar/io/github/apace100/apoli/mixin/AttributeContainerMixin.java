package io.github.apace100.apoli.mixin;

import com.llamalad7.mixinextras.sugar.Local;
import io.github.apace100.apoli.access.OwnableAttributeContainer;
import io.github.apace100.apoli.access.OwnableAttributeInstance;
import net.minecraft.class_1297;
import net.minecraft.class_1320;
import net.minecraft.class_1324;
import net.minecraft.class_5131;
import net.minecraft.class_5132;
import net.minecraft.class_6880;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_5131.class)
public abstract class AttributeContainerMixin implements OwnableAttributeContainer {

    @Shadow
    @Final
    private class_5132 fallback;

    @Unique
    @Nullable
    private class_1297 apoli$owner;

    @Override
    @Nullable
    public class_1297 apoli$getOwner() {
        return apoli$owner;
    }

    @Override
    public void apoli$setOwner(class_1297 owner) {
        this.apoli$owner = owner;
    }

    @Inject(method = "getCustomInstance", at = @At("RETURN"))
    private void apoli$setCustomAttributeInstanceOwner(class_6880<class_1320> attribute, CallbackInfoReturnable<class_1324> cir) {

        if (cir.getReturnValue() instanceof OwnableAttributeInstance ownableAttributeInstance) {
            ownableAttributeInstance.apoli$setOwner(this.apoli$getOwner());
        }

    }

    @Inject(method = "getValue", at = @At("RETURN"))
    private void apoli$setAttributeInstanceOwner(class_6880<class_1320> attribute, CallbackInfoReturnable<Double> cir, @Local class_1324 attributeInstance) {

        if (attributeInstance instanceof OwnableAttributeInstance ownableAttributeInstance) {
            ownableAttributeInstance.apoli$setOwner(this.apoli$getOwner());
        }

        if (this.fallback instanceof OwnableAttributeContainer ownableAttributeContainer) {
            ownableAttributeContainer.apoli$setOwner(this.apoli$getOwner());
        }

    }

}
