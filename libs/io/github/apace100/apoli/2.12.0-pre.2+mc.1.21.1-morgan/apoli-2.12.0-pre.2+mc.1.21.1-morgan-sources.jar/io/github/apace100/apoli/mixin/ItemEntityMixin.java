package io.github.apace100.apoli.mixin;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import io.github.apace100.apoli.power.type.ActionOnItemPickupPowerType;
import io.github.apace100.apoli.power.type.PreventItemPickupPowerType;
import io.github.apace100.apoli.power.type.Prioritized;
import io.github.apace100.apoli.util.InventoryUtil;
import io.github.apace100.apoli.util.MiscUtil;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;

import java.util.UUID;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_5630;

@Mixin(class_1542.class)
public abstract class ItemEntityMixin extends class_1297 {

    @Shadow
    @Nullable
    private UUID throwerUuid;

    @Shadow
    public abstract class_1799 getStack();

    @Shadow
    public abstract void setStack(class_1799 stack);

    private ItemEntityMixin(class_1299<?> type, class_1937 world) {
        super(type, world);
    }

    @WrapOperation(method = "onPlayerCollision", at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/player/PlayerInventory;insertStack(Lnet/minecraft/item/ItemStack;)Z"))
    private boolean apoli$onItemPickup(class_1661 playerInventory, class_1799 stack, Operation<Boolean> original, class_1657 player) {

        if (PreventItemPickupPowerType.doesPrevent(thisAsItemEntity(), player)) {
            return false;
        }

        else if (MiscUtil.hasSpaceInInventory(playerInventory, stack)) {

            class_5630 stackReference = InventoryUtil.createStackReference(stack);
            class_1297 thrower = MiscUtil.getEntityByUuid(this.throwerUuid, this.method_5682());

            Prioritized.CallInstance<ActionOnItemPickupPowerType> callInstance = ActionOnItemPickupPowerType.executeItemAction(thrower, stackReference, player);
            this.setStack(stackReference.method_32327());

            boolean result = original.call(playerInventory, this.getStack());
            if (result) {
                ActionOnItemPickupPowerType.executeBiEntityAction(callInstance, thrower);
            }

            return result;

        }

        else {
            return original.call(playerInventory, stack);
        }

    }

    @Unique
    private class_1542 thisAsItemEntity() {
        return (class_1542) (Object) this;
    }

}
