package io.github.apace100.apoli.loot.function;

import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.apace100.apoli.Apoli;
import io.github.apace100.apoli.component.PowerHolderComponent;
import io.github.apace100.apoli.component.item.ApoliDataComponentTypes;
import io.github.apace100.apoli.component.item.ItemPowersComponent;
import io.github.apace100.apoli.power.Power;
import io.github.apace100.apoli.power.PowerManager;
import io.github.apace100.calio.data.SerializableDataTypes;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import java.util.*;
import net.minecraft.class_120;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1799;
import net.minecraft.class_181;
import net.minecraft.class_2960;
import net.minecraft.class_47;
import net.minecraft.class_5339;
import net.minecraft.class_5341;
import net.minecraft.class_9274;
import net.minecraft.class_9326;

public class RemovePowerLootFunction extends class_120 {

    public static final MapCodec<RemovePowerLootFunction> MAP_CODEC = RecordCodecBuilder.mapCodec(instance -> method_53344(instance).and(instance.group(
        SerializableDataTypes.ATTRIBUTE_MODIFIER_SLOT_SET.codec().optionalFieldOf("slot", EnumSet.allOf(class_9274.class)).forGetter(RemovePowerLootFunction::slots),
        class_2960.field_25139.fieldOf("power").forGetter(RemovePowerLootFunction::powerId)
    )).apply(instance, RemovePowerLootFunction::new));

    private final EnumSet<class_9274> slots;
    private final class_2960 powerId;

    private RemovePowerLootFunction(List<class_5341> conditions, EnumSet<class_9274> slots, class_2960 powerId) {
        super(conditions);
        this.slots = slots;
        this.powerId = powerId;
    }

    @Override
    public class_5339<? extends class_120> method_29321() {
        return ApoliLootFunctionTypes.REMOVE_POWER;
    }

    @Override
    public class_1799 method_522(class_1799 stack, class_47 context) {

        ItemPowersComponent itemPowers = stack.method_57824(ApoliDataComponentTypes.POWERS);
        class_9326.class_9327 componentChanges = class_9326.method_57841();

        if (itemPowers == null) {
            return stack;
        }

        ItemPowersComponent newItemPowers = ItemPowersComponent.builder(itemPowers)
            .remove(slots, powerId, removedEntries -> onSlotsRemoval(context, removedEntries))
            .build();

        if (newItemPowers.isEmpty()) {
            componentChanges.method_57853(ApoliDataComponentTypes.POWERS);
        }

        else {
            componentChanges.method_57854(ApoliDataComponentTypes.POWERS, newItemPowers);
        }

        stack.method_59692(componentChanges.method_57852());
        return stack;

    }

    protected void onSlotsRemoval(class_47 context, Collection<ItemPowersComponent.Entry> removedEntries) {

        class_1297 entity = context.method_296(class_181.field_1226);
        Power power = PowerManager.getOptional(powerId).orElse(null);

        if (entity == null || power == null) {
            return;
        }

        PowerHolderComponent powerComponent = PowerHolderComponent.KEY.getNullable(entity);
        if (powerComponent == null) {
            return;
        }

        Map<class_2960, Collection<Power>> revokedPowers = new HashMap<>();
        for (ItemPowersComponent.Entry entry : removedEntries) {

            class_9274 modifierSlot = entry.slot();

            for (class_1304 slot : class_1304.values()) {

                class_2960 sourceId = Apoli.identifier("item/" + slot.method_5923());

                if (!revokedPowers.containsKey(sourceId) && modifierSlot.method_57286(slot)) {
                    revokedPowers
                        .computeIfAbsent(sourceId, k -> new ObjectArrayList<>())
                        .add(power);
                }

            }

        }

        if (!revokedPowers.isEmpty()) {
            PowerHolderComponent.revokePowers(entity, revokedPowers, true);
        }

    }

    public EnumSet<class_9274> slots() {
        return slots;
    }

    public class_2960 powerId() {
        return powerId;
    }

}
