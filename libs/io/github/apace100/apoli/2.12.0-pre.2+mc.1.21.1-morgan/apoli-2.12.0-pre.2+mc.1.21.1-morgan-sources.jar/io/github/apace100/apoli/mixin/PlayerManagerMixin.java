package io.github.apace100.apoli.mixin;

import com.llamalad7.mixinextras.injector.v2.WrapWithCondition;
import com.llamalad7.mixinextras.sugar.Local;
import io.github.apace100.apoli.access.EndRespawningEntity;
import io.github.apace100.apoli.component.PowerHolderComponent;
import io.github.apace100.apoli.power.type.PowerType;
import net.minecraft.class_1297;
import net.minecraft.class_3222;
import net.minecraft.class_3324;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value = class_3324.class, priority = 800)
public abstract class PlayerManagerMixin {

	@WrapWithCondition(method = "respawnPlayer", at = @At(value = "INVOKE", target = "Lnet/minecraft/server/network/ServerPlayerEntity;setSpawnPointFrom(Lnet/minecraft/server/network/ServerPlayerEntity;)V"))
	private boolean apoli$preventEndExitSpawnpointResetting(class_3222 newPlayer, class_3222 oldPlayer) {
		return ((EndRespawningEntity) oldPlayer).apoli$hasRealRespawnPoint();
	}

	@Inject(method = "respawnPlayer", at = @At(value = "INVOKE", target = "Lnet/minecraft/server/network/ServerPlayerEntity;onSpawn()V"))
	private void apoli$invokeOnRespawnPowerCallback(class_3222 player, boolean alive, class_1297.class_5529 removalReason, CallbackInfoReturnable<class_3222> cir, @Local(ordinal = 1) class_3222 newPlayer) {
		if (!alive) {
			PowerHolderComponent.KEY.get(newPlayer).getPowerTypes().forEach(PowerType::onRespawn);
		}
	}

}
