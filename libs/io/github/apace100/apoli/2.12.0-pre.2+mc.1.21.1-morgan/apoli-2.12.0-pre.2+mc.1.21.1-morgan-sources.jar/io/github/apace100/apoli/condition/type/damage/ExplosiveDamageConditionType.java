package io.github.apace100.apoli.condition.type.damage;

import io.github.apace100.apoli.condition.ConditionConfiguration;
import io.github.apace100.apoli.condition.type.DamageConditionTypes;
import net.minecraft.class_8103;
import org.jetbrains.annotations.NotNull;

@Deprecated(forRemoval = true)
public class ExplosiveDamageConditionType extends InTagDamageConditionType {

	public ExplosiveDamageConditionType() {
		super(class_8103.field_42249);
	}

	@Override
	public @NotNull ConditionConfiguration<?> getConfig() {
		return DamageConditionTypes.EXPLOSIVE;
	}

}
