package io.github.apace100.apoli.action.type.entity;

import io.github.apace100.apoli.action.ActionConfiguration;
import io.github.apace100.apoli.action.ItemAction;
import io.github.apace100.apoli.action.context.EntityActionContext;
import io.github.apace100.apoli.action.type.EntityActionType;
import io.github.apace100.apoli.action.type.EntityActionTypes;
import io.github.apace100.apoli.data.TypedDataObjectFactory;
import io.github.apace100.apoli.util.InventoryUtil;
import io.github.apace100.calio.data.SerializableData;
import io.github.apace100.calio.data.SerializableDataTypes;
import org.jetbrains.annotations.NotNull;

import java.util.Optional;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_5630;
import net.minecraft.class_9274;

public class GiveEntityActionType extends EntityActionType {

    public static final TypedDataObjectFactory<GiveEntityActionType> DATA_FACTORY = TypedDataObjectFactory.simple(
        new SerializableData()
            .add("item_action", ItemAction.DATA_TYPE.optional(), Optional.empty())
            .add("preferred_slot", SerializableDataTypes.ATTRIBUTE_MODIFIER_SLOT.optional(), Optional.empty())
            .add("stack", SerializableDataTypes.ITEM_STACK),
        data -> new GiveEntityActionType(
            data.get("item_action"),
            data.get("preferred_slot"),
            data.get("stack")
        ),
        (actionType, serializableData) -> serializableData.instance()
            .set("item_action", actionType.itemAction)
            .set("preferred_slot", actionType.preferredSlot)
            .set("stack", actionType.stack)
    );

    private final Optional<ItemAction> itemAction;

    private final Optional<class_9274> preferredSlot;
    private final class_1799 stack;

    public GiveEntityActionType(Optional<ItemAction> itemAction, Optional<class_9274> preferredSlot, class_1799 stack) {
        this.itemAction = itemAction;
        this.preferredSlot = preferredSlot;
        this.stack = stack;
    }

    @Override
    public void accept(EntityActionContext context) {

        class_1297 entity = context.entity();

        if (entity.method_37908().method_8608() || stack.method_7960()) {
            return;
        }

        class_5630 stackReference = InventoryUtil.createStackReference(stack.method_7972());
        itemAction.ifPresent(action -> action.execute(entity.method_37908(), stackReference));

        class_1799 stackToGive = stackReference.method_32327();

        if (preferredSlot.isPresent() && entity instanceof class_1309 living) {

            class_9274 actualPreferredSlot = preferredSlot.get();
            for (class_1304 slot : class_1304.values()) {

                if (!actualPreferredSlot.method_57286(slot)) {
                    continue;
                }

                class_1799 stackInSlot = living.method_6118(slot);
                if (stackInSlot.method_7960()) {
                    living.method_5673(slot, stackToGive);
                    return;
                }

                else if (class_1799.method_7973(stackInSlot, stackToGive) && stackInSlot.method_7947() < stackInSlot.method_7914()) {

                    int itemsToGive = Math.min(stackInSlot.method_7914() - stackInSlot.method_7947(), stackToGive.method_7947());

                    stackInSlot.method_7933(itemsToGive);
                    stackToGive.method_7934(itemsToGive);

                    if (stackToGive.method_7960()) {
                        return;
                    }

                }

            }

        }

        if (entity instanceof class_1657 player) {
            player.method_31548().method_7398(stackToGive);
        }

        else {
            InventoryUtil.throwItem(entity, stackToGive, false , false);
        }

    }

    @Override
    public @NotNull ActionConfiguration<?> getConfig() {
        return EntityActionTypes.GIVE;
    }

}
