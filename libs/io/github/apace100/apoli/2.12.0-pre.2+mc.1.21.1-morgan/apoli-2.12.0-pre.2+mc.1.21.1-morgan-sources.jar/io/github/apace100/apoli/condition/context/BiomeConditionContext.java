package io.github.apace100.apoli.condition.context;

import io.github.apace100.apoli.util.context.ConditionContext;
import net.minecraft.class_1959;
import net.minecraft.class_2338;
import net.minecraft.class_6880;

public record BiomeConditionContext(class_2338 pos, class_6880<class_1959> biomeEntry) implements ConditionContext {

}
