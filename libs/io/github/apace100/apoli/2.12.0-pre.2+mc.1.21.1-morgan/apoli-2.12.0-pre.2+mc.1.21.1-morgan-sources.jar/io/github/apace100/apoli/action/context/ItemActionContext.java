package io.github.apace100.apoli.action.context;

import io.github.apace100.apoli.condition.context.ItemConditionContext;
import io.github.apace100.apoli.util.context.ActionContext;
import net.minecraft.class_3218;
import net.minecraft.class_5630;

public record ItemActionContext(class_3218 world, class_5630 stackReference) implements ActionContext<ItemConditionContext> {

	@Override
	public ItemConditionContext forCondition() {
		return new ItemConditionContext(world(), stackReference().method_32327());
	}

}
