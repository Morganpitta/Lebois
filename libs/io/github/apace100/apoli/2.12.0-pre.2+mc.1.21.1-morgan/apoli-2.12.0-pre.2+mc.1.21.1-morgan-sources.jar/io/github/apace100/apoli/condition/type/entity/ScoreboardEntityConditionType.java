package io.github.apace100.apoli.condition.type.entity;

import io.github.apace100.apoli.condition.ConditionConfiguration;
import io.github.apace100.apoli.condition.context.EntityConditionContext;
import io.github.apace100.apoli.condition.type.EntityConditionType;
import io.github.apace100.apoli.condition.type.EntityConditionTypes;
import io.github.apace100.apoli.data.ApoliDataTypes;
import io.github.apace100.apoli.data.TypedDataObjectFactory;
import io.github.apace100.apoli.util.Comparison;
import io.github.apace100.calio.data.SerializableData;
import io.github.apace100.calio.data.SerializableDataTypes;
import org.jetbrains.annotations.NotNull;

import java.util.Optional;
import net.minecraft.class_1297;
import net.minecraft.class_269;
import net.minecraft.class_9013;
import net.minecraft.class_9015;

public class ScoreboardEntityConditionType extends EntityConditionType {

    public static final TypedDataObjectFactory<ScoreboardEntityConditionType> DATA_FACTORY = TypedDataObjectFactory.simple(
        new SerializableData()
            .add("name", SerializableDataTypes.STRING.optional(), Optional.empty())
            .add("objective", SerializableDataTypes.STRING)
            .add("comparison", ApoliDataTypes.COMPARISON)
            .add("compare_to", SerializableDataTypes.INT),
        data -> new ScoreboardEntityConditionType(
            data.get("name"),
            data.get("objective"),
            data.get("comparison"),
            data.get("compare_to")
        ),
        (conditionType, serializableData) -> serializableData.instance()
            .set("name", conditionType.name)
            .set("objective", conditionType.objective)
            .set("comparison", conditionType.comparison)
            .set("compare_to", conditionType.compareTo)
    );

    private final Optional<String> name;
    private final String objective;

    private final Comparison comparison;
    private final int compareTo;

    public ScoreboardEntityConditionType(Optional<String> name, String objective, Comparison comparison, int compareTo) {
        this.name = name;
        this.objective = objective;
        this.comparison = comparison;
        this.compareTo = compareTo;
    }

    @Override
    public boolean test(EntityConditionContext context) {

        class_1297 entity = context.entity();

        class_9015 scoreHolder = class_9015.method_55422(name.orElse(entity.method_5820()));
        class_269 scoreboard = entity.method_37908().method_8428();

        return Optional.ofNullable(scoreboard.method_1170(objective))
            .flatMap(objective -> Optional.ofNullable(scoreboard.method_55430(scoreHolder, objective)))
            .map(class_9013::method_55397)
            .map(score -> comparison.compare(score, compareTo))
            .orElse(false);

    }

    @Override
    public @NotNull ConditionConfiguration<?> getConfig() {
        return EntityConditionTypes.SCOREBOARD;
    }

}
