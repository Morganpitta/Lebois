package io.github.apace100.apoli.mixin.internal;

import org.jetbrains.annotations.ApiStatus;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

import java.util.Map;
import net.minecraft.class_1324;
import net.minecraft.class_5132;

/**
 * @author Ampflower
 **/
@ApiStatus.Internal
@Mixin(class_5132.class)
public interface DefaultAttributeContainerAccessor {
    @Accessor
    Map<?, class_1324> getInstances();
}
