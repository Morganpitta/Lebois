package io.github.apace100.apoli.condition.type.entity;

import io.github.apace100.apoli.condition.ConditionConfiguration;
import io.github.apace100.apoli.condition.context.EntityConditionContext;
import io.github.apace100.apoli.condition.type.EntityConditionType;
import io.github.apace100.apoli.condition.type.EntityConditionTypes;
import io.github.apace100.apoli.data.ApoliDataTypes;
import io.github.apace100.apoli.data.TypedDataObjectFactory;
import io.github.apace100.apoli.util.Comparison;
import io.github.apace100.calio.data.SerializableData;
import io.github.apace100.calio.data.SerializableDataTypes;
import org.jetbrains.annotations.NotNull;

import java.util.Optional;
import net.minecraft.class_1309;
import net.minecraft.class_1320;
import net.minecraft.class_1324;
import net.minecraft.class_6880;

public class AttributeEntityConditionType extends EntityConditionType {

    public static final TypedDataObjectFactory<AttributeEntityConditionType> DATA_FACTORY = TypedDataObjectFactory.simple(
        new SerializableData()
            .add("attribute", SerializableDataTypes.ATTRIBUTE_ENTRY)
            .add("comparison", ApoliDataTypes.COMPARISON)
            .add("compare_to", SerializableDataTypes.DOUBLE),
        data -> new AttributeEntityConditionType(
            data.get("attribute"),
            data.get("comparison"),
            data.get("compare_to")
        ),
        (conditionType, serializableData) -> serializableData.instance()
            .set("attribute", conditionType.attribute)
            .set("comparison", conditionType.comparison)
            .set("compare_to", conditionType.compareTo)
    );

    private final class_6880<class_1320> attribute;

    private final Comparison comparison;
    private final double compareTo;

    public AttributeEntityConditionType(class_6880<class_1320> attribute, Comparison comparison, double compareTo) {
        this.attribute = attribute;
        this.comparison = comparison;
        this.compareTo = compareTo;
    }

    @Override
    public boolean test(EntityConditionContext context) {

        if (context.entity() instanceof class_1309 livingEntity) {
            return Optional.ofNullable(livingEntity.method_5996(attribute))
                .map(class_1324::method_6194)
                .map(value -> comparison.compare(value, compareTo))
                .orElse(false);
        }

        else {
            return false;
        }

    }

    @Override
    public @NotNull ConditionConfiguration<?> getConfig() {
        return EntityConditionTypes.ATTRIBUTE;
    }

}
