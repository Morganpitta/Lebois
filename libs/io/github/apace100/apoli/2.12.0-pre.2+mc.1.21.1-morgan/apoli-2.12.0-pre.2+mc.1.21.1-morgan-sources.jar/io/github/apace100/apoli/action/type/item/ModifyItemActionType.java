package io.github.apace100.apoli.action.type.item;

import io.github.apace100.apoli.access.EntityLinkedItemStack;
import io.github.apace100.apoli.action.ActionConfiguration;
import io.github.apace100.apoli.action.context.ItemActionContext;
import io.github.apace100.apoli.action.type.ItemActionType;
import io.github.apace100.apoli.action.type.ItemActionTypes;
import io.github.apace100.apoli.data.TypedDataObjectFactory;
import io.github.apace100.apoli.loot.context.ApoliLootContextTypes;
import io.github.apace100.calio.data.SerializableData;
import io.github.apace100.calio.data.SerializableDataTypes;
import org.jetbrains.annotations.NotNull;

import java.util.Optional;
import net.minecraft.class_117;
import net.minecraft.class_1799;
import net.minecraft.class_181;
import net.minecraft.class_3218;
import net.minecraft.class_47;
import net.minecraft.class_5321;
import net.minecraft.class_5630;
import net.minecraft.class_7924;
import net.minecraft.class_8567;

public class ModifyItemActionType extends ItemActionType {

    public static final TypedDataObjectFactory<ModifyItemActionType> DATA_FACTORY = TypedDataObjectFactory.simple(
        new SerializableData()
            .add("modifier", SerializableDataTypes.ITEM_MODIFIER),
        data -> new ModifyItemActionType(
            data.get("modifier")
        ),
        (actionType, serializableData) -> serializableData.instance()
            .set("modifier", actionType.modifier)
    );

    private final class_5321<class_117> modifier;

    public ModifyItemActionType(class_5321<class_117> modifier) {
        this.modifier = modifier;
    }

    @Override
    public void accept(ItemActionContext context) {

        class_3218 world = context.world();
        class_5630 stackReference = context.stackReference();

        class_1799 oldStack = stackReference.method_32327();
        class_117 itemModifier = world.method_8503().method_58576()
            .method_58289()
            .method_30530(class_7924.field_50080)
            .method_31140(modifier);

        class_8567 lootContextParameterSet = new class_8567.class_8568(world)
            .method_51874(class_181.field_24424, world.method_43126().method_46558())
            .method_51874(class_181.field_1229, oldStack)
            .method_51877(class_181.field_1226, ((EntityLinkedItemStack) oldStack).apoli$getEntity())
            .method_51875(ApoliLootContextTypes.ANY);

        class_1799 newStack = itemModifier.apply(oldStack, new class_47.class_48(lootContextParameterSet).method_309(Optional.empty()));
        stackReference.method_32332(newStack);

    }

    @Override
    public @NotNull ActionConfiguration<?> getConfig() {
        return ItemActionTypes.MODIFY;
    }

}
