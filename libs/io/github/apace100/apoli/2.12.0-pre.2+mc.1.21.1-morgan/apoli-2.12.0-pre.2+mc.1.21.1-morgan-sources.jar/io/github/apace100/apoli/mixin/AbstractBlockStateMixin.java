package io.github.apace100.apoli.mixin;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import com.llamalad7.mixinextras.injector.v2.WrapWithCondition;
import com.mojang.serialization.MapCodec;
import io.github.apace100.apoli.access.BlockStateCollisionShapeAccess;
import io.github.apace100.apoli.component.PowerHolderComponent;
import io.github.apace100.apoli.power.type.PhasingPowerType;
import io.github.apace100.apoli.power.type.PreventBlockSelectionPowerType;
import it.unimi.dsi.fastutil.objects.Reference2ObjectArrayMap;
import net.minecraft.class_1297;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2688;
import net.minecraft.class_2769;
import net.minecraft.class_3726;
import net.minecraft.class_4970;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_4970.class_4971.class)
public abstract class AbstractBlockStateMixin extends class_2688<class_2248, class_2680> implements BlockStateCollisionShapeAccess {

    @Shadow
    public abstract class_2248 getBlock();

    @Shadow
    public abstract class_265 getCollisionShape(class_1922 world, class_2338 pos, class_3726 context);

    @Unique
    private boolean apoli$queryOriginal = false;

    protected AbstractBlockStateMixin(class_2248 owner, Reference2ObjectArrayMap<class_2769<?>, Comparable<?>> propertyMap, MapCodec<class_2680> codec) {
        super(owner, propertyMap, codec);
    }

    @ModifyReturnValue(method = "getOutlineShape(Lnet/minecraft/world/BlockView;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/block/ShapeContext;)Lnet/minecraft/util/shape/VoxelShape;", at = @At("RETURN"))
    private class_265 apoli$preventBlockSelection(class_265 original, class_1922 blockView, class_2338 blockPos, class_3726 context) {

        if (context == class_3726.method_16194()) {
            return original;
        }

        else {
            return PreventBlockSelectionPowerType.doesPrevent(context, blockPos)
                ? class_259.method_1073()
                : original;
        }

    }

    @ModifyReturnValue(method = "getCollisionShape(Lnet/minecraft/world/BlockView;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/block/ShapeContext;)Lnet/minecraft/util/shape/VoxelShape;", at = @At("RETURN"))
    private class_265 apoli$phaseThroughBlocks(class_265 original, class_1922 blockView, class_2338 blockPos, class_3726 context) {

        if (context == class_3726.method_16194()) {
            return original;
        }

        else {
            return !apoli$queryOriginal && PhasingPowerType.shouldPhase(context, original, blockPos)
                ? class_259.method_1073()
                : original;
        }

    }

    @WrapWithCondition(method = "onEntityCollision", at = @At(value = "INVOKE", target = "Lnet/minecraft/block/Block;onEntityCollision(Lnet/minecraft/block/BlockState;Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/entity/Entity;)V"))
    private boolean apoli$preventOnEntityCollisionCallWhenPhasing(class_2248 instance, class_2680 state, class_1937 world, class_2338 blockPos, class_1297 entity) {
        return !PowerHolderComponent.hasPowerType(entity, PhasingPowerType.class, p -> p.doesApply(blockPos));
    }

    @Override
    public class_265 apoli$getOriginalCollisionShape(class_1922 world, class_2338 pos, class_3726 context) {

        this.apoli$queryOriginal = true;
        class_265 originalShape = this.getCollisionShape(world, pos, context);

        this.apoli$queryOriginal = false;
        return originalShape;

    }

}
