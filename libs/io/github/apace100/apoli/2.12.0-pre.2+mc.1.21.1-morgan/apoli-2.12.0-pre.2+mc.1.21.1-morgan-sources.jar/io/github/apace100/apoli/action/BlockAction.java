package io.github.apace100.apoli.action;

import io.github.apace100.apoli.action.context.BlockActionContext;
import io.github.apace100.apoli.action.type.BlockActionType;
import io.github.apace100.apoli.action.type.BlockActionTypes;
import io.github.apace100.apoli.action.type.block.meta.SequenceBlockActionType;
import io.github.apace100.apoli.data.ApoliDataTypes;
import io.github.apace100.calio.data.SerializableDataType;
import org.jetbrains.annotations.Nullable;

import java.util.Optional;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_3218;

public final class BlockAction extends Action<BlockActionContext, BlockActionType> {

	public static final SerializableDataType<BlockAction> DATA_TYPE = SerializableDataType.lazy(() -> ApoliDataTypes.actions("type", BlockActionTypes.DATA_TYPE, SequenceBlockActionType::new, BlockAction::new));

	public BlockAction(BlockActionType actionType) {
		super(actionType);
	}

	public void execute(class_1937 world, class_2338 pos) {
		execute(world, pos, Optional.empty());
	}

	public void execute(class_1937 world, class_2338 pos, @Nullable class_2350 direction) {
		execute(world, pos, Optional.ofNullable(direction));
	}

	public void execute(class_1937 world, class_2338 pos, Optional<class_2350> direction) {

		if (world instanceof class_3218 serverWorld) {
			accept(new BlockActionContext(serverWorld, pos, direction));
		}

	}

}
