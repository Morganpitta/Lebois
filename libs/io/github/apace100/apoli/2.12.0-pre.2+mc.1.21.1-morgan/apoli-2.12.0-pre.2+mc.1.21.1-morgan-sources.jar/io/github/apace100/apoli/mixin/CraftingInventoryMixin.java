package io.github.apace100.apoli.mixin;

import io.github.apace100.apoli.access.PowerCraftingInventory;
import io.github.apace100.apoli.power.type.PowerType;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;

import java.util.Collection;
import java.util.LinkedList;
import net.minecraft.class_1657;
import net.minecraft.class_1715;

@Mixin(class_1715.class)
public abstract class CraftingInventoryMixin implements PowerCraftingInventory {

    @Unique
    private Collection<? extends PowerType> apoli$CachedPowerTypes = new LinkedList<>();

    @Unique
    private class_1657 apoli$cachedPlayer;

    @Override
    public Collection<? extends PowerType> apoli$getPowerTypes() {
        return apoli$CachedPowerTypes;
    }

    @Override
    public void apoli$setPowerTypes(Collection<? extends PowerType> powerTypes) {
        apoli$CachedPowerTypes = powerTypes;
    }

    @Override
    public class_1715 apoli$getInventory() {
        return (class_1715) (Object) this;
    }

    @Override
    public class_1657 apoli$getPlayer() {
        return apoli$cachedPlayer;
    }

    @Override
    public void apoli$setPlayer(class_1657 player) {
        this.apoli$cachedPlayer = player;
    }

}
