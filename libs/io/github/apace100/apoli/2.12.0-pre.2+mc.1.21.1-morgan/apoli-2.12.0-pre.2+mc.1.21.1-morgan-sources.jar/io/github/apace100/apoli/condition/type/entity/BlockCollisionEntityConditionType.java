package io.github.apace100.apoli.condition.type.entity;

import io.github.apace100.apoli.access.BlockCollisionSpliteratorAccess;
import io.github.apace100.apoli.condition.BlockCondition;
import io.github.apace100.apoli.condition.ConditionConfiguration;
import io.github.apace100.apoli.condition.context.EntityConditionContext;
import io.github.apace100.apoli.condition.type.EntityConditionType;
import io.github.apace100.apoli.condition.type.EntityConditionTypes;
import io.github.apace100.apoli.data.TypedDataObjectFactory;
import io.github.apace100.calio.data.SerializableData;
import io.github.apace100.calio.data.SerializableDataTypes;
import org.jetbrains.annotations.NotNull;

import java.util.Optional;
import net.minecraft.class_1297;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_5329;

public class BlockCollisionEntityConditionType extends EntityConditionType {

    public static final TypedDataObjectFactory<BlockCollisionEntityConditionType> DATA_FACTORY = TypedDataObjectFactory.simple(
        new SerializableData()
            .add("block_condition", BlockCondition.DATA_TYPE.optional(), Optional.empty())
            .add("offset_x", SerializableDataTypes.DOUBLE, 0.0)
            .add("offset_y", SerializableDataTypes.DOUBLE, 0.0)
            .add("offset_z", SerializableDataTypes.DOUBLE, 0.0)
            .addFunctionedDefault("offset", SerializableDataTypes.VECTOR, data -> new class_243(data.get("offset_x"), data.get("offset_y"), data.get("offset_z"))),
        data -> new BlockCollisionEntityConditionType(
            data.get("block_condition"),
            data.get("offset")
        ),
        (conditionType, serializableData) -> serializableData.instance()
            .set("block_condition", conditionType.blockCondition)
            .set("offset", conditionType.offset)
    );

    private final Optional<BlockCondition> blockCondition;
    private final class_243 offset;

    public BlockCollisionEntityConditionType(Optional<BlockCondition> blockCondition, class_243 offset) {
        this.blockCondition = blockCondition;
        this.offset = offset;
    }

    @Override
    public boolean test(EntityConditionContext context) {

        class_1297 entity = context.entity();

        class_238 boundingBox = entity.method_5829().method_997(offset);
        class_1937 world = entity.method_37908();

        class_5329<class_2338> spliterator = new class_5329<>(world, entity, boundingBox, false, (pos, shape) -> pos);
        ((BlockCollisionSpliteratorAccess) spliterator).apoli$setGetOriginalShapes(true);

        while (spliterator.hasNext()) {

            class_2338 pos = spliterator.next();

            if (blockCondition.map(condition -> condition.test(world, pos)).orElse(true)) {
                return true;
            }

        }

        return false;

    }

    @Override
    public @NotNull ConditionConfiguration<?> getConfig() {
        return EntityConditionTypes.BLOCK_COLLISION;
    }

}
