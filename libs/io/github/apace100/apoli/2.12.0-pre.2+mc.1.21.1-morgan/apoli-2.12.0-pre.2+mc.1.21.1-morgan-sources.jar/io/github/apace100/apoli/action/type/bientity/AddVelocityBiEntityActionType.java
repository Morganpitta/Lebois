package io.github.apace100.apoli.action.type.bientity;

import io.github.apace100.apoli.action.ActionConfiguration;
import io.github.apace100.apoli.action.context.BiEntityActionContext;
import io.github.apace100.apoli.action.type.BiEntityActionType;
import io.github.apace100.apoli.action.type.BiEntityActionTypes;
import io.github.apace100.apoli.data.ApoliDataTypes;
import io.github.apace100.apoli.data.TypedDataObjectFactory;
import io.github.apace100.apoli.util.Space;
import io.github.apace100.apoli.util.requirement.BiEntityRequirement;
import io.github.apace100.calio.data.SerializableData;
import io.github.apace100.calio.data.SerializableDataType;
import io.github.apace100.calio.data.SerializableDataTypes;
import org.apache.commons.lang3.function.TriConsumer;
import org.jetbrains.annotations.NotNull;
import org.joml.Vector3f;

import java.util.function.BiFunction;
import net.minecraft.class_1297;
import net.minecraft.class_243;
import net.minecraft.class_3532;

public class AddVelocityBiEntityActionType extends BiEntityActionType {

    public static final TypedDataObjectFactory<AddVelocityBiEntityActionType> DATA_FACTORY = TypedDataObjectFactory.simple(
        new SerializableData()
            .add("x", SerializableDataTypes.FLOAT, 0F)
            .add("y", SerializableDataTypes.FLOAT, 0F)
            .add("z", SerializableDataTypes.FLOAT, 0F)
            .addFunctionedDefault("velocity", ApoliDataTypes.VECTOR_3_FLOAT, data -> new Vector3f(data.getFloat("x"), data.getFloat("y"), data.getFloat("z")))
            .add("reference", SerializableDataType.enumValue(Reference.class), Reference.POSITION)
            .add("set", SerializableDataTypes.BOOLEAN, false),
        data -> new AddVelocityBiEntityActionType(
            data.get("velocity"),
            data.get("reference"),
            data.get("set")
        ),
        (actionType, serializableData) -> serializableData.instance()
            .set("velocity", actionType.velocity)
            .set("reference", actionType.reference)
            .set("set", actionType.set)
    );

    private final Vector3f velocity;
    private final Reference reference;

    private final boolean set;

    public AddVelocityBiEntityActionType(Vector3f velocity, Reference reference, boolean set) {
        this.velocity = velocity;
        this.reference = reference;
        this.set = set;
    }

    @Override
    public void accept(BiEntityActionContext context) {

        class_1297 actor = context.actor();
        class_1297 target = context.target();

        Vector3f velocityCopy = new Vector3f(velocity);
        TriConsumer<Float, Float, Float> method = set
            ? target::method_18800
            : target::method_5762;

        class_243 referenceVec = reference.apply(actor, target);
        Space.transformVectorToBase(referenceVec, velocityCopy, actor.method_36454(), true);  //  Vector normalized by method

        method.accept(velocityCopy.x(), velocityCopy.y(), velocityCopy.z());
        target.field_6037 = true;

    }

    @Override
    public @NotNull ActionConfiguration<?> getConfig() {
        return BiEntityActionTypes.ADD_VELOCITY;
    }

    @Override
    public BiEntityRequirement getRequirement() {
        return BiEntityRequirement.BOTH;
    }

    public enum Reference implements BiFunction<class_1297, class_1297, class_243> {

        POSITION {

            @Override
            public class_243 apply(class_1297 actor, class_1297 target) {
                return target.method_19538().method_1020(actor.method_19538());
            }

        },

        ROTATION {

            @Override
            public class_243 apply(class_1297 actor, class_1297 target) {

                float pitch = actor.method_36455();
                float yaw = actor.method_36454();

                float i = 0.017453292F;

                float j = -class_3532.method_15374(yaw * i) * class_3532.method_15362(pitch * i);
                float k = -class_3532.method_15374(pitch * i);
                float l =  class_3532.method_15362(yaw * i) * class_3532.method_15362(pitch * i);

                return new class_243(j, k, l);

            }

        }

    }

}
