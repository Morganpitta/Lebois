package io.github.apace100.apoli.action.type.block;

import com.google.gson.JsonElement;
import com.mojang.serialization.JsonOps;
import io.github.apace100.apoli.Apoli;
import io.github.apace100.apoli.action.ActionConfiguration;
import io.github.apace100.apoli.action.BlockAction;
import io.github.apace100.apoli.action.context.BlockActionContext;
import io.github.apace100.apoli.action.type.BlockActionType;
import io.github.apace100.apoli.action.type.BlockActionTypes;
import io.github.apace100.apoli.data.ApoliDataTypes;
import io.github.apace100.apoli.data.TypedDataObjectFactory;
import io.github.apace100.apoli.util.ResourceOperation;
import io.github.apace100.calio.data.SerializableData;
import io.github.apace100.calio.data.SerializableDataTypes;
import org.jetbrains.annotations.NotNull;

import java.util.Optional;
import java.util.stream.Collectors;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_2754;
import net.minecraft.class_3542;
import net.minecraft.class_6903;

public class ModifyBlockStateBlockActionType extends BlockActionType {

    public static final TypedDataObjectFactory<ModifyBlockStateBlockActionType> DATA_FACTORY = TypedDataObjectFactory.simple(
        new SerializableData()
            .add("property", SerializableDataTypes.STRING)
            .add("operation", ApoliDataTypes.RESOURCE_OPERATION, ResourceOperation.ADD)
            .add("change", SerializableDataTypes.INT.optional(), Optional.empty())
            .add("value", SerializableDataTypes.BOOLEAN.optional(), Optional.empty())
            .add("enum", SerializableDataTypes.STRING.optional(), Optional.empty())
            .add("cycle", SerializableDataTypes.BOOLEAN, false),
        data -> new ModifyBlockStateBlockActionType(
            data.get("property"),
            data.get("operation"),
            data.get("change"),
            data.get("value"),
            data.get("enum"),
            data.get("cycle")
        ),
        (actionType, serializableData) -> serializableData.instance()
            .set("property", actionType.property)
            .set("operation", actionType.operation)
            .set("change", actionType.change)
            .set("value", actionType.boolValue)
            .set("enum", actionType.enumValue)
            .set("cycle", actionType.cycle)
    );

    private final String property;

    private final ResourceOperation operation;
    private final Optional<Integer> change;

    private final Optional<Boolean> boolValue;
    private final Optional<String> enumValue;

    private final boolean cycle;

    public ModifyBlockStateBlockActionType(String property, ResourceOperation operation, Optional<Integer> change, Optional<Boolean> boolValue, Optional<String> enumValue, boolean cycle) {
        this.property = property;
        this.operation = operation;
        this.change = change;
        this.boolValue = boolValue;
        this.enumValue = enumValue;
        this.cycle = cycle;
    }

    @Override
    public void accept(BlockActionContext context) {

        World world = context.world();
        BlockPos pos = context.pos();

        BlockState blockState = world.getBlockState(pos);
        Property<?> blockProperty = blockState.getProperties()
            .stream()
            .filter(prop -> prop.getName().equals(property))
            .findFirst()
            .orElse(null);

        if (blockProperty == null) {
            return;
        }

        if (cycle) {
            world.setBlockState(pos, blockState.cycle(blockProperty));
            return;
        }

        switch (blockProperty) {
            case EnumProperty<?> enumProp when enumValue.isPresent() && !enumValue.get().isEmpty() ->
                setEnumProperty(enumProp, enumValue.get(), world, pos, blockState);
            case BooleanProperty boolProp when boolValue.isPresent() ->
                world.setBlockState(pos, blockState.with(boolProp, boolValue.get()));
            case IntProperty intProp when change.isPresent() -> {

                int newValue = switch (operation) {
                    case ADD ->
                        Optional.ofNullable(blockState.get(intProp)).orElse(0) + change.get();
                    case SET ->
                        change.get();
                };

                if (intProp.getValues().contains(newValue)) {
                    world.setBlockState(pos, blockState.with(intProp, newValue));
                }

            }
            default -> {

            }
        }

    }

    @Override
    public @NotNull ActionConfiguration<?> getConfig() {
        return BlockActionTypes.MODIFY_BLOCK_STATE;
    }

    private <T extends Enum<T> & class_3542> void setEnumProperty(class_2754<T> property, String name, class_1937 world, class_2338 pos, class_2680 originalState) {
        property.method_11900(name).ifPresentOrElse(
            propValue ->
                world.method_8501(pos, originalState.method_11657(property, propValue)),
            () -> {

                class_6903<JsonElement> jsonOps = world.method_30349().method_57093(JsonOps.INSTANCE);
                Optional<JsonElement> blockActionJson = BlockAction.DATA_TYPE.write(jsonOps, this.getAction()).result();

                Apoli.LOGGER.warn("Couldn't set enum property \"{}\" of block at {} to \"{}\" (with block action {})! Expected value to be any of {}", property.method_11899(), pos.method_23854(), name, blockActionJson.map(JsonElement::toString).orElse("<unknown>"), property.method_11898().stream().map(class_3542::method_15434).collect(Collectors.joining(", ")));

            }
        );
    }

}
