package io.github.apace100.apoli.action.type.entity;

import io.github.apace100.apoli.action.ActionConfiguration;
import io.github.apace100.apoli.action.context.EntityActionContext;
import io.github.apace100.apoli.action.type.EntityActionType;
import io.github.apace100.apoli.action.type.EntityActionTypes;
import io.github.apace100.apoli.data.TypedDataObjectFactory;
import io.github.apace100.apoli.util.MiscUtil;
import io.github.apace100.calio.data.SerializableData;
import io.github.apace100.calio.data.SerializableDataTypes;
import org.jetbrains.annotations.NotNull;

import java.util.List;
import net.minecraft.class_1291;
import net.minecraft.class_1309;
import net.minecraft.class_6880;

public class ClearEffectEntityActionType extends EntityActionType {

    public static final TypedDataObjectFactory<ClearEffectEntityActionType> DATA_FACTORY = TypedDataObjectFactory.simple(
        new SerializableData()
            .add("effect", SerializableDataTypes.STATUS_EFFECT_ENTRY, null)
            .addFunctionedDefault("effects", SerializableDataTypes.STATUS_EFFECT_ENTRIES, data -> MiscUtil.singletonListOrEmpty(data.get("effect"))),
        data -> new ClearEffectEntityActionType(
            data.get("effects")
        ),
        (actionType, serializableData) -> serializableData.instance()
            .set("effects", actionType.effects)
    );

    private final List<class_6880<class_1291>> effects;

    public ClearEffectEntityActionType(List<class_6880<class_1291>> effects) {
        this.effects = effects;
    }

    @Override
    public void accept(EntityActionContext context) {

        if (context.entity() instanceof class_1309 livingEntity) {

            if (effects.isEmpty()) {
                livingEntity.method_6012();
            }

            else {
                effects.forEach(livingEntity::method_6016);
            }

        }

    }

    @Override
    public @NotNull ActionConfiguration<?> getConfig() {
        return EntityActionTypes.CLEAR_EFFECT;
    }

}
