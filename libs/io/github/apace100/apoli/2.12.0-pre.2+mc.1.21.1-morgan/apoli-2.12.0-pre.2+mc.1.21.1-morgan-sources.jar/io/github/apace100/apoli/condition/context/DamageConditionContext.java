package io.github.apace100.apoli.condition.context;

import io.github.apace100.apoli.util.context.ConditionContext;
import net.minecraft.class_1282;

public record DamageConditionContext(class_1282 source, float amount) implements ConditionContext {

}
