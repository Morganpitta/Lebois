package io.github.apace100.apoli.mixin;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import io.github.apace100.apoli.component.PowerHolderComponent;
import io.github.apace100.apoli.power.type.ModifyBreakSpeedPowerType;
import io.github.apace100.apoli.util.modifier.Modifier;
import io.github.apace100.apoli.util.modifier.ModifierUtil;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

import java.util.List;
import net.minecraft.class_1657;
import net.minecraft.class_1922;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_4970;

@Mixin(class_4970.class)
public abstract class AbstractBlockMixin {

    @ModifyExpressionValue(method = "calcBlockBreakingDelta", at = @At(value = "INVOKE", target = "Lnet/minecraft/block/BlockState;getHardness(Lnet/minecraft/world/BlockView;Lnet/minecraft/util/math/BlockPos;)F"))
    private float apoli$modifyBlockHardness(float original, class_2680 state, class_1657 player, class_1922 world, class_2338 pos) {

        List<Modifier> hardnessModifiers = PowerHolderComponent.getPowerTypes(player, ModifyBreakSpeedPowerType.class)
            .stream()
            .filter(p -> p.doesApply(pos))
            .flatMap(p -> p.getHardnessModifiers().stream())
            .toList();

        return (float) Math.max(ModifierUtil.applyModifiers(player, hardnessModifiers, original), -1.0F);

    }

    @ModifyReturnValue(method = "calcBlockBreakingDelta", at = @At("RETURN"))
    private float apoli$modifyBlockBreakSpeed(float original, class_2680 state, class_1657 player, class_1922 world, class_2338 pos) {
        return PowerHolderComponent.modify(player, ModifyBreakSpeedPowerType.class, original, mbsp -> mbsp.doesApply(pos));
    }

}
