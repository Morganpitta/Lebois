package io.github.apace100.apoli.action.type.entity;

import io.github.apace100.apoli.action.ActionConfiguration;
import io.github.apace100.apoli.action.context.EntityActionContext;
import io.github.apace100.apoli.action.type.EntityActionType;
import io.github.apace100.apoli.action.type.EntityActionTypes;
import io.github.apace100.apoli.condition.BlockCondition;
import io.github.apace100.apoli.condition.context.BlockConditionContext;
import io.github.apace100.apoli.data.TypedDataObjectFactory;
import io.github.apace100.apoli.util.MiscUtil;
import io.github.apace100.calio.data.SerializableData;
import io.github.apace100.calio.data.SerializableDataTypes;
import org.jetbrains.annotations.NotNull;

import java.util.function.Predicate;
import net.minecraft.class_1297;
import net.minecraft.class_1927;
import net.minecraft.class_1937;

public class ExplodeEntityActionType extends EntityActionType {

    public static final TypedDataObjectFactory<ExplodeEntityActionType> DATA_FACTORY = TypedDataObjectFactory.simple(
        new SerializableData()
            .add("destructible", BlockCondition.DATA_TYPE, null)
            .add("indestructible", BlockCondition.DATA_TYPE, null)
            .add("destruction_type", SerializableDataTypes.DESTRUCTION_TYPE, class_1927.class_4179.field_18687)
            .add("damage_self", SerializableDataTypes.BOOLEAN, true)
            .add("create_fire", SerializableDataTypes.BOOLEAN, false)
            .add("power", SerializableDataTypes.NON_NEGATIVE_FLOAT)
            .add("indestructible_resistance", SerializableDataTypes.NON_NEGATIVE_FLOAT, 10.0F),
        data -> new ExplodeEntityActionType(
            data.get("destructible"),
            data.get("indestructible"),
            data.get("destruction_type"),
            data.get("damage_self"),
            data.get("create_fire"),
            data.get("power"),
            data.get("indestructible_resistance")
        ),
        (actionType, serializableData) -> serializableData.instance()
            .set("destructible", actionType.destructibleCondition)
            .set("indestructible", actionType.indestructibleCondition)
            .set("destruction_type", actionType.destructionType)
            .set("damage_self", actionType.damageSelf)
            .set("create_fire", actionType.createFire)
            .set("power", actionType.power)
            .set("indestructible_resistance", actionType.indestructibleResistance)
    );

    private final BlockCondition destructibleCondition;
    private final BlockCondition indestructibleCondition;

    private final class_1927.class_4179 destructionType;

    private final boolean damageSelf;
    private final boolean createFire;

    private final float power;
    private final float indestructibleResistance;

    public ExplodeEntityActionType(BlockCondition destructibleCondition, BlockCondition indestructibleCondition, class_1927.class_4179 destructionType, boolean damageSelf, boolean createFire, float power, float indestructibleResistance) {
        this.destructibleCondition = destructibleCondition;
        this.indestructibleCondition = indestructibleCondition;
        this.destructionType = destructionType;
        this.damageSelf = damageSelf;
        this.createFire = createFire;
        this.power = power;
        this.indestructibleResistance = indestructibleResistance;
    }

    @Override
    public void accept(EntityActionContext context) {

        class_1297 entity = context.entity();
        class_1937 world = entity.method_37908();

        if (world.method_8608()) {
            return;
        }

        Predicate<BlockConditionContext> behaviorCondition = indestructibleCondition;
        if (destructibleCondition != null) {
            behaviorCondition = MiscUtil.combineOr(destructibleCondition.negate(), behaviorCondition);
        }

        MiscUtil.createExplosion(
            entity.method_37908(),
            damageSelf ? null : entity,
            class_1927.method_55108(entity.method_37908(), entity),
            entity.method_19538().method_10216(),
            entity.method_19538().method_10214(),
            entity.method_19538().method_10215(),
            power,
            createFire,
            destructionType,
            MiscUtil.createExplosionBehavior(behaviorCondition, indestructibleResistance)
        );

    }

    @Override
    public @NotNull ActionConfiguration<?> getConfig() {
        return EntityActionTypes.EXPLODE;
    }

}
