package io.github.apace100.apoli.condition.type.entity;

import io.github.apace100.apoli.condition.ConditionConfiguration;
import io.github.apace100.apoli.condition.context.EntityConditionContext;
import io.github.apace100.apoli.condition.type.EntityConditionType;
import io.github.apace100.apoli.condition.type.EntityConditionTypes;
import io.github.apace100.apoli.data.TypedDataObjectFactory;
import io.github.apace100.calio.data.SerializableData;
import io.github.apace100.calio.data.SerializableDataTypes;
import net.minecraft.class_1299;
import org.jetbrains.annotations.NotNull;

public class EntityTypeEntityConditionType extends EntityConditionType {

    public static final TypedDataObjectFactory<EntityTypeEntityConditionType> DATA_FACTORY = TypedDataObjectFactory.simple(
        new SerializableData()
            .add("entity_type", SerializableDataTypes.ENTITY_TYPE),
        data -> new EntityTypeEntityConditionType(
            data.get("entity_type")
        ),
        (conditionType, serializableData) -> serializableData.instance()
            .set("entity_type", conditionType.entityType)
    );

    private final class_1299<?> entityType;

    public EntityTypeEntityConditionType(class_1299<?> entityType) {
        this.entityType = entityType;
    }

    @Override
    public boolean test(EntityConditionContext context) {
        return context.entity().method_5864().equals(entityType);
    }

    @Override
    public @NotNull ConditionConfiguration<?> getConfig() {
        return EntityConditionTypes.ENTITY_TYPE;
    }

}
