package io.github.apace100.apoli.condition.context;

import io.github.apace100.apoli.util.context.ConditionContext;
import net.minecraft.class_1799;
import net.minecraft.class_1937;

public record ItemConditionContext(class_1937 world, class_1799 stack) implements ConditionContext {

}
