package io.github.apace100.apoli.mixin;

import com.google.common.collect.AbstractIterator;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import io.github.apace100.apoli.access.BlockCollisionSpliteratorAccess;
import io.github.apace100.apoli.access.BlockStateCollisionShapeAccess;
import net.minecraft.class_1922;
import net.minecraft.class_2338;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_3726;
import net.minecraft.class_5329;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_5329.class)
public abstract class BlockCollisionSpliteratorMixin<T> extends AbstractIterator<T> implements BlockCollisionSpliteratorAccess {

    @Unique
    boolean apoli$getOriginalShapes;

    @Override
    public boolean apoli$shouldGetOriginalShapes() {
        return apoli$getOriginalShapes;
    }

    @Override
    public void apoli$setGetOriginalShapes(boolean getOriginalShapes) {
        this.apoli$getOriginalShapes = getOriginalShapes;
    }

    @WrapOperation(method = "computeNext", at = @At(value = "INVOKE", target = "Lnet/minecraft/block/BlockState;getCollisionShape(Lnet/minecraft/world/BlockView;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/block/ShapeContext;)Lnet/minecraft/util/shape/VoxelShape;"))
    private class_265 apoli$overrideCollisionShapeQuery(class_2680 state, class_1922 world, class_2338 pos, class_3726 context, Operation<class_265> original) {
        return state instanceof BlockStateCollisionShapeAccess shapeAccess && this.apoli$shouldGetOriginalShapes()
            ? shapeAccess.apoli$getOriginalCollisionShape(world, pos, context)
            : original.call(state, world, pos, context);
    }

}
