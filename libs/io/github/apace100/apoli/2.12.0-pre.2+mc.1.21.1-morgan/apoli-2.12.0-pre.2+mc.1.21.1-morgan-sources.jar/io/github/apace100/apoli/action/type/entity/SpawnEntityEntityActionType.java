package io.github.apace100.apoli.action.type.entity;

import io.github.apace100.apoli.action.ActionConfiguration;
import io.github.apace100.apoli.action.BiEntityAction;
import io.github.apace100.apoli.action.EntityAction;
import io.github.apace100.apoli.action.context.EntityActionContext;
import io.github.apace100.apoli.action.type.EntityActionType;
import io.github.apace100.apoli.action.type.EntityActionTypes;
import io.github.apace100.apoli.data.TypedDataObjectFactory;
import io.github.apace100.apoli.util.MiscUtil;
import io.github.apace100.calio.data.SerializableData;
import io.github.apace100.calio.data.SerializableDataTypes;
import org.jetbrains.annotations.NotNull;

import java.util.Optional;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_2487;
import net.minecraft.class_3218;

public class SpawnEntityEntityActionType extends EntityActionType {

    public static final TypedDataObjectFactory<SpawnEntityEntityActionType> DATA_FACTORY = TypedDataObjectFactory.simple(
        new SerializableData()
            .add("entity_type", SerializableDataTypes.ENTITY_TYPE)
            .add("entity_action", EntityAction.DATA_TYPE.optional(), Optional.empty())
            .add("bientity_action", BiEntityAction.DATA_TYPE.optional(), Optional.empty())
            .add("tag", SerializableDataTypes.NBT_COMPOUND, new class_2487()),
        data -> new SpawnEntityEntityActionType(
            data.get("entity_type"),
            data.get("entity_action"),
            data.get("bientity_action"),
            data.get("tag")
        ),
        (actionType, serializableData) -> serializableData.instance()
            .set("entity_type", actionType.entityType)
            .set("entity_action", actionType.entityAction)
            .set("bientity_action", actionType.biEntityAction)
            .set("tag", actionType.tag)
    );

    private final class_1299<?> entityType;

    private final Optional<EntityAction> entityAction;
    private final Optional<BiEntityAction> biEntityAction;

    private final class_2487 tag;

    public SpawnEntityEntityActionType(class_1299<?> entityType, Optional<EntityAction> entityAction, Optional<BiEntityAction> biEntityAction, class_2487 tag) {
        this.entityType = entityType;
        this.entityAction = entityAction;
        this.biEntityAction = biEntityAction;
        this.tag = tag;
    }

    @Override
    public void accept(EntityActionContext context) {

        class_1297 entity = context.entity();

        if (!(entity.method_37908() instanceof class_3218 serverWorld)) {
            return;
        }

        Optional<class_1297> entityToSpawn = MiscUtil.getEntityWithPassengers(
            serverWorld,
            entityType,
            tag,
            entity.method_19538(),
            entity.method_36454(),
            entity.method_36455()
        );

        if (entityToSpawn.isEmpty()) {
            return;
        }

        class_1297 actualEntityToSpawn = entityToSpawn.get();
        serverWorld.method_30736(actualEntityToSpawn);

        entityAction.ifPresent(action -> action.execute(actualEntityToSpawn));
        biEntityAction.ifPresent(action -> action.execute(entity, actualEntityToSpawn));

    }

    @Override
    public @NotNull ActionConfiguration<?> getConfig() {
        return EntityActionTypes.SPAWN_ENTITY;
    }

}
