package io.github.apace100.apoli.access;

import net.minecraft.class_52;
import net.minecraft.class_5321;
import net.minecraft.class_9383;

public interface KeyableLootTable {

    class_5321<class_52> apoli$getKey();

    void apoli$setup(class_5321<class_52> lootTableKey, class_9383.class_9385 lookup);

}
