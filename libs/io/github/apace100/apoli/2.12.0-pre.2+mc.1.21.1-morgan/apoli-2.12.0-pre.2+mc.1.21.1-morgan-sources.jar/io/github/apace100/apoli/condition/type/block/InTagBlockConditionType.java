package io.github.apace100.apoli.condition.type.block;

import io.github.apace100.apoli.condition.ConditionConfiguration;
import io.github.apace100.apoli.condition.context.BlockConditionContext;
import io.github.apace100.apoli.condition.type.BlockConditionType;
import io.github.apace100.apoli.condition.type.BlockConditionTypes;
import io.github.apace100.apoli.data.TypedDataObjectFactory;
import io.github.apace100.calio.data.SerializableData;
import io.github.apace100.calio.data.SerializableDataTypes;
import net.minecraft.class_2248;
import net.minecraft.class_6862;
import org.jetbrains.annotations.NotNull;

public class InTagBlockConditionType extends BlockConditionType {

    public static final TypedDataObjectFactory<InTagBlockConditionType> DATA_FACTORY = TypedDataObjectFactory.simple(
        new SerializableData()
            .add("tag", SerializableDataTypes.BLOCK_TAG),
        data -> new InTagBlockConditionType(
            data.get("tag")
        ),
        (conditionType, serializableData) -> serializableData.instance()
            .set("tag", conditionType.tag)
    );

    private final class_6862<class_2248> tag;

    public InTagBlockConditionType(class_6862<class_2248> tag) {
        this.tag = tag;
    }

    @Override
    public boolean test(BlockConditionContext context) {
        return context.blockState().method_26164(tag);
    }

    @Override
    public @NotNull ConditionConfiguration<?> getConfig() {
        return BlockConditionTypes.IN_TAG;
    }

}
