package io.github.apace100.apoli.condition.type.biome;

import io.github.apace100.apoli.condition.ConditionConfiguration;
import io.github.apace100.apoli.condition.context.BiomeConditionContext;
import io.github.apace100.apoli.condition.type.BiomeConditionType;
import io.github.apace100.apoli.condition.type.BiomeConditionTypes;
import org.jetbrains.annotations.NotNull;

public class HighHumidityBiomeConditionType extends BiomeConditionType {

	@Override
	public boolean test(BiomeConditionContext context) {
		return context.biomeEntry().comp_349().field_26393.comp_846() > 0.85F;
	}

	@Override
	public @NotNull ConditionConfiguration<?> getConfig() {
		return BiomeConditionTypes.HIGH_HUMIDITY;
	}

}
