package io.github.apace100.apoli.action.type.bientity.meta;

import io.github.apace100.apoli.action.ActionConfiguration;
import io.github.apace100.apoli.action.BiEntityAction;
import io.github.apace100.apoli.action.context.BiEntityActionContext;
import io.github.apace100.apoli.action.type.BiEntityActionType;
import io.github.apace100.apoli.action.type.BiEntityActionTypes;
import io.github.apace100.apoli.action.type.meta.ChoiceMetaActionType;
import net.minecraft.class_6032;
import org.jetbrains.annotations.NotNull;

public class ChoiceBiEntityActionType extends BiEntityActionType implements ChoiceMetaActionType<BiEntityActionContext, BiEntityAction> {

	private final class_6032<BiEntityAction> actions;

	public ChoiceBiEntityActionType(class_6032<BiEntityAction> actions) {
		this.actions = actions;
	}

	@Override
	public void accept(BiEntityActionContext context) {
		this.executeActions(context);
	}

	@Override
	public @NotNull ActionConfiguration<?> getConfig() {
		return BiEntityActionTypes.CHOICE;
	}

	@Override
	public class_6032<BiEntityAction> actions() {
		return actions;
	}

}
