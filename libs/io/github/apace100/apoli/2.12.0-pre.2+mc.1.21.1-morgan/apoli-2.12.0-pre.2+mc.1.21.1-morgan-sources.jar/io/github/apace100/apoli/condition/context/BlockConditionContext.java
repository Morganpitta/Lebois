package io.github.apace100.apoli.condition.context;

import io.github.apace100.apoli.util.SavedBlockPosition;
import io.github.apace100.apoli.util.context.ConditionContext;
import org.jetbrains.annotations.Nullable;

import java.util.Optional;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2680;

public record BlockConditionContext(SavedBlockPosition savedBlockPosition) implements ConditionContext {

	public BlockConditionContext(class_1937 world, class_2338 pos, class_2680 blockState, Optional<class_2586> blockEntity) {
		this(world, pos, blockState, blockEntity.orElse(null));
	}

	public BlockConditionContext(class_1937 world, class_2338 pos, class_2680 blockState, @Nullable class_2586 blockEntity) {
		this(new SavedBlockPosition(world, pos, blockState, blockEntity));
	}

	public BlockConditionContext(class_1937 world, class_2338 pos) {
		this(world, pos, world.method_8320(pos), world.method_8321(pos));
	}

	public class_1937 world() {
		return (class_1937) savedBlockPosition().method_11679();
	}

	public class_2338 pos() {
		return savedBlockPosition().method_11683();
	}

	public class_2680 blockState() {
		return savedBlockPosition().method_11681();
	}

	public Optional<class_2586> blockEntity() {
		return Optional.ofNullable(savedBlockPosition().method_11680());
	}

}
