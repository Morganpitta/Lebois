package io.github.apace100.apoli.loot.function;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.apace100.apoli.component.item.ApoliDataComponentTypes;
import io.github.apace100.apoli.component.item.ItemPowersComponent;
import io.github.apace100.apoli.data.ApoliDataTypes;
import io.github.apace100.apoli.power.PowerReference;
import io.github.apace100.calio.data.SerializableDataTypes;
import java.util.EnumSet;
import java.util.List;
import net.minecraft.class_120;
import net.minecraft.class_1799;
import net.minecraft.class_47;
import net.minecraft.class_5339;
import net.minecraft.class_5341;
import net.minecraft.class_9274;

public class AddPowerLootFunction extends class_120 {

    public static final MapCodec<AddPowerLootFunction> MAP_CODEC = RecordCodecBuilder.mapCodec(instance -> method_53344(instance).and(instance.group(
        SerializableDataTypes.ATTRIBUTE_MODIFIER_SLOT_SET.codec().optionalFieldOf("slot", EnumSet.of(class_9274.field_49216)).forGetter(AddPowerLootFunction::slots),
        ApoliDataTypes.POWER_REFERENCE.codec().fieldOf("power").forGetter(AddPowerLootFunction::power),
        Codec.BOOL.optionalFieldOf("hidden", false).forGetter(AddPowerLootFunction::hidden),
        Codec.BOOL.optionalFieldOf("negative", false).forGetter(AddPowerLootFunction::negative)
    )).apply(instance, AddPowerLootFunction::new));

    private final EnumSet<class_9274> slots;
    private final PowerReference power;

    private final boolean hidden;
    private final boolean negative;

    private AddPowerLootFunction(List<class_5341> conditions, EnumSet<class_9274> slots, PowerReference power, boolean hidden, boolean negative) {
        super(conditions);
        this.slots = slots;
        this.power = power;
        this.hidden = hidden;
        this.negative = negative;
    }

    @Override
    public class_5339<? extends class_120> method_29321() {
        return ApoliLootFunctionTypes.ADD_POWER;
    }

    @Override
    public class_1799 method_522(class_1799 stack, class_47 context) {

        power().getOptionalPower().ifPresent(power -> {

            ItemPowersComponent itemPowers = stack.method_57825(ApoliDataComponentTypes.POWERS, ItemPowersComponent.DEFAULT);
            stack.method_57379(ApoliDataComponentTypes.POWERS, ItemPowersComponent.builder(itemPowers)
                .add(slots(), power.getId(), hidden(), negative())
                .build());

        });

        return stack;

    }

    public EnumSet<class_9274> slots() {
        return slots;
    }

    public PowerReference power() {
        return power;
    }

    public boolean hidden() {
        return hidden;
    }

    public boolean negative() {
        return negative;
    }

}
