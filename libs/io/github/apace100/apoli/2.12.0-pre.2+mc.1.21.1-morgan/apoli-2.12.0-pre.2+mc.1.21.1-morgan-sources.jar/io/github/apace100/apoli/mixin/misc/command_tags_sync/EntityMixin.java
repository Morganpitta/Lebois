package io.github.apace100.apoli.mixin.misc.command_tags_sync;

import io.github.apace100.apoli.networking.packet.s2c.SyncCommandTagsS2CPacket;
import io.github.apace100.apoli.util.MiscUtil;
import net.minecraft.class_1297;
import net.minecraft.class_1937;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1297.class)
public abstract class EntityMixin {

	@Shadow
	public abstract class_1937 getWorld();

	@Unique
	private boolean apoli$syncCommandTags = false;

	@Inject(method = "addCommandTag", at = @At("RETURN"))
	private void apoli$onCommandTagAdded(String tag, CallbackInfoReturnable<Boolean> cir) {
		this.apoli$syncCommandTags |= cir.getReturnValueZ();
	}

	@Inject(method = "removeCommandTag", at = @At("RETURN"))
	private void apoli$onCommandTagRemoved(String tag, CallbackInfoReturnable<Boolean> cir) {
		this.apoli$syncCommandTags |= cir.getReturnValueZ();
	}

	@Inject(method = "baseTick", at = @At("TAIL"))
	private void apoli$syncCommandTagsWhenDirty(CallbackInfo ci) {

		if (!this.getWorld().method_8608() && apoli$syncCommandTags) {
			MiscUtil.sendToTrackers(thisAsEntity(), new SyncCommandTagsS2CPacket(thisAsEntity()));
		}

		this.apoli$syncCommandTags = false;

	}

	@Unique
	private class_1297 thisAsEntity() {
		return (class_1297) (Object) this;
	}

}
