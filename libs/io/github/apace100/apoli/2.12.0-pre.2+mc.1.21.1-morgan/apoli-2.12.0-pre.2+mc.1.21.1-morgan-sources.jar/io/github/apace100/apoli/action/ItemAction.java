package io.github.apace100.apoli.action;

import io.github.apace100.apoli.action.context.ItemActionContext;
import io.github.apace100.apoli.action.type.ItemActionType;
import io.github.apace100.apoli.action.type.ItemActionTypes;
import io.github.apace100.apoli.action.type.item.meta.SequenceItemActionType;
import io.github.apace100.apoli.data.ApoliDataTypes;
import io.github.apace100.apoli.util.WorkableEmptyStack;
import io.github.apace100.calio.data.SerializableDataType;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_3218;
import net.minecraft.class_5630;

public final class ItemAction extends Action<ItemActionContext, ItemActionType> {

	public static final SerializableDataType<ItemAction> DATA_TYPE = SerializableDataType.lazy(() -> ApoliDataTypes.actions("type", ItemActionTypes.DATA_TYPE, SequenceItemActionType::new, ItemAction::new));

	public ItemAction(ItemActionType actionType) {
		super(actionType);
	}

	public void execute(class_1937 world, class_5630 stackReference) {

		if (world instanceof class_3218 serverWorld) {
			accept(new ItemActionContext(serverWorld, stackReference));
		}

	}

	@Override
	public void accept(ItemActionContext context) {

		class_5630 stackReference = context.stackReference();

		//	Replace the stack of the stack reference with a "workable" empty stack if the said stack is an
		//	empty stack
		if (stackReference.method_32327() == class_1799.field_8037) {
			stackReference.method_32332(new class_1799((Void) null));
		}

		//	Execute the action type
		getType().accept(context);

		//	Restore the empty stack instance of the stack reference afterward
		if (!WorkableEmptyStack.isOf(stackReference) && stackReference.method_32327().method_7960()) {
			stackReference.method_32332(class_1799.field_8037);
		}

	}

}
