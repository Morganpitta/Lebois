package io.github.apace100.apoli.action.type.block;

import io.github.apace100.apoli.Apoli;
import io.github.apace100.apoli.action.ActionConfiguration;
import io.github.apace100.apoli.action.context.BlockActionContext;
import io.github.apace100.apoli.action.type.BlockActionType;
import io.github.apace100.apoli.action.type.BlockActionTypes;
import io.github.apace100.apoli.data.TypedDataObjectFactory;
import io.github.apace100.calio.data.SerializableData;
import io.github.apace100.calio.data.SerializableDataTypes;
import net.minecraft.class_2165;
import net.minecraft.class_2168;
import net.minecraft.class_2338;
import net.minecraft.class_241;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.server.MinecraftServer;
import org.jetbrains.annotations.NotNull;

public class ExecuteCommandBlockActionType extends BlockActionType {

    public static final TypedDataObjectFactory<ExecuteCommandBlockActionType> DATA_FACTORY = TypedDataObjectFactory.simple(
        new SerializableData()
            .add("command", SerializableDataTypes.STRING),
        data -> new ExecuteCommandBlockActionType(
            data.get("command")
        ),
        (actionType, serializableData) -> serializableData.instance()
            .set("command", actionType.command)
    );

    private final String command;

    public ExecuteCommandBlockActionType(String command) {
        this.command = command;
    }

    @Override
    public void accept(BlockActionContext context) {

        class_3218 world = context.world();
        class_2338 pos = context.pos();

        class_2680 blockState = world.method_8320(pos);
        String blockTranslationKey = blockState.method_26204().method_9539();

        MinecraftServer server = world.method_8503();
        class_2168 commandSource = new class_2168(
            Apoli.config.executeCommand.showOutput ? server : class_2165.field_17395,
            pos.method_46558(),
            class_241.field_1340,
            world,
            Apoli.config.executeCommand.permissionLevel,
            blockTranslationKey,
            class_2561.method_43471(blockTranslationKey),
            server,
            null
        );

        server.method_3734().method_44252(commandSource, command);

    }

    @Override
    public @NotNull ActionConfiguration<?> getConfig() {
        return BlockActionTypes.EXECUTE_COMMAND;
    }

}
