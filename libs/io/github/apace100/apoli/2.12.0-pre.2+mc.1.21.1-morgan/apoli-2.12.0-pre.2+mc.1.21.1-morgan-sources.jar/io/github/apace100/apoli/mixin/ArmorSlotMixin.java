package io.github.apace100.apoli.mixin;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import io.github.apace100.apoli.component.PowerHolderComponent;
import io.github.apace100.apoli.power.type.RestrictArmorPowerType;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_9692;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_9692.class)
public abstract class ArmorSlotMixin {

    @Shadow @Final private class_1309 entity;

    @Shadow @Final private class_1304 equipmentSlot;

    @ModifyReturnValue(method = "canInsert", at = @At("RETURN"))
    private boolean apoli$preventArmorInsertion(boolean original, class_1799 stack) {
        return original
            && !PowerHolderComponent.hasPowerType(this.entity, RestrictArmorPowerType.class, p -> p.doesRestrict(stack, this.equipmentSlot));
    }

}
