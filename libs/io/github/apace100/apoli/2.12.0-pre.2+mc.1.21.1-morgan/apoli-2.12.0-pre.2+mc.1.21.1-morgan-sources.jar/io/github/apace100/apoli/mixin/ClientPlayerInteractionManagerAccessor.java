package io.github.apace100.apoli.mixin;

import net.minecraft.class_1934;
import net.minecraft.class_2338;
import net.minecraft.class_636;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_636.class)
public interface ClientPlayerInteractionManagerAccessor {

    @Accessor
    class_2338 getCurrentBreakingPos();

    @Accessor
    boolean getBreakingBlock();

    @Accessor
    class_1934 getGameMode();
}
