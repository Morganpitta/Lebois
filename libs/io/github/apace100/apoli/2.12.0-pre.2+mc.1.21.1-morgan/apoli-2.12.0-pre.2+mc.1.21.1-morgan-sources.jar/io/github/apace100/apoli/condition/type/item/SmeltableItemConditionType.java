package io.github.apace100.apoli.condition.type.item;

import io.github.apace100.apoli.condition.ConditionConfiguration;
import io.github.apace100.apoli.condition.context.ItemConditionContext;
import io.github.apace100.apoli.condition.type.ItemConditionType;
import io.github.apace100.apoli.condition.type.ItemConditionTypes;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_3956;
import net.minecraft.class_9696;
import org.jetbrains.annotations.NotNull;

public class SmeltableItemConditionType extends ItemConditionType {

    @Override
    public boolean test(ItemConditionContext context) {

        class_1799 stack = context.stack();
        class_1937 world = context.world();

        return world.method_8433()
            .method_8132(class_3956.field_17546, new class_9696(stack), world)
            .isPresent();

    }

    @Override
    public @NotNull ConditionConfiguration<?> getConfig() {
        return ItemConditionTypes.SMELTABLE;
    }

}
