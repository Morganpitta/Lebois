package io.github.apace100.apoli.condition.type.fluid;

import io.github.apace100.apoli.condition.ConditionConfiguration;
import io.github.apace100.apoli.condition.context.FluidConditionContext;
import io.github.apace100.apoli.condition.type.FluidConditionType;
import io.github.apace100.apoli.condition.type.FluidConditionTypes;
import io.github.apace100.apoli.data.TypedDataObjectFactory;
import io.github.apace100.calio.data.SerializableData;
import io.github.apace100.calio.data.SerializableDataTypes;
import net.minecraft.class_3611;
import net.minecraft.class_6862;
import org.jetbrains.annotations.NotNull;

public class InTagFluidConditionType extends FluidConditionType {

    public static final TypedDataObjectFactory<InTagFluidConditionType> DATA_FACTORY = TypedDataObjectFactory.simple(
        new SerializableData()
            .add("tag", SerializableDataTypes.FLUID_TAG),
        data -> new InTagFluidConditionType(
            data.get("tag")
        ),
        (conditionType, serializableData) -> serializableData.instance()
            .set("tag", conditionType.tag)
    );

    private final class_6862<class_3611> tag;

    public InTagFluidConditionType(class_6862<class_3611> tag) {
        this.tag = tag;
    }

    @Override
    public boolean test(FluidConditionContext context) {
        return context.fluidState().method_15767(tag);
    }

    @Override
    public @NotNull ConditionConfiguration<?> getConfig() {
        return FluidConditionTypes.IN_TAG;
    }

}
