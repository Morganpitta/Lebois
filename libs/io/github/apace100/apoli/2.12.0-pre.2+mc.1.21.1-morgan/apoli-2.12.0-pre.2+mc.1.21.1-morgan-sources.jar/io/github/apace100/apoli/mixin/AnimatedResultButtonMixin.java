package io.github.apace100.apoli.mixin;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Share;
import com.llamalad7.mixinextras.sugar.ref.LocalRef;
import io.github.apace100.apoli.access.PowerCraftingObject;
import io.github.apace100.apoli.component.PowerHolderComponent;
import io.github.apace100.apoli.power.Power;
import io.github.apace100.apoli.power.PowerManager;
import io.github.apace100.apoli.recipe.ModifiedCraftingRecipe;
import io.github.apace100.apoli.recipe.PowerCraftingRecipe;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;

import java.util.List;
import net.minecraft.class_124;
import net.minecraft.class_1799;
import net.minecraft.class_1860;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3439;
import net.minecraft.class_3955;
import net.minecraft.class_514;
import net.minecraft.class_7225;
import net.minecraft.class_8786;

@Mixin(class_514.class)
public abstract class AnimatedResultButtonMixin {

    @Shadow
    public abstract class_8786<?> currentRecipe();

    @Shadow
    private class_3439 recipeBook;

    @WrapOperation(method = {"renderWidget", "getTooltip", "appendClickableNarrations"}, at = @At(value = "INVOKE", target = "Lnet/minecraft/recipe/RecipeEntry;value()Lnet/minecraft/recipe/Recipe;"))
    private class_1860<?> apoli$modifyEntryQuery(class_8786<?> entry, Operation<class_1860<?>> original, @Share("originalEntry") LocalRef<class_8786<?>> sharedOriginalEntry) {

        sharedOriginalEntry.set(entry);

        class_2960 id = entry.comp_1932();
        class_1860<?> recipe = entry.comp_1933();

        if (recipe instanceof class_3955 craftingRecipe && ModifiedCraftingRecipe.canModify(id, craftingRecipe, this.recipeBook)) {
            return new ModifiedCraftingRecipe(id, craftingRecipe);
        }

        else {
            return original.call(entry);
        }

    }

    @WrapOperation(method = {"renderWidget", "getTooltip", "appendClickableNarrations"}, at = @At(value = "INVOKE", target = "Lnet/minecraft/recipe/Recipe;getResult(Lnet/minecraft/registry/RegistryWrapper$WrapperLookup;)Lnet/minecraft/item/ItemStack;"))
    private class_1799 apoli$modifyResultQuery(class_1860<?> recipe, class_7225.class_7874 wrapperLookup, Operation<class_1799> original) {

        if (recipe instanceof ModifiedCraftingRecipe modifiedCraftingRecipe && this.recipeBook instanceof PowerCraftingObject pco) {
            return modifiedCraftingRecipe.getModifiedResult(wrapperLookup, pco.apoli$getPlayer()).getFirst();
        }

        else {
            return original.call(recipe, wrapperLookup);
        }

    }

    @ModifyReturnValue(method = "getTooltip", at = @At("RETURN"))
    private List<class_2561> apoli$appendRequiredRecipePowerTooltip(List<class_2561> original, @Share("originalEntry") LocalRef<class_8786<?>> sharedOriginalEntry) {

        class_8786<?> recipeEntry = sharedOriginalEntry.get() != null
            ? sharedOriginalEntry.get()
            : this.currentRecipe();

        if (recipeEntry.comp_1933() instanceof PowerCraftingRecipe pcr && this.recipeBook instanceof PowerCraftingObject pco) {

            Power power = PowerManager.getNullable(pcr.powerId());
            PowerHolderComponent component = PowerHolderComponent.getNullable(pco.apoli$getPlayer());

            if (power != null && component != null && !component.hasPower(power)) {
                original.add(class_2561.method_43473());
                original.add(class_2561.method_43469("tooltip.apoli.power_recipe.required_power", power.getName()).formatted(class_124.field_1061));
            }

        }

        return original;

    }

}
