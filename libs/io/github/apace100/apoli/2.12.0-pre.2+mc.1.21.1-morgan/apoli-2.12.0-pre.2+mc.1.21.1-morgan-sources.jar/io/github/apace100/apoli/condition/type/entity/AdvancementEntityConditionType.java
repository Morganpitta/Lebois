package io.github.apace100.apoli.condition.type.entity;

import io.github.apace100.apoli.Apoli;
import io.github.apace100.apoli.condition.ConditionConfiguration;
import io.github.apace100.apoli.condition.context.EntityConditionContext;
import io.github.apace100.apoli.condition.type.EntityConditionType;
import io.github.apace100.apoli.condition.type.EntityConditionTypes;
import io.github.apace100.apoli.data.TypedDataObjectFactory;
import io.github.apace100.apoli.mixin.ClientAdvancementManagerAccessor;
import io.github.apace100.calio.data.SerializableData;
import io.github.apace100.calio.data.SerializableDataTypes;
import net.minecraft.class_1657;
import net.minecraft.class_167;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_632;
import net.minecraft.class_746;
import net.minecraft.class_8779;
import net.minecraft.server.MinecraftServer;
import org.jetbrains.annotations.NotNull;

import java.util.Map;

public class AdvancementEntityConditionType extends EntityConditionType {

    public static final TypedDataObjectFactory<AdvancementEntityConditionType> DATA_FACTORY = TypedDataObjectFactory.simple(
        new SerializableData()
            .add("advancement", SerializableDataTypes.IDENTIFIER),
        data -> new AdvancementEntityConditionType(
            data.get("advancement")
        ),
        (conditionType, serializableData) -> serializableData.instance()
            .set("advancement", conditionType.advancement)
    );

    private final class_2960 advancement;

    public AdvancementEntityConditionType(class_2960 advancement) {
        this.advancement = advancement;
    }

    @Override
    public boolean test(EntityConditionContext context) {

        if (!(context.entity() instanceof class_1657 player)) {
            return false;
        }

        MinecraftServer server = player.method_5682();
        if (server != null) {

            class_8779 advancementEntry = server.method_3851().method_12896(advancement);
            if (advancementEntry == null) {
                //  TODO: Throw an exception and pass it to the factory instance to be caught instead -eggohito
                Apoli.LOGGER.warn("Advancement \"{}\" did not exist, but was referenced in an \"advancement\" entity condition!", advancement);
                return false;
            }

            else {
                return ((class_3222) player).method_14236()
                    .method_12882(advancementEntry)
                    .method_740();
            }

        }

        else if (player instanceof class_746 clientPlayer && clientPlayer.field_3944 != null) {

            class_632 advancementManager = clientPlayer.field_3944.method_2869();
            class_8779 advancement = advancementManager.method_53815(this.advancement);

            if (advancement == null) {
                //  We don't want to print an error here if the advancement does not exist,
                //  because on the client-side, the advancement could just not have been received from the server
                return false;
            }

            Map<class_8779, class_167> progresses = ((ClientAdvancementManagerAccessor) advancementManager).getAdvancementProgresses();
            class_167 progress = progresses.get(advancement);

            return progress != null
                && progress.method_740();

        }

        else {
            return false;
        }

    }

    @Override
    public @NotNull ConditionConfiguration<?> getConfig() {
        return EntityConditionTypes.ADVANCEMENT;
    }

}
