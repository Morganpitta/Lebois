package io.github.apace100.apoli.action.type.item;

import io.github.apace100.apoli.action.ActionConfiguration;
import io.github.apace100.apoli.action.context.ItemActionContext;
import io.github.apace100.apoli.action.type.ItemActionType;
import io.github.apace100.apoli.action.type.ItemActionTypes;
import io.github.apace100.apoli.data.TypedDataObjectFactory;
import io.github.apace100.calio.data.SerializableData;
import io.github.apace100.calio.data.SerializableDataTypes;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import org.jetbrains.annotations.NotNull;

import java.util.List;
import java.util.Optional;
import net.minecraft.class_1799;
import net.minecraft.class_1887;
import net.minecraft.class_2378;
import net.minecraft.class_3218;
import net.minecraft.class_5321;
import net.minecraft.class_5455;
import net.minecraft.class_5630;
import net.minecraft.class_6880;
import net.minecraft.class_7924;
import net.minecraft.class_9304;
import net.minecraft.class_9334;

public class RemoveEnchantmentItemActionType extends ItemActionType {

    public static final TypedDataObjectFactory<RemoveEnchantmentItemActionType> DATA_FACTORY = TypedDataObjectFactory.simple(
        new SerializableData()
            .add("enchantment", SerializableDataTypes.ENCHANTMENT.optional(), Optional.empty())
            .add("enchantments", SerializableDataTypes.ENCHANTMENT.list().optional(), Optional.empty())
            .add("levels", SerializableDataTypes.INT.optional(), Optional.empty())
            .add("reset_repair_cost", SerializableDataTypes.BOOLEAN, false),
        data -> new RemoveEnchantmentItemActionType(
			data.get("enchantment"),
            data.get("enchantments"),
			data.get("levels"),
			data.get("reset_repair_cost")
		),
        (actionType, serializableData) -> serializableData.instance()
            .set("enchantment", actionType.enchantmentKey)
            .set("enchantments", actionType.enchantmentKeys)
            .set("levels", actionType.levels)
            .set("reset_repair_cost", actionType.resetRepairCost)
    );

    private final Optional<class_5321<class_1887>> enchantmentKey;
    private final Optional<List<class_5321<class_1887>>> enchantmentKeys;

    private final List<class_5321<class_1887>> allEnchantmentKeys;

    private final Optional<Integer> levels;
    private final boolean resetRepairCost;

    public RemoveEnchantmentItemActionType(Optional<class_5321<class_1887>> enchantmentKey, Optional<List<class_5321<class_1887>>> enchantmentKeys, Optional<Integer> levels, boolean resetRepairCost) {

        this.enchantmentKey = enchantmentKey;
        this.enchantmentKeys = enchantmentKeys;

        this.allEnchantmentKeys = new ObjectArrayList<>();

        this.enchantmentKey.ifPresent(this.allEnchantmentKeys::add);
        this.enchantmentKeys.ifPresent(this.allEnchantmentKeys::addAll);

        this.levels = levels;
        this.resetRepairCost = resetRepairCost;

    }

    @Override
    public void accept(ItemActionContext context) {

        class_3218 world = context.world();
        class_5630 stackReference = context.stackReference();

        class_1799 stack = stackReference.method_32327();
        class_5455 dynamicRegistries = world.method_30349();

        if (!stack.method_7942()) {
            return;
        }

        class_9304 oldEnchantments = stack.method_58657();
        class_9304.class_9305 newEnchantments = new class_9304.class_9305(oldEnchantments);

        class_2378<class_1887> enchantmentRegistry = dynamicRegistries.method_30530(class_7924.field_41265);
        for (class_5321<class_1887> enchantmentKey : allEnchantmentKeys) {

            //  Since the registry keys are already validated, this should be fine.
            class_6880<class_1887> enchantment = enchantmentRegistry.method_40290(enchantmentKey);

            if (oldEnchantments.method_57534().contains(enchantment)) {
                newEnchantments.method_57547(enchantment, levels.map(lvl -> oldEnchantments.method_57536(enchantment) - lvl).orElse(0));
            }

        }

        for (class_6880<class_1887> oldEnchantment : oldEnchantments.method_57534()) {

            if (!allEnchantmentKeys.isEmpty()) {
                break;
            }

            else {
                newEnchantments.method_57547(oldEnchantment, levels.map(lvl -> oldEnchantments.method_57536(oldEnchantment) - lvl).orElse(0));
            }

        }

        stack.method_57379(class_9334.field_49633, newEnchantments.method_57549());
        if (resetRepairCost && !stack.method_7942()) {
            stack.method_57379(class_9334.field_49639, 0);
        }

    }

    @Override
    public @NotNull ActionConfiguration<?> getConfig() {
        return ItemActionTypes.REMOVE_ENCHANTMENT;
    }

}
