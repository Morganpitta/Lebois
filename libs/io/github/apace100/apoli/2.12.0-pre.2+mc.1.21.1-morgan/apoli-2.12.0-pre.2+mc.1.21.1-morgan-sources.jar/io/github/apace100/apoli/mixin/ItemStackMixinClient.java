package io.github.apace100.apoli.mixin;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Local;
import io.github.apace100.apoli.Apoli;
import io.github.apace100.apoli.ApoliClient;
import io.github.apace100.apoli.component.PowerHolderComponent;
import io.github.apace100.apoli.component.item.ApoliDataComponentTypes;
import io.github.apace100.apoli.component.item.ItemPowersComponent;
import io.github.apace100.apoli.power.type.PreventItemUsePowerType;
import io.github.apace100.apoli.power.type.TooltipPowerType;
import io.github.apace100.apoli.util.ApoliConfigClient;
import io.github.apace100.apoli.util.keybinding.KeyBindingUtil;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_124;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1839;
import net.minecraft.class_2561;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import net.minecraft.class_5244;
import net.minecraft.class_5250;
import net.minecraft.class_9274;
import net.minecraft.class_9322;
import net.minecraft.class_9323;
import net.minecraft.class_9331;
import net.minecraft.class_9334;
import org.apache.commons.lang3.mutable.MutableBoolean;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.*;
import java.util.function.Consumer;

@Environment(EnvType.CLIENT)
@Mixin(class_1799.class)
public abstract class ItemStackMixinClient implements class_9322 {

    @Shadow
    public abstract class_1839 getUseAction();

    @Shadow
    public abstract class_9323 method_57353();

    @Shadow
    public abstract class_1792 getItem();

    @Unique
    private EnumSet<class_9274> apoli$appendedSlots;

    @Unique
    private class_1792.class_9635 apoli$tooltipContext;

    @Unique
    private class_1836 apoli$tooltipType;

    @Unique
    private List<class_2561> apoli$tooltip;

    @Inject(method = "getTooltip", at = @At(value = "INVOKE", target = "Lnet/minecraft/text/MutableText;append(Lnet/minecraft/text/Text;)Lnet/minecraft/text/MutableText;"))
    private void apoli$cacheTooltipStuff(class_1792.class_9635 context, @Nullable class_1657 player, class_1836 type, CallbackInfoReturnable<List<class_2561>> cir, @Local List<class_2561> tooltip) {

		// Although this is a client-only mixin, this is still seen by the internal server.
        if (player == null || !player.method_37908().field_9236) {
            return;
        }

        this.apoli$appendedSlots = EnumSet.noneOf(class_9274.class);
        this.apoli$tooltipContext = context;
        this.apoli$tooltipType = type;
        this.apoli$tooltip = tooltip;

    }

    @Inject(method = "getTooltip", at = @At(value = "RETURN"))
    private void apoli$clearCachedTooltipStuff(CallbackInfoReturnable<?> cir) {
        this.apoli$appendedSlots = null;
        this.apoli$tooltipContext = null;
        this.apoli$tooltipType = null;
        this.apoli$tooltip = null;
    }

    @Inject(method = "getTooltip", at = @At(value = "INVOKE", target = "Lnet/minecraft/item/Item;appendTooltip(Lnet/minecraft/item/ItemStack;Lnet/minecraft/item/Item$TooltipContext;Ljava/util/List;Lnet/minecraft/item/tooltip/TooltipType;)V", shift = At.Shift.AFTER))
    private void apoli$appendUnusableTooltip(class_1792.class_9635 context, @Nullable class_1657 player, class_1836 type, CallbackInfoReturnable<List<class_2561>> cir) {

        if (!(Apoli.config instanceof ApoliConfigClient config) || !config.tooltips.showUsabilityHints) {
            return;
        }

        List<PreventItemUsePowerType> preventItemUsePowers = PowerHolderComponent.getPowerTypes(player, PreventItemUsePowerType.class)
            .stream()
            .filter(p -> p.doesPrevent((class_1799) (Object) this))
            .toList();

        if (preventItemUsePowers.isEmpty()) {
            return;
        }

        String translationKey = "tooltip.apoli.unusable." + this.getUseAction().toString().toLowerCase(Locale.ROOT) + (preventItemUsePowers.size() == 1 ? ".single" : ".multiple");

        class_124 baseTextFormat = class_124.field_1080;
        class_124 powerTextFormat = class_124.field_1061;

        class_2561 powerText;
        class_2561 baseText;

        if (preventItemUsePowers.size() == 1) {

            PreventItemUsePowerType preventItemUsePower = preventItemUsePowers.getFirst();

            powerText = preventItemUsePower.getPower().getName().formatted(powerTextFormat);
            baseText = class_2561.method_43469(translationKey, powerText).method_27692(baseTextFormat);

            apoli$tooltip.add(baseText);

        }

        else if (config.tooltips.compactUsabilityHints) {

            class_310 client = class_310.method_1551();
            class_304 keyBinding = ApoliClient.showPowersOnUsabilityHint;

            Integer keyCode = !keyBinding.method_1415()
                ? class_3675.method_15981(keyBinding.method_1428()).method_1444()
                : null;
            boolean isKeyPressed = keyCode != null
                && class_3675.method_15987(client.method_22683().method_4490(), keyCode);

            if (isKeyPressed) {
                this.apoli$appendExpandedTooltip(preventItemUsePowers, apoli$tooltip, translationKey, powerTextFormat, powerTextFormat);
            }

            else {

                powerText = class_2561.method_43469("tooltip.apoli.usability_hint.power_count", preventItemUsePowers.size()).method_27692(powerTextFormat);
                baseText = class_2561.method_43469(translationKey, powerText).method_27692(baseTextFormat);

                apoli$tooltip.add(baseText);
                apoli$tooltip.add(class_2561.method_43473());

                class_2561 keyBindingText = KeyBindingUtil.getLocalizedName(keyBinding.method_1431()).method_27694(style -> style
                    .method_10977(class_124.field_1054)
                    .method_10978(keyBinding.method_1415()));

                class_2561 guideText = class_2561.method_43469("tooltip.apoli.usability_hint.show_powers", keyBindingText).method_27692(baseTextFormat);
                apoli$tooltip.add(guideText);

            }

        }

        else {
            this.apoli$appendExpandedTooltip(preventItemUsePowers, apoli$tooltip, translationKey, powerTextFormat, baseTextFormat);
        }

    }

    @WrapOperation(method = "getTooltip", at = @At(value = "INVOKE", target = "Lnet/minecraft/item/ItemStack;appendTooltip(Lnet/minecraft/component/ComponentType;Lnet/minecraft/item/Item$TooltipContext;Ljava/util/function/Consumer;Lnet/minecraft/item/tooltip/TooltipType;)V"))
    private void apoli$appendPowerTooltips(class_1799 stack, class_9331<?> componentType, class_1792.class_9635 context, Consumer<class_2561> tooltipConsumer, class_1836 type, Operation<Void> original, class_1792.class_9635 mContext, @Nullable class_1657 player, @Local List<class_2561> tooltip) {

        original.call(stack, componentType, context, tooltipConsumer, type);

        if (componentType == class_9334.field_49632) {
            PowerHolderComponent.getPowerTypes(player, TooltipPowerType.class)
                .stream()
                .filter(p -> p.doesApply((class_1799) (Object) this))
                .sorted(Comparator.comparing(TooltipPowerType::getOrder))
                .forEach(p -> p.processTooltips(tooltipConsumer));
        }

    }

    @Inject(method = "appendAttributeModifiersTooltip", at = @At(value = "INVOKE", target = "Lnet/minecraft/item/ItemStack;applyAttributeModifier(Lnet/minecraft/component/type/AttributeModifierSlot;Ljava/util/function/BiConsumer;)V", shift = At.Shift.AFTER))
    private void apoli$appendItemPowersTooltips(Consumer<class_2561> tooltipConsumer, @Nullable class_1657 player, CallbackInfo ci, @Local class_9274 modifierSlot, @Local MutableBoolean shouldAppendSlotName) {

        ItemPowersComponent itemPowersComponent = this.method_57825(ApoliDataComponentTypes.POWERS, ItemPowersComponent.DEFAULT);
        if (apoli$appendedSlots == null || apoli$appendedSlots.contains(modifierSlot) || !itemPowersComponent.containsSlot(modifierSlot)) {
            return;
        }

        if (shouldAppendSlotName.isTrue()) {

            tooltipConsumer.accept(class_5244.field_39003);
            tooltipConsumer.accept(class_2561.method_43471("item.modifiers." + modifierSlot.method_15434()).method_27692(class_124.field_1080));

            shouldAppendSlotName.setFalse();

        }

        itemPowersComponent.appendTooltip(modifierSlot, apoli$tooltipContext, apoli$tooltip::add, apoli$tooltipType);
        apoli$appendedSlots.add(modifierSlot);

    }

    @Unique
    private void apoli$appendExpandedTooltip(List<PreventItemUsePowerType> powers, List<class_2561> tooltip, String translationKey, class_124 powerTextColor, class_124 baseTextColor) {

        List<class_2561> powerTexts = new LinkedList<>();
        for (PreventItemUsePowerType power : powers) {

            class_5250 prependedText = class_2561.method_43470("  - ").method_27692(baseTextColor);
            class_5250 powerText = power.getPower().getName().formatted(powerTextColor);

            powerTexts.add(prependedText.method_10852(powerText));

        }

        class_2561 powerText = class_2561.method_43469("tooltip.apoli.usability_hint.power_count", powers.size()).method_27692(powerTextColor);
        class_2561 baseText = class_2561.method_43469(translationKey, powerText).method_27692(baseTextColor);

        tooltip.add(baseText);
        tooltip.addAll(powerTexts);

    }

}
