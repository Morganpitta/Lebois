package io.github.apace100.apoli.component.item;

import io.github.apace100.apoli.Apoli;
import net.minecraft.class_2378;
import net.minecraft.class_7923;
import net.minecraft.class_9331;

public class ApoliDataComponentTypes {

    public static final class_9331<ItemPowersComponent> POWERS = class_9331.<ItemPowersComponent>method_57873()
        .method_57881(ItemPowersComponent.CODEC)
        .method_57882(ItemPowersComponent.PACKET_CODEC)
        .method_57880();

    public static void register() {
        class_2378.method_10230(class_7923.field_49658, Apoli.identifier("powers"), POWERS);
    }

}
