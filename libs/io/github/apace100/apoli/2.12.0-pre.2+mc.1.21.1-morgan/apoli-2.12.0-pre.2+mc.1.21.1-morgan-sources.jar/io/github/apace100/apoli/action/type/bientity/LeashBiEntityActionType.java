package io.github.apace100.apoli.action.type.bientity;

import io.github.apace100.apoli.access.CustomLeashable;
import io.github.apace100.apoli.action.ActionConfiguration;
import io.github.apace100.apoli.action.context.BiEntityActionContext;
import io.github.apace100.apoli.action.type.BiEntityActionType;
import io.github.apace100.apoli.action.type.BiEntityActionTypes;
import io.github.apace100.apoli.util.requirement.BiEntityRequirement;
import net.minecraft.class_1297;
import net.minecraft.class_9817;
import org.jetbrains.annotations.NotNull;

public class LeashBiEntityActionType extends BiEntityActionType {

    @Override
    public void accept(BiEntityActionContext context) {

        class_1297 actor = context.actor();
        class_1297 target = context.target();

        if (target instanceof class_9817 leashable && target instanceof CustomLeashable customLeashable && !leashable.method_60953()) {
            customLeashable.apoli$setCustomLeashed(true);
            leashable.method_60964(actor, true);
        }

    }

    @Override
    public @NotNull ActionConfiguration<?> getConfig() {
        return BiEntityActionTypes.LEASH;
    }

    @Override
    public BiEntityRequirement getRequirement() {
        return BiEntityRequirement.BOTH;
    }

}
