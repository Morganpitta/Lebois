package io.github.apace100.apoli.action.type.entity;

import io.github.apace100.apoli.action.ActionConfiguration;
import io.github.apace100.apoli.action.context.EntityActionContext;
import io.github.apace100.apoli.action.type.EntityActionType;
import io.github.apace100.apoli.action.type.EntityActionTypes;
import io.github.apace100.apoli.component.PowerHolderComponent;
import io.github.apace100.apoli.data.ApoliDataTypes;
import io.github.apace100.apoli.data.TypedDataObjectFactory;
import io.github.apace100.apoli.power.PowerReference;
import io.github.apace100.apoli.util.PowerUtil;
import io.github.apace100.apoli.util.modifier.Modifier;
import io.github.apace100.calio.data.SerializableData;
import org.jetbrains.annotations.NotNull;

import java.util.List;
import net.minecraft.class_1297;

public class ModifyResourceEntityActionType extends EntityActionType {

    public static final TypedDataObjectFactory<ModifyResourceEntityActionType> DATA_FACTORY = TypedDataObjectFactory.simple(
        new SerializableData()
            .add("resource", ApoliDataTypes.RESOURCE_REFERENCE)
            .add("modifier", Modifier.DATA_TYPE),
        data -> new ModifyResourceEntityActionType(
            data.get("resource"),
            data.get("modifier")
        ),
        (actionType, serializableData) -> serializableData.instance()
            .set("resource", actionType.resource)
            .set("modifier", actionType.modifier)
    );

    private final PowerReference resource;
    private final Modifier modifier;

    public ModifyResourceEntityActionType(PowerReference resource, Modifier modifier) {
        this.resource = resource;
        this.modifier = modifier;
    }

    @Override
    public void accept(EntityActionContext context) {

        class_1297 entity = context.entity();

        if (PowerUtil.modifyResourceValue(resource.getNullablePowerType(entity), List.of(modifier))) {
            PowerHolderComponent.syncPower(entity, resource);
        }

    }

    @Override
    public @NotNull ActionConfiguration<?> getConfig() {
        return EntityActionTypes.MODIFY_RESOURCE;
    }

}
