package io.github.apace100.apoli.condition.type.entity;

import io.github.apace100.apoli.condition.ConditionConfiguration;
import io.github.apace100.apoli.condition.context.EntityConditionContext;
import io.github.apace100.apoli.condition.type.EntityConditionType;
import io.github.apace100.apoli.condition.type.EntityConditionTypes;
import io.github.apace100.apoli.mixin.ClientPlayerEntityAccessor;
import io.github.apace100.apoli.mixin.ClientPlayerInteractionManagerAccessor;
import io.github.apace100.apoli.mixin.ServerPlayerInteractionManagerAccessor;
import net.minecraft.class_1657;
import net.minecraft.class_2680;
import net.minecraft.class_3222;
import net.minecraft.class_746;
import org.jetbrains.annotations.NotNull;

public class UsingEffectiveToolEntityConditionType extends EntityConditionType {

    @Override
    public boolean test(EntityConditionContext context) {

        if (!(context.entity() instanceof class_1657 playerEntity)) {
            return false;
        }

        class_2680 miningBlockState;
        if (playerEntity instanceof class_3222 serverPlayer) {

            ServerPlayerInteractionManagerAccessor interactionManager = (ServerPlayerInteractionManagerAccessor) serverPlayer.field_13974;
            if (!interactionManager.getMining()) {
                return false;
            }

            miningBlockState = playerEntity.method_37908().method_8320(interactionManager.getMiningPos());

        }

        else if (playerEntity instanceof class_746 clientPlayer) {

            ClientPlayerInteractionManagerAccessor interactionManager = (ClientPlayerInteractionManagerAccessor) ((ClientPlayerEntityAccessor) clientPlayer).getClient().field_1761;
            if (interactionManager == null || !interactionManager.getBreakingBlock()) {
                return false;
            }

            miningBlockState = playerEntity.method_37908().method_8320(interactionManager.getCurrentBreakingPos());

        }

        else {
            return false;
        }

        return playerEntity.method_7305(miningBlockState);

    }

    @Override
    public @NotNull ConditionConfiguration<?> getConfig() {
        return EntityConditionTypes.USING_EFFECTIVE_TOOL;
    }

}
