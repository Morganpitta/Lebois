package io.github.apace100.apoli.data;

import io.github.apace100.apoli.Apoli;
import net.minecraft.class_5321;
import net.minecraft.class_7924;
import net.minecraft.class_8110;

public interface ApoliDamageTypes {
    class_5321<class_8110> SYNC_DAMAGE_SOURCE = class_5321.method_29179(class_7924.field_42534, Apoli.identifier("sync_damage_source"));
}
