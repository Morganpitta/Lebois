package io.github.apace100.apoli.condition.type.item;

import io.github.apace100.apoli.component.item.ApoliDataComponentTypes;
import io.github.apace100.apoli.component.item.ItemPowersComponent;
import io.github.apace100.apoli.condition.ConditionConfiguration;
import io.github.apace100.apoli.condition.context.ItemConditionContext;
import io.github.apace100.apoli.condition.type.ItemConditionType;
import io.github.apace100.apoli.condition.type.ItemConditionTypes;
import io.github.apace100.apoli.data.ApoliDataTypes;
import io.github.apace100.apoli.data.TypedDataObjectFactory;
import io.github.apace100.apoli.power.PowerReference;
import io.github.apace100.calio.data.SerializableData;
import io.github.apace100.calio.data.SerializableDataTypes;
import org.jetbrains.annotations.NotNull;

import java.util.Optional;
import net.minecraft.class_9274;

public class HasPowerItemConditionType extends ItemConditionType {

    public static final TypedDataObjectFactory<HasPowerItemConditionType> DATA_FACTORY = TypedDataObjectFactory.simple(
        new SerializableData()
            .add("slot", SerializableDataTypes.ATTRIBUTE_MODIFIER_SLOT.optional(), Optional.empty())
            .add("power", ApoliDataTypes.POWER_REFERENCE),
        data -> new HasPowerItemConditionType(
            data.get("slot"),
            data.get("power")
        ),
        (conditionType, serializableData) -> serializableData.instance()
            .set("slot", conditionType.slot)
            .set("power", conditionType.power)
    );

    private final Optional<class_9274> slot;
    private final PowerReference power;

    public HasPowerItemConditionType(Optional<class_9274> slot, PowerReference power) {
        this.slot = slot;
        this.power = power;
    }

    @Override
    public boolean test(ItemConditionContext context) {
        return context.stack().method_57825(ApoliDataComponentTypes.POWERS, ItemPowersComponent.DEFAULT)
            .stream()
            .filter(entry -> slot.map(entry.slot()::equals).orElse(true))
            .map(ItemPowersComponent.Entry::powerId)
            .anyMatch(power.id()::equals);
    }

    @Override
    public @NotNull ConditionConfiguration<?> getConfig() {
        return ItemConditionTypes.HAS_POWER;
    }

}
