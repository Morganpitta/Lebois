package io.github.apace100.apoli.condition.type.entity;

import io.github.apace100.apoli.Apoli;
import io.github.apace100.apoli.condition.ConditionConfiguration;
import io.github.apace100.apoli.condition.context.EntityConditionContext;
import io.github.apace100.apoli.condition.type.EntityConditionType;
import io.github.apace100.apoli.condition.type.EntityConditionTypes;
import io.github.apace100.apoli.data.ApoliDataTypes;
import io.github.apace100.apoli.data.TypedDataObjectFactory;
import io.github.apace100.apoli.util.Comparison;
import io.github.apace100.calio.data.SerializableData;
import io.github.apace100.calio.data.SerializableDataTypes;
import net.minecraft.class_1297;
import net.minecraft.class_1937;
import net.minecraft.class_2165;
import net.minecraft.class_2168;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;
import org.jetbrains.annotations.NotNull;

import java.util.concurrent.atomic.AtomicInteger;

public class CommandEntityConditionType extends EntityConditionType {

    public static final TypedDataObjectFactory<CommandEntityConditionType> DATA_FACTORY = TypedDataObjectFactory.simple(
        new SerializableData()
            .add("command", SerializableDataTypes.STRING)
            .add("comparison", ApoliDataTypes.COMPARISON)
            .add("compare_to", SerializableDataTypes.INT),
        data -> new CommandEntityConditionType(
            data.get("command"),
            data.get("comparison"),
            data.get("compare_to")
        ),
        (conditionType, serializableData) -> serializableData.instance()
            .set("command", conditionType.command)
            .set("comparison", conditionType.comparison)
            .set("compare_to", conditionType.compareTo)
    );

    private final String command;

    private final Comparison comparison;
    private final int compareTo;

    public CommandEntityConditionType(String command, Comparison comparison, int compareTo) {
        this.command = command;
        this.comparison = comparison;
        this.compareTo = compareTo;
    }

    @Override
    public boolean test(EntityConditionContext context) {

        class_1297 entity = context.entity();
        class_1937 world = entity.method_37908();

        if (!(world instanceof class_3218 serverWorld)) {
            return false;
        }

        MinecraftServer server = serverWorld.method_8503();
        AtomicInteger result = new AtomicInteger();

        class_2168 commandSource = entity.method_5671()
            .method_9231((successful, returnValue) -> result.set(returnValue))
            .method_9206(Apoli.config.executeCommand.permissionLevel)
            .method_36321(class_2165.field_17395);

        if (Apoli.config.executeCommand.showOutput) {

            class_2165 output = entity instanceof class_3222 serverPlayer && serverPlayer.field_13987 != null
                ? serverPlayer
                : server;

            commandSource = commandSource.method_36321(output);

        }

        server.method_3734().method_44252(commandSource, command);
        return comparison.compare(result.get(), compareTo);

    }

    @Override
    public @NotNull ConditionConfiguration<?> getConfig() {
        return EntityConditionTypes.COMMAND;
    }

}
