package io.github.apace100.apoli.condition.type.bientity;

import io.github.apace100.apoli.condition.ConditionConfiguration;
import io.github.apace100.apoli.condition.context.BiEntityConditionContext;
import io.github.apace100.apoli.condition.type.BiEntityConditionType;
import io.github.apace100.apoli.condition.type.BiEntityConditionTypes;
import io.github.apace100.apoli.util.requirement.BiEntityRequirement;
import org.jetbrains.annotations.NotNull;

import java.util.Objects;
import net.minecraft.class_1297;

public class RidingRecursiveBiEntityConditionType extends BiEntityConditionType {

    @Override
    public boolean test(BiEntityConditionContext context) {

        class_1297 vehicle = context.actor().method_5854();

        while (vehicle != null) {

            if (Objects.equals(vehicle, context.target())) {
                return true;
            }

            else {
                vehicle = vehicle.method_5854();
            }

        }

        return false;

    }

    @Override
    public BiEntityRequirement getRequirement() {
        return BiEntityRequirement.BOTH;
    }

    @Override
    public @NotNull ConditionConfiguration<?> getConfig() {
        return BiEntityConditionTypes.RIDING_RECURSIVE;
    }

}
