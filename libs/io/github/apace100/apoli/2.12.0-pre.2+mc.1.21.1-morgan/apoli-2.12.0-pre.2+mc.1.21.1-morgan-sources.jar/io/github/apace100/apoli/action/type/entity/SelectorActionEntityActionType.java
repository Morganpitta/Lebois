package io.github.apace100.apoli.action.type.entity;

import com.mojang.brigadier.exceptions.CommandSyntaxException;
import io.github.apace100.apoli.Apoli;
import io.github.apace100.apoli.action.ActionConfiguration;
import io.github.apace100.apoli.action.BiEntityAction;
import io.github.apace100.apoli.action.context.EntityActionContext;
import io.github.apace100.apoli.action.type.EntityActionType;
import io.github.apace100.apoli.action.type.EntityActionTypes;
import io.github.apace100.apoli.condition.BiEntityCondition;
import io.github.apace100.apoli.data.ApoliDataTypes;
import io.github.apace100.apoli.data.TypedDataObjectFactory;
import io.github.apace100.calio.data.SerializableData;
import io.github.apace100.calio.util.ArgumentWrapper;
import net.minecraft.class_1297;
import net.minecraft.class_2165;
import net.minecraft.class_2168;
import net.minecraft.class_2300;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;
import org.jetbrains.annotations.NotNull;

import java.util.Optional;

public class SelectorActionEntityActionType extends EntityActionType {

    public static final TypedDataObjectFactory<SelectorActionEntityActionType> DATA_FACTORY = TypedDataObjectFactory.simple(
        new SerializableData()
            .add("selector", ApoliDataTypes.ENTITIES_SELECTOR)
            .add("bientity_action", BiEntityAction.DATA_TYPE)
            .add("bientity_condition", BiEntityCondition.DATA_TYPE.optional(), Optional.empty()),
        data -> new SelectorActionEntityActionType(
            data.get("selector"),
            data.get("bientity_action"),
            data.get("bientity_condition")
        ),
        (actionType, serializableData) -> serializableData.instance()
            .set("selector", actionType.selector)
            .set("bientity_action", actionType.biEntityAction)
            .set("bientity_condition", actionType.biEntityCondition)
    );

    private final ArgumentWrapper<class_2300> selector;
    private final class_2300 unwrappedSelector;

    private final BiEntityAction biEntityAction;
    private final Optional<BiEntityCondition> biEntityCondition;

    public SelectorActionEntityActionType(ArgumentWrapper<class_2300> selector, BiEntityAction biEntityAction, Optional<BiEntityCondition> biEntityCondition) {
        this.selector = selector;
        this.unwrappedSelector = selector.parsedValue();
        this.biEntityAction = biEntityAction;
        this.biEntityCondition = biEntityCondition;
    }

    @Override
    public void accept(EntityActionContext context) {

        class_1297 entity = context.entity();
        MinecraftServer server = entity.method_5682();

        if (server == null) {
            return;
        }

        class_2168 commandSource = entity.method_5671()
            .method_36321(class_2165.field_17395)
            .method_9206(Apoli.config.executeCommand.permissionLevel);

        if (Apoli.config.executeCommand.showOutput) {
            commandSource = commandSource.method_36321(entity instanceof class_3222 serverPlayer && serverPlayer.field_13987 != null
                ? serverPlayer
                : server);
        }

        try {
            unwrappedSelector.method_9816(commandSource)
                .stream()
                .filter(selected -> biEntityCondition.map(condition -> condition.test(entity, selected)).orElse(true))
                .forEach(selected -> biEntityAction.execute(entity, selected));
        }

        catch (CommandSyntaxException cse) {
            commandSource.method_9213(class_2561.method_54155(cse.getRawMessage()));
        }

    }

    @Override
    public @NotNull ActionConfiguration<?> getConfig() {
        return EntityActionTypes.SELECTOR_ACTION;
    }

}
