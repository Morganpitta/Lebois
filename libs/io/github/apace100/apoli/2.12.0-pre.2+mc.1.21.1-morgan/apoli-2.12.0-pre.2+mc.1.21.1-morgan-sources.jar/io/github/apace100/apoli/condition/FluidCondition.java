package io.github.apace100.apoli.condition;

import io.github.apace100.apoli.condition.context.FluidConditionContext;
import io.github.apace100.apoli.condition.type.FluidConditionType;
import io.github.apace100.apoli.condition.type.FluidConditionTypes;
import io.github.apace100.apoli.data.ApoliDataTypes;
import io.github.apace100.calio.data.SerializableDataType;
import net.minecraft.class_3610;

public final class FluidCondition extends Condition<FluidConditionContext, FluidConditionType> {

	public static final SerializableDataType<FluidCondition> DATA_TYPE = SerializableDataType.lazy(() -> ApoliDataTypes.condition("type", FluidConditionTypes.DATA_TYPE, FluidCondition::new));

	public FluidCondition(FluidConditionType conditionType, boolean inverted) {
		super(conditionType, inverted);
	}

	public FluidCondition(FluidConditionType conditionType) {
		this(conditionType, false);
	}

	public boolean test(class_3610 fluidState) {
		return test(new FluidConditionContext(fluidState));
	}

}
