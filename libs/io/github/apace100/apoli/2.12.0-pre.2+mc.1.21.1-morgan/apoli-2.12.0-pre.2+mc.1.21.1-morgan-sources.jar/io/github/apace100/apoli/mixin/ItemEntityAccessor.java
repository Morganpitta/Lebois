package io.github.apace100.apoli.mixin;

import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

import java.util.UUID;
import net.minecraft.class_1542;

@Mixin(class_1542.class)
public interface ItemEntityAccessor {

    @Nullable
    @Accessor
    UUID getThrowerUuid();

}
