package io.github.apace100.apoli.mixin;

import net.minecraft.class_1657;
import net.minecraft.class_1714;
import net.minecraft.class_3914;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_1714.class)
public interface CraftingScreenHandlerAccessor {

    @Accessor
    class_1657 getPlayer();

    @Accessor
    class_3914 getContext();
}
