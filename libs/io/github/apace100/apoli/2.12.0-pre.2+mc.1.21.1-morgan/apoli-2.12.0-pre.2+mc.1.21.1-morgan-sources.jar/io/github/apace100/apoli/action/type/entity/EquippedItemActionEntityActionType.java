package io.github.apace100.apoli.action.type.entity;

import io.github.apace100.apoli.action.ActionConfiguration;
import io.github.apace100.apoli.action.ItemAction;
import io.github.apace100.apoli.action.context.EntityActionContext;
import io.github.apace100.apoli.action.type.EntityActionType;
import io.github.apace100.apoli.action.type.EntityActionTypes;
import io.github.apace100.apoli.data.TypedDataObjectFactory;
import io.github.apace100.calio.data.SerializableData;
import io.github.apace100.calio.data.SerializableDataTypes;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_5630;
import net.minecraft.class_9274;
import org.jetbrains.annotations.NotNull;

public class EquippedItemActionEntityActionType extends EntityActionType {

    public static final TypedDataObjectFactory<EquippedItemActionEntityActionType> DATA_FACTORY = TypedDataObjectFactory.simple(
        new SerializableData()
            .add("equipment_slot", SerializableDataTypes.ATTRIBUTE_MODIFIER_SLOT)
            .add("item_action", ItemAction.DATA_TYPE),
        data -> new EquippedItemActionEntityActionType(
            data.get("equipment_slot"),
            data.get("item_action")
        ),
        (actionType, serializableData) -> serializableData.instance()
            .set("equipment_slot", actionType.equipmentSlot)
            .set("item_action", actionType.itemAction)
    );

    private final class_9274 equipmentSlot;
    private final ItemAction itemAction;

    public EquippedItemActionEntityActionType(class_9274 equipmentSlot, ItemAction itemAction) {
        this.equipmentSlot = equipmentSlot;
        this.itemAction = itemAction;
    }

    @Override
    public void accept(EntityActionContext context) {

        if (!(context.entity() instanceof class_1309 livingEntity)) {
            return;
        }

        for (class_1304 slot : class_1304.values()) {

            if (equipmentSlot.method_57286(slot)) {
                itemAction.execute(livingEntity.method_37908(), class_5630.method_32330(livingEntity, slot));
            }

        }

    }

    @Override
    public @NotNull ActionConfiguration<?> getConfig() {
        return EntityActionTypes.EQUIPPED_ITEM_ACTION;
    }

}
