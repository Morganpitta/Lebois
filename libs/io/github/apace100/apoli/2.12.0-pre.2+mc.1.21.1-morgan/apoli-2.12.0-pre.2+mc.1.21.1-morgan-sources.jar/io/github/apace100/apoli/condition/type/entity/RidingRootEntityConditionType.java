package io.github.apace100.apoli.condition.type.entity;

import io.github.apace100.apoli.condition.BiEntityCondition;
import io.github.apace100.apoli.condition.ConditionConfiguration;
import io.github.apace100.apoli.condition.context.EntityConditionContext;
import io.github.apace100.apoli.condition.type.EntityConditionType;
import io.github.apace100.apoli.condition.type.EntityConditionTypes;
import io.github.apace100.apoli.data.TypedDataObjectFactory;
import io.github.apace100.calio.data.SerializableData;
import org.jetbrains.annotations.NotNull;

import java.util.Optional;
import net.minecraft.class_1297;

public class RidingRootEntityConditionType extends EntityConditionType {

    public static final TypedDataObjectFactory<RidingRootEntityConditionType> DATA_FACTORY = TypedDataObjectFactory.simple(
        new SerializableData()
            .add("bientity_condition", BiEntityCondition.DATA_TYPE.optional(), Optional.empty()),
        data -> new RidingRootEntityConditionType(
            data.get("bientity_condition")
        ),
        (conditionType, serializableData) -> serializableData.instance()
            .set("bientity_condition", conditionType.biEntityCondition)
    );

    private final Optional<BiEntityCondition> biEntityCondition;

    public RidingRootEntityConditionType(Optional<BiEntityCondition> biEntityCondition) {
        this.biEntityCondition = biEntityCondition;
    }

    @Override
    public boolean test(EntityConditionContext context) {

        class_1297 entity = context.entity();
        class_1297 rootVehicle = entity.method_5668();

        return rootVehicle != null
            && biEntityCondition.map(condition -> condition.test(entity, rootVehicle)).orElse(true);

    }

    @Override
    public @NotNull ConditionConfiguration<?> getConfig() {
        return EntityConditionTypes.RIDING_ROOT;
    }

}
