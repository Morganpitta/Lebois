package io.github.apace100.apoli.action.type.entity;

import io.github.apace100.apoli.action.ActionConfiguration;
import io.github.apace100.apoli.action.context.EntityActionContext;
import io.github.apace100.apoli.action.type.EntityActionType;
import io.github.apace100.apoli.action.type.EntityActionTypes;
import io.github.apace100.apoli.data.TypedDataObjectFactory;
import io.github.apace100.calio.data.SerializableData;
import io.github.apace100.calio.data.SerializableDataTypes;
import net.minecraft.class_1309;
import org.jetbrains.annotations.NotNull;

public class GainAirEntityActionType extends EntityActionType {

    public static final TypedDataObjectFactory<GainAirEntityActionType> DATA_FACTORY = TypedDataObjectFactory.simple(
        new SerializableData()
            .add("value", SerializableDataTypes.INT),
        data -> new GainAirEntityActionType(
            data.get("value")
        ),
        (actionType, serializableData) -> serializableData.instance()
            .set("value", actionType.value)
    );

    private final int value;

    public GainAirEntityActionType(int value) {
        this.value = value;
    }

    @Override
    public void accept(EntityActionContext context) {

        if (context.entity() instanceof class_1309 livingEntity) {
            livingEntity.method_5855(Math.min(livingEntity.method_5669() + value, livingEntity.method_5748()));
        }

    }

    @Override
    public @NotNull ActionConfiguration<?> getConfig() {
        return EntityActionTypes.GAIN_AIR;
    }

}
