package io.github.apace100.apoli.access;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1058;
import net.minecraft.class_2960;

@Environment(EnvType.CLIENT)
public interface OverlaySpriteHolder {
    class_1058 apoli$getSprite(class_2960 id);
}
