package io.github.apace100.apoli.action.type.bientity;

import io.github.apace100.apoli.action.ActionConfiguration;
import io.github.apace100.apoli.action.context.BiEntityActionContext;
import io.github.apace100.apoli.action.type.BiEntityActionType;
import io.github.apace100.apoli.action.type.BiEntityActionTypes;
import io.github.apace100.apoli.networking.packet.s2c.MountPlayerS2CPacket;
import io.github.apace100.apoli.util.requirement.BiEntityRequirement;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_1297;
import net.minecraft.class_3222;
import org.jetbrains.annotations.NotNull;

public class MountBiEntityActionType extends BiEntityActionType {

    @Override
    public void accept(BiEntityActionContext context) {

        class_1297 actor = context.actor();
        class_1297 target = context.target();

        actor.method_5873(target, true);

        if (target instanceof class_3222 targetPlayer) {
            ServerPlayNetworking.send(targetPlayer, new MountPlayerS2CPacket(actor.method_5628(), target.method_5628()));
        }

    }

    @Override
    public @NotNull ActionConfiguration<?> getConfig() {
        return BiEntityActionTypes.MOUNT;
    }

    @Override
    public BiEntityRequirement getRequirement() {
        return BiEntityRequirement.BOTH;
    }

}
