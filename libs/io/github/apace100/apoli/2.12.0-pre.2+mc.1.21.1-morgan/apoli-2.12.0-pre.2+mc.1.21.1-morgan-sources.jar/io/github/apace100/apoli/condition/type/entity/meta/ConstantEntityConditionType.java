package io.github.apace100.apoli.condition.type.entity.meta;

import io.github.apace100.apoli.condition.ConditionConfiguration;
import io.github.apace100.apoli.condition.context.EntityConditionContext;
import io.github.apace100.apoli.condition.type.EntityConditionType;
import io.github.apace100.apoli.condition.type.EntityConditionTypes;
import io.github.apace100.apoli.condition.type.meta.ConstantMetaConditionType;
import org.jetbrains.annotations.NotNull;

public class ConstantEntityConditionType extends EntityConditionType implements ConstantMetaConditionType {

	private final boolean value;

	public ConstantEntityConditionType(boolean value) {
		this.value = value;
	}

	@Override
	public boolean test(EntityConditionContext context) {
		return value();
	}

	@Override
	public @NotNull ConditionConfiguration<?> getConfig() {
		return EntityConditionTypes.CONSTANT;
	}

	@Override
	public boolean value() {
		return value;
	}

}
