package io.github.apace100.apoli.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

import java.util.List;
import net.minecraft.class_9080;

@Mixin(class_9080.class)
public interface LayeredDrawerAccessor {

    @Accessor
    List<class_9080.class_9081> getLayers();

}
