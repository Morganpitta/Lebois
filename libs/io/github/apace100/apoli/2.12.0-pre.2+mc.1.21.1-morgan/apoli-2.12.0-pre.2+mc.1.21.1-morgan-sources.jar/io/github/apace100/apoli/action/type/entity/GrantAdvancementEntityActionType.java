package io.github.apace100.apoli.action.type.entity;

import io.github.apace100.apoli.Apoli;
import io.github.apace100.apoli.action.ActionConfiguration;
import io.github.apace100.apoli.action.context.EntityActionContext;
import io.github.apace100.apoli.action.type.EntityActionType;
import io.github.apace100.apoli.action.type.EntityActionTypes;
import io.github.apace100.apoli.data.ApoliDataTypes;
import io.github.apace100.apoli.data.TypedDataObjectFactory;
import io.github.apace100.apoli.util.AdvancementUtil;
import io.github.apace100.apoli.util.MiscUtil;
import io.github.apace100.calio.data.SerializableData;
import io.github.apace100.calio.data.SerializableDataTypes;
import net.minecraft.class_1297;
import net.minecraft.class_2960;
import net.minecraft.class_2989;
import net.minecraft.class_3008;
import net.minecraft.class_3222;
import net.minecraft.class_8779;
import net.minecraft.server.MinecraftServer;
import org.jetbrains.annotations.NotNull;

import java.util.List;

public class GrantAdvancementEntityActionType extends EntityActionType {

    public static final TypedDataObjectFactory<GrantAdvancementEntityActionType> DATA_FACTORY = TypedDataObjectFactory.simple(
        new SerializableData()
            .add("advancement", SerializableDataTypes.IDENTIFIER)
            .add("selection", ApoliDataTypes.ADVANCEMENT_SELECTION, class_3008.class_3010.field_13464)
            .add("criterion", SerializableDataTypes.STRING, null)
            .addFunctionedDefault("criteria", SerializableDataTypes.STRINGS, data -> MiscUtil.singletonListOrEmpty(data.get("criterion"))),
        data -> new GrantAdvancementEntityActionType(
            data.get("advancement"),
            data.get("selection"),
            data.get("criteria")
        ),
        (actionType, serializableData) -> serializableData.instance()
            .set("advancement", actionType.advancementId)
            .set("selection", actionType.selection)
            .set("criteria", actionType.criteria)
    );

    private final class_2960 advancementId;
    private final class_3008.class_3010 selection;

    private final List<String> criteria;

    public GrantAdvancementEntityActionType(class_2960 advancementId, class_3008.class_3010 selection, List<String> criteria) {
        this.advancementId = advancementId;
        this.selection = selection;
        this.criteria = criteria;
    }

    @Override
    public void accept(EntityActionContext context) {

        class_1297 entity = context.entity();
        MinecraftServer server = entity.method_5682();

        if (server == null || !(entity instanceof class_3222 serverPlayerEntity)) {
            return;
        }

        class_2989 advancementLoader = server.method_3851();
        if (selection == class_3008.class_3010.field_13461) {
            AdvancementUtil.processAdvancements(advancementLoader.method_12893(), class_3008.class_3009.field_13457, serverPlayerEntity);
        }

        else if (advancementId != null) {

            class_8779 advancementEntry = advancementLoader.method_12896(advancementId);
            if (advancementEntry == null) {
                Apoli.LOGGER.warn("Unknown advancement (\"" + advancementId + "\") referenced in `grant_advancement` entity action type!");
            }

            else if (criteria.isEmpty()) {
                AdvancementUtil.processAdvancements(AdvancementUtil.selectEntries(server.method_3851().method_53646(), advancementEntry, selection), class_3008.class_3009.field_13457, serverPlayerEntity);
            }

            else {
                AdvancementUtil.processCriteria(advancementEntry, criteria, class_3008.class_3009.field_13457, serverPlayerEntity);
            }

        }

    }

    @Override
    public @NotNull ActionConfiguration<?> getConfig() {
        return EntityActionTypes.GRANT_ADVANCEMENT;
    }

}
