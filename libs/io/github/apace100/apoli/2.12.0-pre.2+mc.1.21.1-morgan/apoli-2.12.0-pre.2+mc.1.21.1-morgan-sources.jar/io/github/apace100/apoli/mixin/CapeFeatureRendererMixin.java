package io.github.apace100.apoli.mixin;

import io.github.apace100.apoli.component.PowerHolderComponent;
import io.github.apace100.apoli.power.type.ElytraFlightPowerType;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_742;
import net.minecraft.class_972;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_972.class)
public class CapeFeatureRendererMixin {

    @Inject(at = @At("HEAD"), method = "render", cancellable = true)
    private void preventCapeRendering(class_4587 matrixStack, class_4597 vertexConsumerProvider, int i, class_742 abstractClientPlayerEntity, float f, float g, float h, float j, float k, float l, CallbackInfo ci) {
        if(PowerHolderComponent.getPowerTypes(abstractClientPlayerEntity, ElytraFlightPowerType.class).stream().anyMatch(ElytraFlightPowerType::shouldRenderElytra)) {
            ci.cancel();
        }
    }
}
