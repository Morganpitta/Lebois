package io.github.apace100.apoli.action.type.entity;

import io.github.apace100.apoli.action.ActionConfiguration;
import io.github.apace100.apoli.action.context.EntityActionContext;
import io.github.apace100.apoli.action.type.EntityActionType;
import io.github.apace100.apoli.action.type.EntityActionTypes;
import io.github.apace100.apoli.data.TypedDataObjectFactory;
import io.github.apace100.calio.data.SerializableData;
import io.github.apace100.calio.data.SerializableDataType;
import io.github.apace100.calio.data.SerializableDataTypes;
import org.jetbrains.annotations.NotNull;

import java.util.Optional;
import net.minecraft.class_1297;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_3414;
import net.minecraft.class_3419;

public class PlaySoundEntityActionType extends EntityActionType {

    public static final TypedDataObjectFactory<PlaySoundEntityActionType> DATA_FACTORY = TypedDataObjectFactory.simple(
        new SerializableData()
            .add("sound", SerializableDataTypes.SOUND_EVENT)
            .add("category", SerializableDataType.enumValue(class_3419.class).optional(), Optional.empty())
            .add("volume", SerializableDataTypes.FLOAT, 1.0F)
            .add("pitch", SerializableDataTypes.FLOAT, 1.0F),
        data -> new PlaySoundEntityActionType(
            data.get("sound"),
            data.get("category"),
            data.get("volume"),
            data.get("pitch")
        ),
        (actionType, serializableData) -> serializableData.instance()
            .set("sound", actionType.sound)
            .set("category", actionType.category)
            .set("volume", actionType.volume)
            .set("pitch", actionType.pitch)
    );

    private final class_3414 sound;
    private final Optional<class_3419> category;

    private final float volume;
    private final float pitch;

    public PlaySoundEntityActionType(class_3414 sound, Optional<class_3419> category, float volume, float pitch) {
        this.sound = sound;
        this.category = category;
        this.volume = volume;
        this.pitch = pitch;
    }

    @Override
    public void accept(EntityActionContext context) {

        class_1297 entity = context.entity();
        class_1937 world = entity.method_37908();

        class_2338 blockPos = class_2338.method_49638(entity.method_19538().method_1019(context.offset()));
        world.method_8396(null, blockPos, sound, category.orElseGet(entity::method_5634), volume, pitch);

    }

    @Override
    public @NotNull ActionConfiguration<?> getConfig() {
        return EntityActionTypes.PLAY_SOUND;
    }

}
